<?php

namespace Netatmo\Common;

class NACameraInfo
{
    const CI_ID = "id";
    const CI_NAME = "name";
    const CI_LIVE_URL = "live_url";
    const CI_STATUS = "status";
    const CI_SD_STATUS = "sd_status";
    const CI_ALIM_STATUS = "alim_status";
    const CI_IS_LOCAL = "is_local";
    const CI_VPN_URL = "vpn_url";
}

?>
