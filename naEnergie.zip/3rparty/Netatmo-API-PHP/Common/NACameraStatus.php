<?php

namespace Netatmo\Common;

class NACameraStatus
{
    const CS_ON = "on";
    const CS_OFF = "off" ;
    const CS_DISCONNECTED = "disconnected";
}

?>
