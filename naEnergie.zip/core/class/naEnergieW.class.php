<?php
//error_reporting(E_ALL);
/* * ***************************Includes********************************* */

//require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';
     
/* * ***************************  class naEnergieW  ********************************* */

class naEnergieW {

/* *  _nawLogin  ************************************************************ */
	public static function _nawLogin(){
      	$sesCookie = cache::bykey('naEnergie_web')->getValue();
      	//if(!$sesCookie || strtotime($sesCookie['expires']) <= (time()-14400)){
      	if(1==1){
      	$login_url='https://auth.netatmo.com/fr-fr/access/login';
      	//$tags = get_meta_tags($login_url);
        //$csrf_token=$tags['csrf-token'];
      	$login_rqst = self::wRequest($login_url, 'GET', null);
		preg_match('/.*<meta name="csrf-token" content="([a-zA-Z0-9]+)" \/>.*/m', $login_rqst['body'], $csrf);
		$csrf_token=$csrf[1]; 
      
      
      
      
		$next_url=array('next_url' => 'https://my.netatmo.com/settingsenergy/room/5981cac4e6da23627e8b6294/3264158207');
		$auth_url='https://auth.netatmo.com/access/postlogin?next_url=https%3A%2F%2Fmy.netatmo.com%2Fsettingsenergy%2Froom%2F5981cac4e6da23627e8b6294%2F3264158207';
		$params = array(
          		'email'			=> config::byKey('username', 'naEnergie'),//l.imad%40sfr.fr
				'password'		=> config::byKey('napassword', 'naEnergie'),
				'stay_logged'	=> 'on',
  				'_token'	=> $csrf_token
		);
		$auth_rqst = self::wRequest($auth_url, 'POST', $params);
      	//log::add('naEnergie', 'debug', __FUNCTION__ .' rqst_param: '.json_encode($params));
      	log::add('naEnergie', 'debug', __FUNCTION__ .' auth_rqst[code]: '.$auth_rqst['code']);
      	log::add('naEnergie', 'debug', __FUNCTION__ .' auth_rqst[stat]: '.$auth_rqst['stat']);
      	log::add('naEnergie', 'debug', __FUNCTION__ .' auth_rqst[headers]: '.json_encode($auth_rqst['headers']));
      	log::add('naEnergie', 'debug', __FUNCTION__ .' auth_rqst[body]: '.$auth_rqst['body']);
      
      
		$ar_token = self::getheadersVal($auth_rqst['headers'], 'Set-Cookie', 'netatmocomaccess_token');
      	cache::set('naEnergie_web','');
        //cache::set('naEnergie', $ar_token);
	//////////////////////////
      	$cookieRsp = jeedom::getTmpFolder('naEnergie').'/cookie_naEnergie';
      	$content = file_get_contents($cookieRsp);
		//preg_match("/netatmocomaccess_token\s*(.*)/", $content, $match_token);
		//$token = trim(array_pop($match_token));
      	preg_match("/netatmocomci_csrf_cookie_na\s*(.*)/", $content, $match_csrf);
      	$csrf = trim(array_pop($match_csrf));
      	log::add('naEnergie', 'debug', __FUNCTION__ .' csrf: '.$csrf);
      	//log::add('naEnergie', 'debug', __FUNCTION__ .' sesCookie1: '.json_encode($sesCookie));
      	
		$ar_token['csrf'] = $csrf;
		cache::set('naEnergie_web', $ar_token );
        log::add('naEnergie', 'debug', __FUNCTION__ .' ar_token: '.json_encode($ar_token));
      	
		//log::add('naEnergie', 'debug', __FUNCTION__ .' sesCookie2: '.json_encode($sesCookie));

        }
      
      	/*$sesCookie=["netatmocomaccess_token":"56477d094bda1daa808b45a2%7C705225923c617a6da3ce4da28434f4c0",
                    " expires":"Wed, 15-Apr-2020 16:33:05 GMT"," Max-Age":"10800"," path":"\/"," domain":".netatmo.com"," secure":null,"csrf":"24db79515c073ee349e0cf4d3d270da5"];*/
      	//strtotime($sesCookie['expires']) <= (time()-14400)
        $sesCookie = cache::bykey('naEnergie_web')->getValue();
      	log::add('naEnergie', 'debug', __FUNCTION__ .' cach_expires: '.$sesCookie["expires"].'-'.strtotime($sesCookie['expires']) );
      	log::add('naEnergie', 'debug', __FUNCTION__ .' cach_token: '.$sesCookie['netatmocomaccess_token']);
      	//exp= $content->getCookieByName('netatmocomci_csrf_cookie_na')->getExpires();
        //- 36000) < time()
      	return $sesCookie;
      
    }

/* *  wRequest  ************************************************************ */
	public static function wRequest($path, $method = 'GET', $params = array()){
        $cookiefile = jeedom::getTmpFolder('naEnergie').'/cookie_naEnergie';
		file_put_contents($cookiefile, 'null' . "\n");
       	$ch = curl_init();
        $opts =  array(
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_HEADER         => TRUE,
            CURLOPT_TIMEOUT        => 60,
            //CURLOPT_USERAGENT      => 'netatmoclient',
          	CURLOPT_USERAGENT      => "(X11; Linux) Safari",
          	CURLOPT_SSL_VERIFYPEER => TRUE,
          	//CURLINFO_HEADER_OUT	   => TRUE,
          	CURLOPT_COOKIEJAR	   => $cookiefile,
          	//CURLOPT_COOKIEFILE	   => $cookiefile,
          	CURLOPT_FOLLOWLOCATION => TRUE,
            CURLOPT_HTTPHEADER     => array("Accept: application/json"),
        );
      	$query=null;
        if (!empty($params)){
          	$query = http_build_query($params, NULL, '&');
            if(isset($params['access_token'])){
                $opts[CURLOPT_HTTPHEADER][] = 'Authorization: Bearer ' . $params['access_token'];
                unset($params['access_token']);
            }
			switch ($method){
                case 'GET':
                	foreach($params as $key => $value){
                    	if(!is_null($value)) $opts[CURLOPT_HTTPHEADER][$key] = $value;
                	}
                    $path .= '?' . http_build_query($params, NULL, '&');
                	//$opts[CURLOPT_HTTPHEADER][] = http_build_query($params, NULL, '&');
                break;
                // Method override as we always do a POST.
                default:
                    $opts[CURLOPT_POSTFIELDS] = $query;
                    
                break;
            }
        }
        $opts[CURLOPT_URL] = $path;
        // Disable the 'Expect: 100-continue' behaviour. This causes CURL to wait
        // for 2 seconds if the server does not support this header.
        if (isset($opts[CURLOPT_HTTPHEADER])){
            $existing_headers = $opts[CURLOPT_HTTPHEADER];
            $existing_headers[] = 'Expect:';
            
            $opts[CURLOPT_HTTPHEADER] = $existing_headers;
        }
        else{
            $opts[CURLOPT_HTTPHEADER] = array('Expect:');
        }
      	($query) ? : $opts[CURLOPT_HTTPHEADER]['Content-length'] = strlen($query);
        curl_setopt_array($ch, $opts);
        $result = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		
        $errno = curl_errno($ch);
        // CURLE_SSL_CACERT || CURLE_SSL_CACERT_BADFILE
        if ($errno == 60 || $errno == 77){
            log::add('naEnergie', 'debug', __FUNCTION__ ." WARNING ! SSL_VERIFICATION has been disabled...\n");
          	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            $result = curl_exec($ch);
        }
		//log::add('naEnergie', 'debug', __FUNCTION__ .' http_code: '.$http_code.'--'.$result);
        	
        if ($result === FALSE){
            log::add('naEnergie', 'debug', __FUNCTION__ .' curl_result = FALSE: ');
        	curl_close($ch);
            //throw $e;
        }
        curl_close($ch);
	
      	
        // Split the HTTP response into header and body.
        list($headers, $body) = explode("\r\n\r\n", $result);
        $rawHeaders = explode("\r\n", $headers);
      	//log::add('naEnergie', 'debug', __FUNCTION__ .' rawHeaders: ' . json_encode($rawHeaders, JSON_UNESCAPED_UNICODE,JSON_PRETTY_PRINT));
        //log::add('naEnergie', 'debug', __FUNCTION__ .' body: ' . $body);
      
      	preg_match('/^HTTP\/1.1 ([0-9]{3,3}) (.*)$/', $rawHeaders[0], $matches);
      	$http_code2 = $matches[1];
      	$http_status = $matches[2];
      
      	log::add('naEnergie', 'debug', __FUNCTION__ .' match_code: '.$http_code2.'--'.$http_status);
        //Only 2XX response are considered as a success
      
        //if(strpos($headers[0], 'HTTP/1.1 2') !== FALSE){
        if(substr($http_code, 0, 1) === '2'){
            $decode = json_decode($body, TRUE);
            if(!$decode){
                $rsp_body=$body;
            } else $rsp_body= $decode;
          	$return['code']= $http_code;
          	$return['body'] = $body; 
          	$return['stat']=$http_status;
          	//$return['headers'] = $rawHeaders;
          	$return['headers'] = $rawHeaders;
        }
        else{
            if(substr($http_code, 0, 1) === '4'){
                //$matches = array("", 400, "bad request");
              	log::add('naEnergie', 'debug', __FUNCTION__ .' error: '.$http_code." bad request ?");
        	}
            $decode = json_decode($body, TRUE);
            if(!$decode){
              	log::add('naEnergie', 'debug', __FUNCTION__ .' !$decode3: '.$http_code.'-'.$http_status .'-'.$path);
        		//throw new NAApiErrorType($matches[1], $matches[2], null);
            }
          	$return['code']= $http_code;
          	$return['body'] = $body;
          	$return['stat']=$http_status;
          	$return['headers'] = $rawHeaders;
          	log::add('naEnergie', 'debug', __FUNCTION__ .' !$decode4: '.$http_code.'-'.$http_status .'-'.$path.'-'.$body);
        		
           // throw new NAApiErrorType($matches[1], $matches[2], $decode);
        }
      	return $return;
    } 

/* *  wRequest  ************************************************************ */
	public static function getheadersVal($headers, $keyhead, $val=''){
		$keyleng=strlen($keyhead);
      	$valleng=strlen($val);
       	foreach ($headers as $entry){
			if (substr($entry, 0, $keyleng) == $keyhead 
                && substr($entry, $keyleng+2, $valleng) == $val){
				$found=substr($entry, $keyleng+2, $valleng);
              	$return=trim(substr($entry, $keyleng+2));
              	if($val=='' && $return) return array($keyhead => $return);
              	$exp=explode(';', $return);
        		if(is_array($exp) && !empty($exp)){
                  	foreach ($exp as $expvalue){
                      //list($key, $fval) = explode('=', trim($expvalue), 2);
                      list($key, $fval) = array_pad(explode('=', trim($expvalue), 2), -2, null);
                      //ll
                      $result[trim($key, "\x1B\x00..\x1F")]=trim($fval, "\x00..\x1F");
                    }
                }
            break;
            }
        }
    	return $result;
    }
 
}
//Fin class  naEnergieGraph extends naEnergie {




?>