# Comment installer ce plugin ?

1. Rendez vous sur la page du market Jeedom et télecharger la dérniere virsion du plugin
![install1](https://raw.githubusercontent.com/limad/plugin-naEnergie/master/images/naEnergie_doc1.PNG)

2. Une fois le plugin installé, il vous faut renseigner vos informations de connexion Netatmo :

Client ID*: votre : client ID (Obtenu sur https://dev.netatmo.com/apps)

Client secret*: Client secret (Obtenu sur https://dev.netatmo.com/apps)

email : l'adresse mail de votre compte Netatmo

Mot de passe : mot de passe de votre compte Netatmo



(*) Pour accéder à L'api Netatmo, il est indispensable d'avoir un compte Netatmo et de créer une application sur https://dev.netatmo.com/apps/createanapp#form 
    vous devez simplement remplir un formulaire pour génerer ces informations(Client ID, Client secret).
    Si vous n'y arrivez pas demandez de l'aides à vos amis !... ;-)

**Cliquer le boutton "Sauvegarder" puis sur "Synchroniser" **: Celà permet de synchroniser Jeedom avec votre compte Netatmo pour découvrir automatiquement vos équipements !! Actualiser la page "touche F5" pour faire apparaitre les équipements.

  
![install3](https://raw.githubusercontent.com/limad/plugin-naEnergie/master/images/naEnergie_doc2.PNG)