# Comment installer ce plugin ?

1. Rendez vous sur la page du market Jeedom et télecharger la dérniere virsion du plugin
![install1](https://raw.githubusercontent.com/limad/plugin-test/master/images/migoThermostat_screenshot12.PNG)

2. Une fois le plugin installé, il vous faut renseigner vos informations de connexion Migo :

email : l'adresse mail de votre compte Migo

Mot de passe : mot de passe de votre compte Migo

Type du Thermostat : Choisir le type tu thermostat installé

**Cliquer sur Synchroniser **: Celà permet de synchroniser Jeedom avec votre compte MiGo pour découvrir automatiquement vos équipements . 

!! A faire après avoir sauvegardé les paramètres précedent.

  
![install3](https://raw.githubusercontent.com/limad/plugin-test/master/images/migoThermostat_screenshot11.PNG)