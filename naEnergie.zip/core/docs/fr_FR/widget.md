# WIDGET

## Voici le **widget standard** pour un thermostat :

![widget1](https://raw.githubusercontent.com/limad/plugin-test/master/images/migoThermostat_screenshot1.PNG)
![widget2](https://raw.githubusercontent.com/limad/plugin-test/master/images/migoThermostat_screenshot2.PNG)
![widget3](https://raw.githubusercontent.com/limad/plugin-test/master/images/migoThermostat_screenshot3.PNG)
**Widget mobile** :
migoScreen8
migoScreen9

	Lors du changement de mode de widget il est conseillé de cliquer sur synchroniser pour voir le resultat immédiatement 