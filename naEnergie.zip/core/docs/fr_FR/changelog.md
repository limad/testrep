# Changelog

Détail complet des mises à jour sur [Historique > Commit](https://limad.github.io/plugin-naEnergie)

Liste des évolutions majeures de la version courante :

* Version 1.1
  * Installation de plugins
  * Mise à jour de plugins
