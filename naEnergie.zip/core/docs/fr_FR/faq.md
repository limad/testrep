# FAQ

## Quelle est la fréquence de rafraichissement ?


	Le systeme recupère les informations toutes les **5 min**.