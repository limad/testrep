<?php
if (!isConnect('admin'))
{
    throw new Exception('{{401 - Accès non autorisé}}');
}
// Déclaration des variables obligatoires
$plugin = plugin::byId('ModbusMonitor');
sendVarToJS('eqType', $plugin->getId());
$eqLogics = eqLogic::byType($plugin->getId());
?>

<div class="row row-overflow">

	<div class="col-xs-12 eqLogicThumbnailDisplay">
		<legend><i class="fas fa-cog"></i>  {{Gestion}}</legend>
		<!-- Boutons de gestion du plugin -->
		<div class="eqLogicThumbnailContainer">
			<div class="cursor pluginAction logoPrimary" data-action="add">
				<i class="fas fa-plus-circle"></i>
				<br>
				<span>{{Ajouter}}</span>
			</div>
			<div class="cursor pluginAction logoSecondary" data-action="gotoPluginConf">
				<i class="fas fa-wrench"></i>
				<br>
				<span>{{Configuration}}</span>
			</div>
			<div class="cursor pluginAction logoSecondary" id="mdTester">
				<i class="fas fa-random"></i>
				<br>
				<span>{{Testeur}}</span>
			</div>
  			<div class="cursor pluginAction logoSecondary"  id="mdScan">
				<i class="fas fa-bars"></i>
				<br
				<span>{{Scan}}</span>
			</div>
  			
  			<div class="cursor pluginAction logoSecondary"  onclick="window.open('https://community.jeedom.com/tag/modbus/l/latest', '_blank')">
				<i class="fas fa-comments"></i>
				<br>
				<span>Community</span>
			</div>
		</div>
		<legend><i class="fas fa-table"></i> {{Eequipements Modbus Monitor}}</legend>
		<?php
if (count($eqLogics) == 0){
    echo '<br/><div class="text-center" style="font-size:1.2em;font-weight:bold;">{{Aucun équipement ModbusMonitor paramétré, cliquer sur "Ajouter" pour commencer}}</div>';
}
else
{
    // Champ de recherche
    echo '<div class="input-group" style="margin:5px;">';
    echo '<input class="form-control roundedLeft" placeholder="{{Rechercher}}" id="in_searchEqlogic"/>';
    echo '<div class="input-group-btn">';
    echo '<a id="bt_resetSearch" class="btn" style="width:30px"><i class="fas fa-times"></i></a>';
    echo '<a class="btn roundedRight hidden" id="bt_pluginDisplayAsTable" data-coreSupport="1" data-state="0"><i class="fas fa-grip-lines"></i></a>';
    echo '</div>';
    echo '</div>';
    // Liste des équipements du plugin
    echo '<div class="eqLogicThumbnailContainer">';
    foreach ($eqLogics as $eqLogic)
    {
        $opacity = ($eqLogic->getIsEnable()) ? '' : 'disableCard';
        echo '<div class="eqLogicDisplayCard cursor ' . $opacity . '" data-eqLogic_id="' . $eqLogic->getId() . '">';
        echo '<img src="' . $plugin->getPathImgIcon() . '"/>';
        echo '<br>';
        echo '<span class="name">' . $eqLogic->getHumanName(true, true) . '</span>';
        echo '</div>';
    }
    echo '</div>';
}
?>
	</div> <!-- /.eqLogicThumbnailDisplay -->

	<!-- Page de présentation de l'équipement -->
	<div class="col-xs-12 eqLogic" style="display: none;">
		<!-- barre de gestion de l'équipement -->
		<div class="input-group pull-right" style="display:inline-flex;">
              <a class="btn btn-sm btn-primary btn-file">  			
                   {{Import JSON}}<input id="bt_TEST" type="file" name="file">        
              </a>
			<span class="input-group-btn">
				<!-- Les balises <a></a> sont volontairement fermées à la ligne suivante pour éviter les espaces entre les boutons. Ne pas modifier -->      				
				<a class="btn btn-sm btn-default eqLogicAction roundedLeft" data-action="configure"><i class="fas fa-cogs"></i><span class="hidden-xs"> {{Configuration avancée}}</span>
				</a><a class="btn btn-sm btn-default eqLogicAction" data-action="copy"><i class="fas fa-copy"></i><span class="hidden-xs">  {{Dupliquer}}</span>
				</a><a class="btn btn-sm btn-success eqLogicAction" data-action="save"><i class="fas fa-check-circle"></i> {{Sauvegarder}}
				</a><a class="btn btn-sm btn-danger eqLogicAction roundedRight" data-action="remove"><i class="fas fa-minus-circle"></i> {{Supprimer}}
				</a>
			</span>
		</div>
		<!-- Onglets -->
		<ul class="nav nav-tabs" role="tablist">
			<li role="presentation"><a href="#" class="eqLogicAction" aria-controls="home" role="tab" data-toggle="tab" data-action="returnToThumbnailDisplay"><i class="fas fa-arrow-circle-left"></i></a></li>
			<li role="presentation" class="active"><a href="#eqlogictab" aria-controls="home" role="tab" data-toggle="tab"><i class="fas fa-tachometer-alt"></i> {{Equipement}}</a></li>
			<li role="presentation"><a href="#commandtab" aria-controls="home" role="tab" data-toggle="tab"><i class="fas fa-list"></i> {{Commandes}}</a></li>
		</ul>
		<div class="tab-content">
			<!-- Onglet de configuration de l'équipement -->
			<div role="tabpanel" class="tab-pane active" id="eqlogictab">
				<!-- Partie gauche de l'onglet "Equipements" -->
				<!-- Paramètres généraux de l'équipement -->
				<form class="form-horizontal">
					<fieldset>
						<div class="col-lg-6">
							<legend><i class="fas fa-wrench"></i> {{Paramètres généraux}}</legend>
							<div class="form-group">
								<label class="col-sm-4 control-label">{{Nom de l'équipement}}</label>
								<div class="col-sm-7">
									<input type="text" class="eqLogicAttr form-control" data-l1key="id" style="display : none;"/>
									<input type="text" class="eqLogicAttr form-control" data-l1key="name" placeholder="{{Nom de l'équipement}}"/>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-4 control-label" >{{Objet parent}}</label>
								<div class="col-sm-7">
									<select id="sel_object" class="eqLogicAttr form-control" data-l1key="object_id">
										<option value="">{{Aucun}}</option>
										<?php
$options = '';
foreach ((jeeObject::buildTree(null, false)) as $object)
{
    $options .= '<option value="' . $object->getId() . '">' . str_repeat('&nbsp;&nbsp;', $object->getConfiguration('parentNumber')) . $object->getName() . '</option>';
}
echo $options;
?>
									</select>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-4 control-label">{{Catégorie}}</label>
								<div class="col-sm-7">
									<?php
foreach (jeedom::getConfiguration('eqLogic:category') as $key => $value)
{
    echo '<label class="checkbox-inline">';
    echo '<input type="checkbox" class="eqLogicAttr" data-l1key="category" data-l2key="' . $key . '" />' . $value['name'];
    echo '</label>';
}
?>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-4 control-label">{{Options}}</label>
								<div class="col-sm-7">
									<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="isEnable" checked/>{{Activer}}</label>
									<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="isVisible" checked/>{{Visible}}</label>
								</div>
							</div>
                            <br/>
  					
                            <br>
							<legend><i class="fas fa-wrench"></i> {{Parametres Modbus}}</legend>
  							<div class="col-lg-10" id="div_paramsrtu" style="display:none;">
                                         
  
 	<form class="form-horizontal">
                                          <fieldset>
                                               

				<div class="form-group" id="choiceMod">
						<label class="col-sm-5 control-label" >{{Type Modbus}}</label>
						<div class="col-lg-6">
							<select id="connectType" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="connectType">
								 <option value="TCP">{{TCP}}</option>
								 <option value="RTU">{{Modbus RTU}}</option>
						 	</select>
						</div>
					</div>
  
  
  				<div class="form-group" id="gatwayIp" style="display:none;">
                                                   <label class="col-sm-5 control-label" >{{Ip Device}}</label>
                                                   <div class="col-lg-6">
                                                        <input type="text" id="gatwayIp" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="gatwayIp">
                                                   </div>
                                               </div>
					 <div class="form-group" id="slaveId" style="display:none;">
								<label class="col-sm-5 control-label" >{{Unit ID}}</label>
								<div class="col-lg-6">
										 <input type="text" id="slaveId" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="slaveId">
									        
								</div>
						               <label class="col-sm-5 control-label" >{{Port (optionnel) Defaut 502}}</label>
								<div class="col-lg-6">
									
									          <input type="text" id="gatwayPort" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="gatwayPort" placeholder="502 par defaut">
								</div>
						</div>


  <div class="form-group" id="choiceOffset">
						<label class="col-sm-5 control-label" >{{Registre Offset}}</label>
						<div class="col-lg-6">
							<select id="connectType" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="Offset">
								<option value="0" id="noOffset" selected="">No Offset</option>
								<option value="-1" id="offsetMinus">Offset -1</option>
								<option value="1" id="offsetPlus">Offset +1</option>
						 	</select>
						</div>
					</div>
  
  
                                         <div class="form-group" id="div-portserial" style="display:none;">
                                                    <label class="col-sm-5 control-label">{{Port Série}}</label>
                                                    <div class="col-lg-6">
                                                        <select class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="portserial">
                                                            <?php
foreach (jeedom::getUsbMapping('', true) as $name => $value)
{
    echo '<option value="' . $value . '">' . $name . ' (' . $value . ')</option>';
}
?>
                                                        </select>
                                                    </div>
                                           </div>

                                          <div class="form-group" id="div-baudrate"  style="display:none;">
                                               <label class="col-sm-5 control-label">{{Baudrate}}</label>
                                               <div class="col-lg-6">
                                                      <select id="baudrate" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="baudrate">
                                                          <option value="300">300</option>
                                                          <option value="600">600</option>
                                                          <option value="1200">1200</option>
                                                          <option value="2400">2400</option>
                                                          <option value="4800">4800</option>
                                                          <option value="9600">9600</option>
                                                          <option value="14400">14400</option>
                                                          <option value="19200">19200</option>
                                                          <option value="38400">38400</option>
                                                          <option value="56000">56000</option>
                                                          <option value="57600">57600</option>
                                                          <option value="115200">115200</option>
                                                          <option value="128000">128000</option>
                                                          <option value="230400">230400</option>
                                                          <option value="256000">256000</option>
                                                      </select>
                                               </div>
                                          </div>
                                              <div class="form-group" id="div-parity"  style="display:none;">
                                                  <label class="col-sm-5 control-label">{{Parité}}</label>
                                                  <div class="col-lg-6">
                                                      <select id="parity" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="parity">
                                                          <option value="N">{{Aucune}}</option>
                                                          <option value="E">{{Paire}}</option>
                                                          <option value="O">{{Impaire}}</option>
                                                      </select>
                                                  </div>
                                              </div>
                                           <div class="form-group" id="div-bytesize"  style="display:none;">
                                                <label class="col-sm-5 control-label">{{Taille de l octet}}</label>
                                                <div class="col-lg-6">
                                                    <select id="bytesize" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="bytesize">
                                                        <option value="7">{{7 Data Bits}}</option>
                                                        <option value="8">{{8 Data Bits}}</option>
                                                    </select>
                                                </div>
                                           </div>
                                             <div class="form-group" id="div-stopbits"  style="display:none;">
                                                  <label class="col-sm-5 control-label">{{Bit de fin}}</label>
                                                  <div class="col-lg-6">
                                                      <select id="stopbits" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="stopbits">
                                                          <option value="1">{{1 Stop Bit}}</option>
                                                          <option value="1.5">{{1.5 Stop Bits}}</option>
                                                          <option value="2">{{2 Stop Bits}}</option>
                                                      </select>
                                                  </div>
                                              </div>
						<div class="form-group" id="div-unitid"  style="display:none;">
								 <label class="col-sm-5 control-label">{{Unit ID}}</label>
								 <div class="col-lg-6">
									 <input type="number" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="unitID"/>
								 </div>
						</div>
  
  						<div class="form-group" style="">
								 <label class="col-sm-5 control-label">{{Testeur}}</label>
								 <div class="col-lg-6">
									  <a class="btn btn-sm btn-warning col-sm-6" id="bt_ModbusMonitorDoct">ModbusTester</a>
								     <div id="md_modalTest" style="overflow-x: hidden; display: none;"></div>
								 </div>
						</div>
  
 
						</fieldset>
					</form>
                                       </div>
				         </div>

						<!-- Partie droite de l'onglet "Équipement" -->
						<!-- Affiche l'icône du plugin par défaut mais vous pouvez y afficher les informations de votre choix -->
						<div class="col-lg-6">
							<legend><i class="fas fa-info"></i> {{Informations}}</legend>
							<div class="form-group">
								<div class="text-center">
									<img name="icon_visu" src="<?=$plugin->getPathImgIcon(); ?>" style="max-width:160px;"/>
								</div>

								<legend><i class="fas fa-tasks"></i> {{Choisir les commandes}} <sub id="selectCmdsNumber"></sub> </legend>
									<div style="padding-Left:10%;" class="form-group">
											<label class="control-label col-sm-4">{{Sélectionner les commandes}}</label>
												<div class="col-sm-6">
														<input type="text" class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="selectedCmdIds" style="display:none">
														<a class="btn btn-primary col-sm-12" id="cmdsList" title="{{Liste des commandes à exporter}}"><i class="fas fa-chart-line"></i> {{Liste des commandes à exporter}}</a>
												</div>
									</div>
									<div style="padding-Left:10%;" class="form-group">
									  	<label class="control-label col-sm-4">{{Commandes sélectionnées}}</label>
											<div class="col-sm-6">
												<div class="col-sm-12" id="selectedCmds"></div>
											</div>
					    			</div>
								<a class="btn btn-success col-sm-6" id="exportCmds" title="{{Export du Json}}" data-action="cmdexport" style="margin-Top:20px;">{{Telecharger Configs des commandes}}</a>
								
					   	</div>
							</div>

					</fieldset>
				</form>
				<hr>
			</div><!-- /.tabpanel #eqlogictab-->

			<!-- Onglet des commandes de l'équipement '-->
			<div role="tabpanel" class="tab-pane" id="commandtab">
				<div class="input-group pull-right" style="display:inline-flex;margin-top:5px;">
					<span class="input-group-btn">
						<a class="btn btn-info btn-xs roundedLeft" id="bt_addCmdInfo"><i class="fas fa-plus-circle"></i> {{Ajouter une info}}</a>
                        <a class="btn btn-warning btn-xs roundedRight" id="bt_addCmdAction"><i class="fas fa-plus-circle"></i> {{Ajouter une action}}</a>
					</span>
				</div>
                          
				<br/><br/>
				<div class="table-responsive">
					<legend class="success"><i class="fa fa-list-alt"></i>  {{Commandes Infos}}</legend>
      				<table id="table_cmd_infos" class="table_cmd table table-bordered table-condensed">
						<thead>
							<tr>
								<th style="width: 80px;">Id</th>
								<th style="min-width: 140px;width: 320px;">Nom</th>
								<th style="min-width: 100px;width: 100px;">Type</th>
								<th style="width: 100px;">Options</th>
								<th style="min-width: 200px;width: 200px;">Type I/O</th>
								<th style="">Parametres</th>
								<th style="min-width: 160px;width: 160px;">Etat</th>
								<th style="width: 120px;min-width: 120px;">Action</th>
                                <th style="width: 130px;max-width: 100px;"></th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
  
  					<legend class="success"><i class="fa fa-list-alt"></i>  {{Commandes Actions}}</legend>
      				<table id="table_cmd_actions" class="table_cmd table table-bordered table-condensed">
						<thead>
							<tr>
								<th style="width: 80px;">Id</th>
								<th style="min-width: 140px;width: 320px;">Nom</th>
								<th style="min-width: 100px;width: 100px;">Type</th>
								<th style="width: 100px;">Options</th>
								<th style="min-width: 200px;width: 200px;">Type I/O</th>
								<th style="">Parametres</th>
								<th style="min-width: 160px;width: 160px;">Etat</th>
								<th style="width: 120px;min-width: 120px;">Action</th>
                                <th style="width: 130px;max-width: 100px;"></th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table><!-- End table actions-->
  
				</div>
			</div><!-- /.tabpanel #commandtab-->

		</div><!-- /.tab-content -->
	</div><!-- /.eqLogic -->
</div><!-- /.row row-overflow -->

<script>

$('#mdScan').click(function(){
  	console.log(" mdTester ");
    window.open("/index.php?v=d&m=ModbusMonitor&p=scan.ModbusMonitor", "_blank");
});

$('#mdTester').click(function(){
  	console.log(" mdTester ");
    window.open("/index.php?v=d&m=ModbusMonitor&p=test.ModbusMonitor", "_blank");
});

$('#bt_importJson').click(function(){
    $('#bt_importJsonbtn').click();
});

  var eqLogicIdimport = $('.eqLogicAttr[data-l1key=id]').value(); 
  
    $('#bt_importJsonbtn').fileupload({
      dataType: 'json',
      replaceFileInput: false,
      url: 'plugins/ModbusMonitor/core/ajax/ModbusMonitor.ajax.php?action=importJson&eqId=' +eqLogicIdimport,
      done: function (e, data) {
                if (data.result.state != 'ok') {
                  console.log(data.result)
                    $('#div_alert').showAlert({message: data.result.result, level: 'danger'});
                    return;
                }

                $('#div_alert').showAlert({message: '{{Fichier(s) ajouté(s) avec succès}}', level: 'success'});
            }
   });
  
  
  
  
 </script>

<!-- Inclusion du fichier javascript du plugin (dossier, nom_du_fichier, extension_du_fichier, id_du_plugin) -->
<?php include_file('desktop', 'ModbusMonitor', 'js', 'ModbusMonitor'); ?>
<!-- Inclusion du fichier javascript du core - NE PAS MODIFIER NI SUPPRIMER -->
<?php include_file('core', 'plugin.template', 'js'); ?>