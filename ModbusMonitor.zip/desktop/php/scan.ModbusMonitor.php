<?php
/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

if (!isConnect('admin')) {
	throw new Exception('401 Unauthorized');
}

$eqLogic = null;
if(init('id') != ""){
  $eqLogic_id = init('id');
  $eqLogic = ModbusMonitor::byId($eqLogic_id);
  
}
sendVarToJs('eqLogic_id', init('id'));


$tcpport = $eqLogic ? $eqLogic->getConfiguration('tcpport') : 502;
$gatwayIp =  $eqLogic ? $eqLogic->getConfiguration('gatwayIp') : "192.168.1.184";
$slaveId =  $eqLogic ? $eqLogic->getConfiguration('slaveId') : "215";
  


if ($lastValueDate == false) {
	$lastValueDate = date('Y-01-01');
}else $lastValueDate = date('Y-m-d', strtotime($lastValueDate));



?>
<div id='div_alertSetPulse' style="display: none;"></div>

	
 
    </br>
<!-- ************************** -->
      <div class="col-lg-12 col1">
        <div class="panel panel-info" id="div_connect">
          <div class="panel-heading" style="height: 30px;">
            <h3 class="panel-title" style="margin-top: -6px;"><i class="fas fa-circle-notch"></i> Passerelle</h3>
          </div>
          <div class="panel-body">
 
       
       
            <div id="div_plugin_toggleState">
       			<form class="form-horizontal">
       			<fieldset>
      		<!-- Type Modbus *********************************  -->
       		<div class="form-group" id="choice_connectType">
			<!-- Type TCP/UDP*********************************  -->
       			<div class="col-sm-2">
                    <select class="eqLogicAttr form-control" id="connectType">
                        <option value="TCP" selected>TCP</option>
                        <option value="UDP">UDP</option>
       					<option value="RTU" disabled="">RTU</option>
                    </select>
				</div>
       		<!-- Ip *********************************  -->
       			<div class="col-sm-4">
					<input type="text" class="eqLogicAttr form-control" id="gatwayIp" placeholder="192.168.1.2" value="<?php echo $gatwayIp;?>" >
				</div>
       		<!-- Port *********************************  -->
       			<label class="col-sm-1 control-label">Port</label>
				<div class="col-sm-2">
					<input type="text" class="eqLogicAttr form-control" id="gatwayPort" value="<?php echo $tcpport;?>" placeholder="502" >
				</div>
       			<div class="col-sm-2">
                    <a class="btn btn-success btn-sm pull-right connectTcp" id="bt_connect">
       					<i class="fas fa-share"></i> Connction</a>
       			</div>
                <div class="col-sm-1">
                    <span class="label label-success"></span>
                </div>
			</div>
       		
       		
       	</div>
        </div>
      </div>
      		     
      </div>
       <!-- Fin col-lg-12  col1 -->
        
       

<style>	
	
	table.tablecmdtest > tbody:nth-child(2) > tr:nth-child(1), table.tablecmdtest > thead > tr{
  		background-color: transparent !important;;
	}
	div#div_cmd.panel {
		min-height: 20em;

	}
</style>
<!-- ************************** -->
       
      <!-- ************************** -->      
  <div class="form-group col-lg-12 col2">
       <!-- ************************** -->        
		
		  

 <div class="panel panel-success" id="div_cmd">
		<div class="panel-heading" style="height: 30px;">
            <h3 class="panel-title" style="margin-top: -6px;"><i class="fas fa-circle-notch"></i> Test Commande</h3>
		</div>
		<div class="panel-body">
 
       
       
            
        <fieldset>
       
       
       <table id="" class="table tablecmdtest" style="">
						<thead>
							
								<th style="width: 60px;">SalveId</th>
								<th style="min-width: 60px;width: 80px;">Register</th>
								<th style="min-width: 60px;width: 80px;">Longueur</th>
								<th style="width: 180px;">Type</th>
								<th style="/*! min-width: 200px; *//*! width: 120px; */">Format</th>
								<th style="width: 80px;">Operation</th>
								<th style="min-width: 160px;width: 160px;">Inversion</th>
							
		</thead>
		<tbody>
       	<tr>
			<td style="width: 60px;">
				<input class="form-control input-sm slaveId" placeholder="215" id="slaveId" style="margin-top: 2px" value="215">
			</td>
       
			<td style="min-width: 60px;width: 80px;">
				<input class="form-control input-sm startregister" placeholder="Registre départ" id="startregister" style="margin-top: 2px" value="50000">
  							<input class="form-control input-sm endregister" placeholder="Registre fin" id="endregister" style="margin-top: 2px" value="50004">
			</td>
       
			<td style="min-width: 60px;width: 80px;">
				<input class="form-control input-sm nbregister" id="nbregister" placeholder="Nb de bytes" style="margin-top: 2px;">
			</td>
       
			<td style="width: 180px;">
				<select class="form-control input-sm functionCode" id="functionCode" style="font-weight:bold;">
					<option value="fc01" class="readOption" id="fc01">Coils status Fc1</option>
					<option value="fc02" class="readOption" id="fc02">Discrete status Fc2</option>
					<option value="fc03" class="readOption" id="fc03" selected="">Holding Registers Fc3</option>
					<option value="fc04" class="readOption" id="fc04">Input Registers Fc4</option>
				</select>
			</td>
       
			<td style="min-width: 80px;width: 80px;">
				<select class="form-control input-sm attendedFormat" id="attendedFormat" style="margin-top: 2px;font-weight:bold;">
					<option value="longformat" class="longformat" selected="">Integer</option>
					<option value="floatformat" class="floatformat">Float</option>
					<option value="bitsformat" class="bitsformat">Bits</option>
					<option value="stringformat" class="stringformat">String</option>
					<option value="noneformat" class="noneformat">Decimal</option>
					<option value="hexaformat" class="hexaformat">HexaDecimal</option>
  					<option value="binaryformat" class="binaryformat">Binary</option>
  				</select>
       		</td>
       		<td style="width: 80px;">
				<input class="form-control input-sm operation" placeholder="/100" id="operation" style="margin-top: 2px">
			</td>
			<td style="min-width: 160px;width: 160px;">
				<input type="checkbox" class="cmdAttr wordReverse" id="wordReverse" checked="" style="">Word
  				<input type="checkbox" class="cmdAttr byteReverse" id="byteReverse" style="">Byte 
				<input type="checkbox" class="cmdAttr unsigned" id="unsigned" style="">Unsigned 
			</td>
			

		</tr>
		</tbody>
		</table>
       	</fieldset>
  		<div class="form-group col-lg-11 col3">
  			<a class="btn btn-info btn-sm pull-right connectTcp" data-action="read" id="bt_scan"><i class="fas fa-share"></i> Scan</a>
       	</div><!--col3 -->
  		
  		<div class="form-group col-lg-11 col4 resultCmd" id="resultCmd">
  		</div><!--col4 -->
 
</div><!-- panel-body -->  
</div><!-- panel -->               
 </div><!-- col2 -->           
		
  		               

  
       
  <script>
    function getConfig(){
       console.log("getConfig()  start" );
		var gatwayIp = $('#gatwayIp').value(); 
        var gatwayPort = $('#gatwayPort').value();
        if (gatwayIp == '' ){
          	$('#div_alert').showAlert({ message: 'Ip Adress is mandatory', level: 'warning' })
			console.error("Ip is mandatory");
			return;
        }
       	else if (gatwayPort == ''){
            gatwayPort = '502';
			$('#gatwayPort').value(gatwayPort);
           	console.log("port set to 502");
			//$('#div_alert').showAlert({ message: 'Ip Adress is mandatory', level: 'success' })
			//return;
        }
        var connectType = $('#connectType').value();
        var config = {
          connectType:connectType, 
          gatwayIp:gatwayIp,
          gatwayPort:gatwayPort 
        };
      	return config;
       
    }
    $('#bt_connect').on('click', function () {
		console.log("bt_connect:  " );
		var config = getConfig();
        console.log("config: "+ JSON.stringify(config));
      	$.ajax({
			type: "POST",
			url: "plugins/ModbusMonitor/core/ajax/ModbusMonitor.ajax.php",
			dataType: 'json',
			data: {
				action: 'connectGateway',
				eqLogic_id : eqLogic_id,
              	dataj: config,
            },
			error: function (request, status, error) {
				handleAjaxError(request, status, error,$('#div_alertSetPulse'));
			},
			success: function (data) {
				if (data.state != 'ok') {
					$('#div_alertSetPulse').showAlert({message: "{{Connecting Gateway failled}} " + data.result, level: 'danger'});
					return;
				}
				$('#div_alertSetPulse').showAlert({message: '{{Connecting Gateway success}}', level: 'success'});
              	//location.reload();
            }
		});                
                        
    })
    
       
	$('#bt_scan').on('click', function () {
      	console.log("bt_scan:  " );
		var config = getConfig();
        var startregister = $('#startregister').value();
      	var endregister  = $('#endregister').value();
        var nbregister = $('#nbregister').value();
		var slaveId = $('#slaveId').value();
        if (slaveId == '' ){
			console.error("bt_scan::slaveId adress is mandatory");
			$('#div_alert').showAlert({ message: 'Register adress is mandatory', level: 'warning' })
			return;
        }else if (startregister == '' ){
			console.error("bt_scan::Register start adress is mandatory");
			$('#div_alert').showAlert({ message: 'Register adress is mandatory', level: 'warning' })
			return;
        }else if (endregister == '' ){
			console.error("bt_scan::Register end adress is mandatory");
			$('#div_alert').showAlert({ message: 'Register adress is mandatory', level: 'warning' })
			return;
        }
      	if (nbregister == '' ){
          nbregister = 1;
        }
        /*var gatwayPort  = $('#gatwayPort').value();            
        var functionCode = $('#functioncode').value();
        var attendedFormat = $('#attendedFormat').value();
        var endianess = $('#endianess').value();*/
      	//var endianess = false;
      	//if($('#endianess').prop('checked') == "1") endianess = true;
      
      var cmdParams = {
            slaveId: slaveId,
            startregister: startregister,
            endregister: endregister,
            nbregister: nbregister,            
            functionCode: $('#functionCode').value(),
            attendedFormat: $('#attendedFormat').value(),
            operation: $('#operation').value(),
            unsigned: $('#unsigned').value(),
            byteReverse: $('#byteReverse').value(),
        	wordReverse: $('#wordReverse').value(),
        };
      	config.cmdParms = cmdParams;
      	console.log("bt_scan::config: "+ JSON.stringify(config));
      	$('.resultCmd').empty();
				
      	$.ajax({
			type: "POST",
			url: "plugins/ModbusMonitor/core/ajax/ModbusMonitor.ajax.php",
			dataType: 'json',
			data: {
				action: 'scanRegs',
				//eqLogic_id : eqLogic_id,
              	dataj: config,
            },
			error: function (request, status, error) {
				handleAjaxError(request, status, error,$('#div_alertSetPulse'));
			},
			success: function (data) {
				if (data.state != 'ok') {
					$('#div_alertSetPulse').showAlert({message: "{{Reading command failled}} " + data.result, level: 'danger'});
					return;
				}
				//$('#div_alertSetPulse').showAlert({message: '{{Reading command success}}', level: 'success'});
              	var cmdResult = data.result;
				console.log("bt_scan::data: "+ JSON.stringify(data.result));
              	var items = [];
				$.each( cmdResult, function( key, val ) {
					if($.isArray(val)){
                      	 items.push( "<li id='" + key + "'>" + key + " : <strong>[" + val + "]</strong></li>" );
                    }else{
                      items.push( "<li id='" + key + "'>" + key + " : <strong>" + val + "</strong></li>" );
                    }
				});
 				$( "<ul/>", {"class": "listCmdResult",html: items.join( "" )}).appendTo( ".resultCmd" );  
              	//location.reload();
            }
		}); 
                     
    })   
       

/////////////////////////////////////////////////
    $('#in_value').on('keyup',function(){
		let indexVol_cible = parseFloat($('#in_value').value().replace("#unite#", "").replace(" ", "")).toFixed(2);
    	if (isNaN(indexVol_cible)){
			//console.error("keyup:: La valeur saisie n'est pas un nombre : " + indexVol_cible);
			$(this).value('');
			return;
        }
		$('#in_value').value(parseInt(($('#in_value').value()) * 1000)/1000);//(parseFloat($('#in_value').value()) - step).toFixed(3)
        $('#in_value').trigger('change')
    })
    
/////////////////////////////////////////////////////////////////////////////
    $('#in_value').on('change', function () {
      if (typeof timerHandle !== 'undefined') {
        clearTimeout(timerHandle)
      }
      timerHandle = setTimeout(function() {
        var indexVol_cible = parseFloat($('#in_value').value().replace("#unite#", "").replace(" ", ""));
        	
        if (isNaN(indexVol_cible)){
			console.error("change:: La valeur saisie n'est pas un nombre : " + indexVol_cible);
			$('#new_indexPulseAdd').empty();
			$('#indexPulse_cible').empty();
			$('#indexVol_cible').empty();
			$('#basepulse_r').empty();
          	$('#result').hide();
			return;
        }
        console.log("change:: indexVol_cible:  " + indexVol_cible);        
      	var	basepulse = parseInt($('#basepulse').value());
        		console.log("basepulse:  " + basepulse);
        
        var	pulseRatio = parseFloat("<?php echo $pulseRatio; ?>").toFixed(2);
        		console.log("pulseRatio:  " + pulseRatio);
		
        var indexPulse_cible = parseInt(indexVol_cible * pulseRatio);
        	console.log("indexPulse_cible:  " + indexPulse_cible);
        
        var new_indexPulseAdd = indexPulse_cible - basepulse;
      			console.log("old_indexPulseAdd:  " + new_indexPulseAdd);
        
        var old_indexPulseAdd = parseInt($('#indexPulseAdd').value());
      			console.log(" * indexPulseAdd ***   " + old_indexPulseAdd +" => " + new_indexPulseAdd);
		
        var old_indexVol = $('#now_IndexVol').value();
        		console.log(" * IndexVol ***   " + old_indexVol +" => " + indexVol_cible);
        
        
        $('#new_indexPulseAdd').value(new_indexPulseAdd);
      		$('#result').show();
        	$('#indexPulse_cible').value(indexPulse_cible);
      		$('#indexVol_cible').value(indexVol_cible.toFixed(2));
      		$('#basepulse_r').value(basepulse);
        	$('#bt_save_eq').removeClass('disabled');
        
        
        	//$('#indexVol_cible').value($('#in_value').value().replace("#unite#", "").replace(" ", ""));
        //jeedom.cmd.execute({id:'#id#', value: {slider: $('#in_value').value().replace("#unite#", "").replace(" ", "")}})
      }, 500)
    })
	 
    /*jeedom.cmd.addUpdateFunction('#id#',function(_options) {
      $('#in_value').value(_options.display_value+' #unite#')
    });
    jeedom.cmd.refreshValue([{cmd_id :'#id#',display_value: '#state#', valueDate: '#valueDate#', collectDate: '#collectDate#', alertLevel: '#alertLevel#', unit: '#unite#'}])*/

     
	$('#bt_save_eq').on('click',function(){
      	var indexVol_cible = $('#indexVol_cible').value();
    	var config = {
          //indexPulse_cible:$('#indexVol_cible').value(), 
          indexPulseAdd:$('#new_indexPulseAdd').value(),
          PulseAdd_date:new Date().toLocaleString().replaceAll("/", "-"), 
        };
      	console.log("bt_save_eq:: indexVol_cible:  " + indexVol_cible );
		$.ajax({
			type: "POST",
			url: "plugins/ModbusMonitor/core/ajax/ModbusMonitor.ajax.php",
			dataType: 'json',
			data: {
				action: 'setEqConfig',
				eqLogic_id : eqLogic_id,
              	dataj: config,
              	configKey : 'indexVolCible',
              	value : indexVol_cible
            },
			error: function (request, status, error) {
				handleAjaxError(request, status, error,$('#div_alertSetPulse'));
			},
			success: function (data) {
				if (data.state != 'ok') {
					$('#div_alertSetPulse').showAlert({message: "save_eq " + data.result, level: 'danger'});
					return;
				}
				$('#div_alertSetPulse').showAlert({message: '{{Ajout réussi}}', level: 'success'});
              	location.reload();
            }
		});
	});

    $("#choiceModbusMonitor").on('change', function() {
        console.log('choiceModbusMonitor: ');
        var typeModbus = $("#choiceModbusMonitor").val();
        if(typeModbus == 'TCP'){
             $("#div_paramsrtu").show();
             $("#gatwayIp").show();
             $("#div-bytesize").hide();
             $("#div-baudrate").hide();
             $("#div-stopbits").hide();
             $("#div-parity").hide();
             $("#div-portserial").hide();
             $("#div-slaveId").hide();
             $("#slaveId").show();



            /* $("#paramsrtu").hide(); */
        }
        else if(typeModbus == 'RTU'){
                /* $("#paramsrtu").show();*/
             $("#div_paramsrtu").show();
             $("#gatwayIp").hide();
             $("#div-bytesize").show();
             $("#div-baudrate").show();
            $("#div-stopbits").show();
            $("#div-parity").show();
            $("#div-portserial").show();
            $("#div-slaveId").show();
            $("#slaveId").hide();
        }
        else if(typeModbus == 'ascii'){
            $("#div_paramsrtu").show();
            $("#gatwayIp").hide();
            $("#div-bytesize").show();
            $("#div-baudrate").show();
            $("#div-stopbits").show();
            $("#div-parity").show();
            $("#div-portserial").show();
            $("#div-slaveId").show();
        }
    });

</script>