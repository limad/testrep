
/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */


/* Permet la réorganisation des commandes dans l'équipement */
$("#table_cmd_infos, #table_cmd_actions").sortable({
  axis: "y",
  cursor: "move",
  items: ".cmd",
  placeholder: "ui-state-highlight",
  tolerance: "intersect",
  forcePlaceholderSize: true
});


$('.eqLogicAttr[data-l1key=configuration][data-l2key=type]').on('change', function () {
	let configType = $(this).value();
	let arrayConfig = configType.split('_');
	console.log('type: ' + configType);
	if($(this).value() != '' && $(this).value() != null && $(this).value() != 'none'){
		$('.img_device').attr("src", 'plugins/ModbusMonitor/data/manufacturers/'+arrayConfig[0]+'/'+arrayConfig[1]+'.png');
	}else{
		$('.img_device').attr("src", 'plugins/ModbusMonitor/plugin_info/ModbusMonitor_icon.png');
	}
});

$('.eqLogicAttr[data-l2key=selectedCmdIds]').on('change', function() {
	console.log('selectedCmdIds: ');
	$('#selectedCmds').empty()
	if ($(this).value() != '') {
		let selectedIdsArray = $(this).value().split(',')
		$('#selectCmdsNumber').html('(' + selectedIdsArray.length + ')')
		for (var i in selectedIdsArray) {
			jeedom.cmd.getHumanCmdName({
              id: selectedIdsArray[i],
              error: function(error) {
                  $('#div_alert').showAlert({ message: error.message, level: 'danger' })
              },
              success: function(data) {
              $('#selectedCmds').append('<span class="label label-info cursor cmdAdvanceConfigure" style="display:flex;flex-direction:column;" data-cmd_id="' + selectedIdsArray[i] + '">' + data.replace(/#/g, '') + '</span> ')
              $('#exportCmds').show();

			}
      		})
    	}
	}
	else {
    	$('#selectedCmds').append('<div class="alert alert-warning" style="text-align:center;">{{Aucune commande sélectionnée}}</div>');
    	$('#exportCmds').hide();
	}
});


$('#bt_ModbusMonitorDoct').on('click', function () {
	let eqid = $('.eqLogicAttr[data-l1key=id]').value();
	let url = 'index.php?v=d&plugin=ModbusMonitor&modal=test.ModbusMonitor&id='+eqid
	$('#md_modalTest').dialog({
            title: "{{Testeur ModbusMonitor}}",
            closeText: '',
            autoOpen: false,
            modal: true,
            minHeight: 400,
            height: 500,
            minWidth: 1024,
            width: 1024,
            position: { my: 'top', at: 'top+150' },
            open: function () {
              $("body").css({overflow:'hidden', display:'block'});
            },
            beforeClose: function (event, ui) {
              $("body").css({overflow: 'inherit'});
            }
    }).load(url).dialog('open')
   
});

$('#bt_ModbusMonitorDoct1').on('click', function() {
  	console.log('bt_ModbusMonitorDoct: ');
	let eqid = $('.eqLogicAttr[data-l1key=id]').value();
	//let url = 'index.php?v=d&plugin=ModbusMonitor&modal=test.ModbusMonitor&id='+eqid;
	let url = 'index.php?v=d&plugin=ModbusMonitor&modal=test.ModbusMonitor&id='+eqid;
	$('#md_modal').dialog({ 
    	title: "{{Testeur ModbusMonitor}}" 
	}).load(url).dialog('open')
});

function printEqLogic(_eqLogic){
	$('#bt_TEST').fileupload({
        dataType: 'json',
        replaceFileInput: false,
        url: 'plugins/ModbusMonitor/core/ajax/ModbusMonitor.ajax.php?action=importJson&id=' + _eqLogic.id+'&jeedom_token='+JEEDOM_AJAX_TOKEN,
        done: function (e, data) {
            if (data.result.state != 'ok') {
              console.log(data.result)
                  $('#div_alert').showAlert({message: data.result.result, level: 'danger'});
                return;
            }
			$('#div_alert').showAlert({message: '{{Fichier(s) ajouté(s) avec succès}}', level: 'success'});
            location.reload();
		}
	});

}


$('#validateProfil').on('click', function() {
	bootbox.confirm('{{Etes-vous sûr de vouloir charger un modele ? Cela supprimera les commandes actuelles }}',
	function (result) {
		if (result) {
			$.ajax({
                type: "POST",
                url: "plugins/ModbusMonitor/core/ajax/ModbusMonitor.ajax.php",      
                data: {
					action: "testConstruct",
					eqId : $('.eqLogicAttr[data-l1key=id]').value(),
					choice : $('.eqLogicAttr[data-l1key=configuration][data-l2key=type]').value()
                },
                dataType: 'json',
                error: function(request, status, error) {
                        handleAjaxError(request, status, error, $('#div_alert'))
                      },
                success: function(data) {
                    if (data.state != 'ok') {
                      $('#div_alert').showAlert({ message: data.result, level: 'danger' })
                      return
                    }
                    $('#validateProfil').removeClass('btn-primary');
                    $('#validateProfil').addClass('btn-success');
                    $('#validateProfil').text('Validé');                 
                    $('#div_alert').showAlert({ message: 'Modele enregistre avec succes, vous pouvez actualisé la page', level: 'success' })
                   
                  }
			})
          // location.reload()
		}
	});
});

$('#exportCmds').on('click', function() {
  let eqLogicId = $('.eqLogicAttr[data-l1key=id]').value()
  let selectedIdsArray = $('.eqLogicAttr[data-l2key=selectedCmdIds]').value().split(',')
  $.ajax({
    type: "POST",
    url: "plugins/ModbusMonitor/core/ajax/ModbusMonitor.ajax.php",
    data: {
      action: "exportCmd",
      eqId: eqLogicId,
      cmds: selectedIdsArray
    },
    dataType: 'json',
    error: function(request, status, error) {
      handleAjaxError(request, status, error, $('#div_alert'))
    },
    success: function(data) {
          window.open('core/php/downloadFile.php?pathfile=plugins/ModbusMonitor/data/cmdsModbus.json')
      if (data.state != 'ok') {
        $('#div_alert').showAlert({ message: data.result, level: 'danger' })
        return
      }

    }
  })
})

$('#cmdsList').on('click', function() {
  console.log('cmdsList: ');
	
  $('#md_modal').dialog({ title: "{{Liste des commandes à exporter}}" }).load('index.php?v=d&plugin=ModbusMonitor&modal=exportCmds.list&eqLogic='+$('.eqLogicAttr[data-l1key=id]').val()).dialog('open')
})

$("#table_cmd_infos tbody, #table_cmd_actions tbody").delegate(".cmdAttr[data-l2key=defCmd]", 'change', function (event) {
  console.log('defCmd: '+ $(this).value());
  var cmdNb = $(this).value();
  if (cmdNb == '4') {
    $(this).closest('tr').find('.isnegatif').hide();
    $(this).closest('tr').find('.functionCode').prop('disabled', 'disabled');
  }
  if (cmdNb == '1') {
    $(this).closest('tr').find('.isnegatif').hide();
    $(this).closest('tr').find('.functionCode').prop('disabled', 'disabled');
    $(this).closest('tr').find('.wordReverse').show();
    $(this).closest('tr').find('.byteReverse').show();
    $(this).closest('tr').find('.unsigned').show();
    $(this).closest('tr').find('.nbregister').val('1');
    $(this).closest('tr').find('.nbregister').prop('disabled', 'disabled');
    
  }
  if (cmdNb == '2') {
    $(this).closest('tr').find('.isnegatif').hide();
    $(this).closest('tr').find('.functionCode').prop('disabled', 'disabled');
    $(this).closest('tr').find('.wordReverse').hide();
    $(this).closest('tr').find('.byteReverse').hide();
    $(this).closest('tr').find('.unsigned').hide();
  }
  if (cmdNb == '3') {
    $(this).closest('tr').find('.isnegatif').hide();
    $(this).closest('tr').find('.functionCode').hide();
    $(this).closest('tr').find('.offset').hide();
    $(this).closest('tr').find('.stepchoice').hide();
    $(this).closest('tr').find('.attendedFormat').hide();
    $(this).closest('tr').find('.wordReverse').hide();
    $(this).closest('tr').find('.byteReverse').hide();
    $(this).closest('tr').find('.unsigned').hide();
    $(this).closest('tr').find('.nbregister').hide();
    $(this).closest('tr').find('.startregister').hide();
    $(this).closest('tr').find('.valeurToAction').hide();
    
  }
});

//document.querySelector
//$("#table_cmd_infos tbody, #table_cmd_actions tbody .cmdAttr[data-l1key=type]")
$("#table_cmd_infos tbody .cmdAttr[data-l1key=type]").on('change', function () {
  console.log('cmd type changed: '+$(this).value());
});


$("#table_cmd_infos tbody, #table_cmd_actions tbody").delegate(".cmdAttr[data-l1key=type2]", 'change', function (event) {
   console.log('type: ');
   $(this).closest('tr').find('.functionCode').val('');
   $(this).closest('tr').find('.sendValues').hide();
   var cmdType = $(this).value();

   if (cmdType == 'info') {
     $(this).closest('tr').find('.readOption').show();
     $(this).closest('tr').find('.writeOption').hide();
   }
   else { // action
     $(this).closest('tr').find('.readOption').hide();
     $(this).closest('tr').find('.writeOption').show();
     $(this).closest('tr').find('.valeurToAction').show();
     $(this).closest('tr').find('.request').show();
   }
});


$(".table_cmd tbody, .cmdAttr[data-l1key=subType33]").on('change', function () {
  console.log('cmd subType33 changed: '+$(this).value());
});
$("#table_cmd_infos tbody, #table_cmd_actions tbody").delegate(".cmdAttr[data-l1key=subType]", 'change', function (event) {
	console.log('subType: '+ $(this).value());
	var subType = $(this).value();
	if (subType == 'message') {
       $(this).closest('tr').find('.readOption').show();
    }
});


$("#table_cmd_infos tbody, #table_cmd_actions tbody").delegate(".cmdAttr[data-l1key=subType]", 'change', function (event) {
   var cmdSubType = $(this).value();

   if (cmdSubType == 'other') {
     $(this).closest('tr').find('.valeurToAction').show();
     $(this).closest('tr').find('.request').show();
   }
   else {
    $(this).closest('tr').find('.valeurToAction').hide();
    $(this).closest('tr').find('.request').hide();
    if (cmdSubType == 'slider') {
      $(this).closest('tr').find('.stepchoice').show();
    }
   }
});


$("#table_cmd_infos tbody, #table_cmd_actions tbody").delegate(".cmdAttr[data-l1key=configuration][data-l2key=attendedFormat]", 'change', function (event) {
   var attendedFormat = $(this).value();
   if (attendedFormat == 'bitsformat') {
     $(this).closest('tr').find('.byteReverse').hide();
     $(this).closest('tr').find('.wordReverse').hide();
     $(this).closest('tr').find('.isnegatif').hide();

   }
   else {
     $(this).closest('tr').find('.byteReverse').show();
     $(this).closest('tr').find('.wordReverse').show();
     $(this).closest('tr').find('.isnegatif').show();
   }
   if (attendedFormat != 'floatformat') {
     $(this).closest('tr').find('.stepchoice').hide();
   } else {
     $(this).closest('tr').find('.stepchoice').show();
   }
});

$("#table_cmd_infos tbody").delegate(".cmdAttr[data-l1key=configuration][data-l2key=functionCode]", 'change', function (event) {
	console.log('functionCode: ' +$(this).value());
  	var fctCode = $(this).value();
	if(fctCode == 'fc01'){
		//modify_FC01_02_05_15($(this));
      	$(this).closest('tr').find('.wordReverse').hide();
        $(this).closest('tr').find('.byteReverse').show();
        $(this).closest('tr').find('.unsigned').hide();
        $(this).closest('tr').find('.isnegatif').hide();
        $(this).closest('tr').find('.attendedFormat').hide();
        $(this).closest('tr').find('.stepchoice').hide();
		$(this).closest('tr').find('.valeurToAction').hide();
		$(this).closest('tr').find('.nbregister').show();
		$(this).closest('tr').find('.sendValues').hide();
		$(this).closest('tr').find('.isVisible').show();
		$(this).closest('tr').find('.isSpecific').hide();
		$(this).closest('tr').find('.isVisible').prop('checked', true);
	}
	else if(fctCode == 'fc02'){
		$(this).closest('tr').find('.wordReverse').hide();
        $(this).closest('tr').find('.byteReverse').hide();
        $(this).closest('tr').find('.unsigned').hide();
        $(this).closest('tr').find('.isnegatif').hide();
        $(this).closest('tr').find('.attendedFormat').hide();
        $(this).closest('tr').find('.stepchoice').hide();
      	$(this).closest('tr').find('.valeurToAction').hide();
		$(this).closest('tr').find('.nbregister').show();
		$(this).closest('tr').find('.sendValues').hide();
		$(this).closest('tr').find('.isVisible').show();
		$(this).closest('tr').find('.isSpecific').hide();
		$(this).closest('tr').find('.isVisible').prop('checked', true);
	}
	else if(fctCode == 'fc03'){
		$(this).closest('tr').find('.wordReverse').show();
        $(this).closest('tr').find('.byteReverse').show();
        $(this).closest('tr').find('.unsigned').show();
        $(this).closest('tr').find('.isnegatif').show();
        $(this).closest('tr').find('.valeurToAction').hide();
        $(this).closest('tr').find('.isVisible').show();
      	$(this).closest('tr').find('.bitsformat').show();
		$(this).closest('tr').find('.sendValues').show();
		$(this).closest('tr').find('.stepchoice').hide();
		$(this).closest('tr').find('.isSpecific').hide();
		$(this).closest('tr').find('.isVisible').prop('checked',true);
	}
	else if(fctCode == 'fc04'){
		$(this).closest('tr').find('.wordReverse').show();
        $(this).closest('tr').find('.byteReverse').show();
        $(this).closest('tr').find('.unsigned').show();
        $(this).closest('tr').find('.isnegatif').show();
        $(this).closest('tr').find('.valeurToAction').hide();
        $(this).closest('tr').find('.isVisible').show();
      	$(this).closest('tr').find('.bitsformat').hide();
		$(this).closest('tr').find('.sendValues').hide();
		$(this).closest('tr').find('.stepchoice').hide();
		$(this).closest('tr').find('.isSpecific').hide();
		$(this).closest('tr').find('.isVisible').prop('checked',true);
	}
});

$("#table_cmd_actions tbody").delegate(".cmdAttr[data-l1key=configuration][data-l2key=functionCode]", 'change', function (event) {
	console.log('functionCode: ' +$(this).value());
  	var fctCode = $(this).value();
	if(fctCode == 'fc05'){
		$(this).closest('tr').find('.wordReverse').hide();
  $(this).closest('tr').find('.byteReverse').hide();
  $(this).closest('tr').find('.unsigned').hide();
  $(this).closest('tr').find('.isnegatif').hide();
  $(this).closest('tr').find('.attendedFormat').hide();
  $(this).closest('tr').find('.stepchoice').hide();$(this).closest('tr').find('.valeurToAction').show();
		$(this).closest('tr').find('.nbregister').hide();
		$(this).closest('tr').find('.sendValues').hide();
		$(this).closest('tr').find('.isVisible').show();
		$(this).closest('tr').find('.isSpecific').hide();
		$(this).closest('tr').find('.isVisible').prop('checked', true);
	}
	else if(fctCode == 'fc06'){
		$(this).closest('tr').find('.wordReverse').show();
  $(this).closest('tr').find('.byteReverse').show();
  $(this).closest('tr').find('.unsigned').show();
  $(this).closest('tr').find('.isnegatif').show();
  $(this).closest('tr').find('.valeurToAction').hide();
  $(this).closest('tr').find('.isVisible').show();
      
		$(this).closest('tr').find('.bitsformat').hide();
		$(this).closest('tr').find('.sendValues').hide();
		$(this).closest('tr').find('.stepchoice').show();
		$(this).closest('tr').find('.isSpecific').hide();
		$(this).closest('tr').find('.nbregister').hide();
		$(this).closest('tr').find('.bitsformat').hide();
		$(this).closest('tr').find('.floatformat').hide();
		$(this).closest('tr').find('.isVisible').prop('checked',true);
	}
	else if(fctCode == 'fc15'){
		$(this).closest('tr').find('.wordReverse').hide();
  $(this).closest('tr').find('.byteReverse').hide();
  $(this).closest('tr').find('.unsigned').hide();
  $(this).closest('tr').find('.isnegatif').hide();
  $(this).closest('tr').find('.attendedFormat').hide();
  $(this).closest('tr').find('.stepchoice').hide();$(this).closest('tr').find('.valeurToAction').hide();
		$(this).closest('tr').find('.nbregister').hide();
		$(this).closest('tr').find('.sendValues').show();
		$(this).closest('tr').find('.isVisible').show();
		$(this).closest('tr').find('.isSpecific').hide();
      	$(this).closest('tr').find('.isVisible').prop('checked', false);
	}
	else if(fctCode == 'fc16'){
		$(this).closest('tr').find('.wordReverse').show();
  $(this).closest('tr').find('.byteReverse').show();
  $(this).closest('tr').find('.unsigned').show();
  $(this).closest('tr').find('.isnegatif').show();
  $(this).closest('tr').find('.valeurToAction').hide();
  $(this).closest('tr').find('.isVisible').show();
      
		$(this).closest('tr').find('.attendedFormat').hide();
		$(this).closest('tr').find('.bitsformat').hide();
		$(this).closest('tr').find('.stepchoice').hide();
		$(this).closest('tr').find('.sendValues').show();
		$(this).closest('tr').find('.nbregister').hide();
		$(this).closest('tr').find('.isVisible').prop('checked', false);
		$(this).closest('tr').find('.isSpecific').show();
	}
});

$("#bt_addCmdInfo").on('click', function (event) {
  addCmdToTable({ type: 'info' })
  modifyWithoutSave = true
})

$("#bt_addCmdAction").on('click', function (event) {
  addCmdToTable({ type: 'action' })
  modifyWithoutSave = true
})


$("#connectType").on('change', function() {
	var typeModbus = $("#connectType").val();
	console.log('connectType: '+ typeModbus);
  	if(typeModbus == 'TCP'){
         $("#div_paramsrtu").show();
         $("#gatwayIp").show();
         $("#div-bytesize").hide();
         $("#div-baudrate").hide();
         $("#div-stopbits").hide();
         $("#div-parity").hide();
         $("#div-portserial").hide();
         $("#div-slaveId").hide();
         $("#slaveId").show();



        /* $("#paramsrtu").hide(); */
	}else if(typeModbus == 'rtu'){
            /* $("#paramsrtu").show();*/
         $("#div_paramsrtu").show();
         $("#gatwayIp").hide();
         $("#div-bytesize").show();
         $("#div-baudrate").show();
		$("#div-stopbits").show();
		$("#div-parity").show();
		$("#div-portserial").show();
		$("#div-slaveId").show();
		$("#slaveId").hide();
	}else if(typeModbus == 'ascii'){
		$("#div_paramsrtu").show();
		$("#gatwayIp").hide();
		$("#div-bytesize").show();
		$("#div-baudrate").show();
		$("#div-stopbits").show();
		$("#div-parity").show();
		$("#div-portserial").show();
		$("#div-slaveId").show();
	}
});

		
function modify_FC01_02_05_15(thi){
  thi.closest('tr').find('.wordReverse').hide();
  thi.closest('tr').find('.byteReverse').hide();
  thi.closest('tr').find('.unsigned').hide();
  thi.closest('tr').find('.isnegatif').hide();
  thi.closest('tr').find('.attendedFormat').hide();
  thi.closest('tr').find('.stepchoice').hide();
}


function modify_FC03_04_06_16(thi){
  thi.closest('tr').find('.wordReverse').show();
  thi.closest('tr').find('.byteReverse').show();
  thi.closest('tr').find('.unsigned').show();
  thi.closest('tr').find('.isnegatif').show();
  thi.closest('tr').find('.valeurToAction').hide();
  thi.closest('tr').find('.isVisible').show();
}

/* Fonction permettant l'affichage des commandes dans l'équipement */
function addCmdToTable(_cmd) {
  if (!isset(_cmd)) {
     var _cmd = {configuration: {}};
   }
   if (!isset(_cmd.configuration)) {
     _cmd.configuration = {};
   }
   var tr = '<tr class="cmd" data-cmd_id="' + init(_cmd.id) + '">';
   tr += '<td style="">';
   tr += '<span class="cmdAttr" data-l1key="id"></span>';
   tr += '</td>';
   
  
 
  	tr += '<td>';
    tr += '<div class="input-group">';
      tr += '<input class="cmdAttr form-control input-sm roundedLeft" data-l1key="name" placeholder="{{Nom de la commande}}">';
  		tr += '<input class="cmdAttr form-control input-sm defCmd" data-l1key="configuration" data-l2key="defCmd" style="display : none;" placeholder="{{defCmd}}">';
   
      tr += '<span class="input-group-btn"><a class="cmdAction btn btn-sm btn-default" data-l1key="chooseIcon" title="{{Choisir une icône}}"><i class="fas fa-flag"></i></a></span>';
      tr += '<span class="cmdAttr input-group-addon roundedRight" data-l1key="display" data-l2key="icon" style="font-size:19px;padding:0 5px 0 0!important;"></span>';
      tr += '</div>';
    tr += '<select class="cmdAttr form-control input-sm" data-l1key="value" style="display:none;margin-top:2px;" title="{{Commande information liée}}">';
    tr += '<option value="">{{Aucune}}</option>';
    tr += '</select>';
    tr += '</td>';
  
  
  
  
   tr += '<td>';
   tr += '<span class="type hide" id="' + init(_cmd.type) + '" type="' + init(_cmd.type) + '">' + jeedom.cmd.availableType() + '</span>';
   tr += '<span class="subType" subType="' + init(_cmd.subType) + '" style="max-width: 100px;">';
  	if (_cmd.type == 'info'){
	  tr += '<select style="width: 100px" class="cmdAttr form-control input-sm" data-l1key="subType"><option value="numeric">Numérique</option><option value="binary">Binaire</option><option value="string">Autre</option></select>';
	}
   	else {
	  tr += '<select style="width: 100px" class="cmdAttr form-control input-sm" data-l1key="subType"><option value="other">Défaut</option><option value="slider">Curseur</option><option value="message">Message</option><option value="color">Couleur</option><option value="select">Liste</option></select>';
	} 
  tr += '</span>';
  
   tr += '</td>';
   tr += '<td style="">';
   tr += '<input class="cmdAttr form-control input-xs minVal" data-l1key="configuration" data-l2key="minValue" placeholder="{{Min.}}" title="{{Min.}}" style="max-width: 80px; margin-top: 2px; display:inline-block;font-size: 12px !important;"/><br> ';
   tr += '<input class="cmdAttr form-control input-xs maxVal" data-l1key="configuration" data-l2key="maxValue" placeholder="{{Max.}}" title="{{Max.}}" style="max-width: 80px; margin-top: 2px; display:inline-block;font-size: 12px !important;"/><br> ';
   tr += '<input class="cmdAttr form-control input-xs unitVal" data-l1key="unite" placeholder="{{Unité}}" title="{{Unité}}" style="max-width: 80px; margin-top: 2px; display:inline-block;font-size: 12px !important;"/>';
   tr += '<input class="cmdAttr form-control input-xs decimalafter " data-l1key="configuration" data-l2key="historizeRound" placeholder="{{Arrondi}}" title="{{Nb Chiffres apres la virgule}}" style="max-width: 80px; margin-top: 2px; display:inline-block;font-size: 12px !important;"/>';
  
   if (_cmd.type == 'action'){
     tr += '<input class="cmdAttr form-control input-xs stepchoice" data-l1key="configuration" data-l2key="stepchoice" placeholder="{{Pas du slider}}" title="{{Choisir le pas du slider (0.1, 0.5 etc..)}}" style="max-width: 80px; margin-top: 2px; display:inline-block;font-size: 12px !important;"/>';
   }	
   tr += '</td>';
   tr += '<td>';
  
   tr += '<div class="multiR" ><label class="checkbox-inline"><input type="checkbox" class="cmdAttr form-control multiR" data-l1key="configuration" data-l2key="multiR" >{{Lecture MultiRegistres}}</label></div>';
   
   tr += '<div class="hexa"><label class="checkbox-inline"><input type="checkbox" class="cmdAttr form-control" data-l1key="configuration" data-l2key="hexa" >{{HexaToDec}}</label></div>';
  
   tr += '<div class="isSpecific" style="display:none;"><label class="checkbox-inline"><input type="checkbox" class="cmdAttr form-control" data-l1key="configuration" data-l2key="isSpecific" >{{Fc16 Registres non suivis}}</label></div>';

  /*
    tr += '<label class="checkbox multiR"><input type="checkbox" class="cmdAttr multiR" data-l1key="configuration" data-l2key="multiR">{{Lecture MultiRegistres}}</label>';
  
  tr += '<label class="checkbox multiR"><input type="checkbox" class="cmdAttr hexa" data-l1key="configuration" data-l2key="hexa">{{HexaToDec}}</label>';
   
   tr += '<label class="checkbox isSpecific"  style="display:none;"><input type="checkbox" class="cmdAttr isSpecific" data-l1key="configuration" data-l2key="isSpecific" style="display:none;">{{Fc16 Registres non suivis}}</label>';
   */
   tr += '<input class="cmdAttr form-control tooltips input-sm operation" data-l1key="configuration" data-l2key="operation" placeholder="{{Operation sur la commande}}" style="margin-bottom:2px; width:100%;"/>';
  
  
   //tr += '<label class="checkbox-inline offset"><input type="checkbox" class="cmdAttr offset" data-l1key="configuration" data-l2key="offset">{{Offset}}</label>';
   tr += '<select class="cmdAttr form-control input-sm cmdAction offset" data-l1key="configuration" data-l2key="offset" style="margin-bottom:2px; font-weight:bold;">';
   tr += '<option value="" selected id="offset" disabled>{{Offset}}</option>';
   tr += '<option value="0" id="noOffset">{{No Offset}}</option>';
   tr += '<option value="-1" id="offsetMinus">{{Offset -1}}</option>';
   tr += '<option value="1" id="offsetPlus">{{Offset +1}}</option>';
   tr += '</select>';
   
   tr += '</td>';
   tr += '<td>';
   tr += '<input class="cmdAttr form-control tooltips input-sm startregister" data-l1key="configuration" data-l2key="startregister" placeholder="{{Registre départ}}" style="margin-top: 2px;width:100%;"/>';
   tr += '<input class="cmdAttr form-control tooltips input-sm nbregister" data-l1key="configuration" data-l2key="nbregister" placeholder="{{Nb de registres}}" style="margin-top: 2px; width:100%"/>';
  
   tr += '<select class="cmdAttr form-control input-sm cmdAction functionCode" data-l1key="configuration" data-action="testFC" data-l2key="functionCode" id="functionCode" style="margin-top: 2px; font-weight:bold;">';
   if (_cmd.type == 'info'){
	  tr += '<option value="" id="test" disabled>{{FONCTION READ}}</option>';
   	  tr += '<option value="fc01" class="readOption" id="fc01">{{01 Coils Status}}</option>';
	  tr += '<option value="fc02" class="readOption" id="fc02">{{02 Discrete Input}}</option>';
	  tr += '<option value="fc03" class="readOption" id="fc03" selected>{{03 Holding registers}}</option>';
	  tr += '<option value="fc04" class="readOption" id="fc04">{{04 Input Registers}}</option>';
   }
   else {
	  tr += '<option value="" selected id="test" disabled>{{FONCTION WRITE}}</option>';
   	  tr += '<option value="fc05" class="writeOption" id="fc05">{{05 Single Coil}}</option>';
	  tr += '<option value="fc06" class="writeOption" id="fc06">{{06 Single Register}}</option>';
	  tr += '<option value="fc15" class="writeOption" id="fc15">{{15 Multiple Coils}}</option>';
	  tr += '<option value="fc16" class="writeOption" id="fc16">{{16 Multiple Registers}}</option>';
   }     
   tr += '</select>';
   tr += '<select class="cmdAttr form-control input-sm attendedFormat" data-l1key="configuration" data-l2key="attendedFormat" id="attendedFormat" style="margin-top: 2px;font-weight:bold;">';
   tr += '<option value="other" selected disabled>{{Format données}}</option>';
   tr += '<option value="bitsformat" class="bitsformat">{{Bits}}</option>';
   tr += '<option value="longformat" class="longformat">{{Long / Integer}}</option>';
   tr += '<option value="floatformat" class="floatformat">{{Float (Real4)}}</option>';
   tr += '<option value="strformat" class="strformat">{{String}}</option>';
   tr += '<option value="noneformat" class="noneformat">{{None}}</option>';
  //tr += '<option value="bcd" class="bcd">{{BCD}}</option>';
   tr += '</select>';
  /*
   tr += '<select class="cmdAttr form-control input-sm wordReverse" data-l1key="configuration" data-l2key="wordReverse" style="margin-top: 2px;font-weight:bold;">';
   tr += '<option value="" selected disabled>{{== Word Order ==}}</option>';
   tr += '<option value="littleword">{{Little First}}</option>';
   tr += '<option value="bigword">{{Big First}}</option>';
   tr += '</select>';
   tr += '<select class="cmdAttr form-control input-sm byteReverse" data-l1key="configuration" data-l2key="byteReverse" style="margin-top: 2px;font-weight:bold;">';
   tr += '<option value="" selected disabled>{{== Byte Order ==}}</option>';
   tr += '<option value="littlebyte">{{Little First}}</option>';
   tr += '<option value="bigbyte">{{Big First}}</option>';
   tr += '</select>';//$byteReverse, $wordReverse
  */
  if (_cmd.type == 'action'){
        tr += '<input type="number" class="cmdAttr form-control tooltips input-sm valeurToAction" data-l1key="configuration" data-l2key="valeurToAction" placeholder="{{Valeur à envoyer pour WriteCoil (0 ou 1)}}" style="margin-top: 2px; width:100%; display: inline-block;"/>';
    //tr += '<textarea style="height: 35px; margin-top:5px; margin-bottom: 0px; display: none;" class="cmdAttr form-control input-sm request" data-l1key="configuration" placeholder="Valeurs a envoyer aux coils" data-l2key="request"></textarea>';
    }
  
  tr += '<div class="byteReverse" ><label class="checkbox-inline"><input type="checkbox" class="cmdAttr form-control byteReverse" data-l1key="configuration" data-l2key="byteReverse" >{{byteReverse}}</label></div>';
   tr += '<div class="wordReverse"><label class="checkbox-inline"><input type="checkbox" class="cmdAttr form-control" data-l1key="configuration" data-l2key="wordReverse" checked>{{wordReverse}}</label></div>';
   tr += '<div class="unsigned"><label class="checkbox-inline"><input type="checkbox" class="cmdAttr form-control" data-l1key="configuration" data-l2key="unsigned" >{{unsigned}}</label></div>';
  
  
  
   

    
    
  

   tr += '</td>';
  	tr += '<td ';
   tr += '<td>';
        if (typeof jeeFrontEnd !== 'undefined' && jeeFrontEnd.jeedomVersion !== 'undefined') {
		   tr += '<span class="cmdAttr" data-l1key="htmlstate"></span>';
		   
    	}
		tr += '</td>';
		
   tr += '<td style="">';
   tr += '<div><label class="checkbox-inline"><input type="checkbox" class="cmdAttr" data-l1key="isVisible" checked>{{Afficher}}</label></div>';
   tr += '<div><label class="checkbox-inline"><input type="checkbox" class="cmdAttr" data-l1key="isHistorized" checked>{{Historiser}}</label></div>';
   tr += '<div><label class="checkbox-inline"><input type="checkbox" class="cmdAttr" data-l1key="display" data-l2key="invertBinary">{{Inverser}}</label></div>';
   tr += '</td>';
   tr += '<td style="">';
   if (is_numeric(_cmd.id)) {
		test = $('.cmdAction[data-action=testFC]').value();

		tr += '<a class="btn btn-default btn-xs cmdAction" data-action="configure"><i class="fas fa-cogs"></i></a> ';
     /*tr += '<a class="btn btn-default btn-xs cmdAction" data-action="test"><i class="fas fa-rss"></i> Tester</a>';*/
   /*  tr += '<a class="btn btn-primary btn-xs cmdAction sendValues" data-action="sendValues">{{Envoyer Valeurs}}</a>';*/
   }
   tr += ' <a class="btn btn-default btn-xs cmdAction" data-action="copy" title="Dupliquer"><i class="far fa-clone"></i></a> ';
  
   tr += '<i class="fas fa-minus-circle pull-right cmdAction cursor" data-action="remove" style="margin-top: 3px"></i></td>';
   tr += '</tr>';
   if (_cmd.type == 'info'){
        $('#table_cmd_infos tbody').append(tr)
        $('#table_cmd_infos tbody tr:last').setValues(_cmd, '.cmdAttr')
        if (isset(_cmd.type)) $('#table_cmd_infos tbody tr:last .cmdAttr[data-l1key=type]').value(init(_cmd.type))
        jeedom.cmd.changeType($('#table_cmd_infos tbody tr:last'), init(_cmd.subType))
    }
    else {
        $('#table_cmd_actions tbody').append(tr)
      	var tr = $('#table_cmd_actions tbody tr').last();
      	jeedom.eqLogic.builSelectCmd({
           id:  $('.eqLogicAttr[data-l1key=id]').value(),
           filter: {type: 'info'},
           error: function (error) {
             $('#div_alert').showAlert({message: error.message, level: 'danger'});
           },
           success: function (result) {
             tr.find('.cmdAttr[data-l1key=value]').append(result);
             tr.setValues(_cmd, '.cmdAttr');
             jeedom.cmd.changeType(tr, init(_cmd.subType));

           }
         });
      
      
        //$('#table_cmd_actions tbody tr:last').setValues(_cmd, '.cmdAttr')
        //if (isset(_cmd.type)) $('#table_cmd_actions tbody tr:last .cmdAttr[data-l1key=type]').value(init(_cmd.type))
        //jeedom.cmd.changeType($('#table_cmd_actions tbody tr:last'), init(_cmd.subType))
    }
  
  
  

}