<?php

/* This file is part of Jeedom.
*
* Jeedom is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Jeedom is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
*/

if (!isConnect('admin')) {
  throw new Exception('{{401 - Accès non autorisé}}');
}


$eqLogic = ModbusMonitor::byId(init('eqLogic'));
if(is_object($eqLogic)){
 $eqId = $eqLogic->getId();
 $allCmds = cmd::byEqLogicId($eqId);

}else{
  return;
}


?>



<div style="display:none;" id="md_historizedCmdsListAlert"></div>
<div class="input-group pull-right">
  <a class="btn btn-default roundedLeft" id="bt_allSelectCmd" data-state="0"><i class="fas fa-check-circle"></i> {{Tout selectionner}}
  </a><a class="btn btn-success roundedRight" id="bt_cmdsListAlertApply"><i class="fas fa-check"></i> {{Valider}}</a>
</div>
<br>

<table class="table table-bordered table-condensed tablesorter" id="#table_cmdsList" style="width:100% !important;">
  <thead>
    <tr>
      <th data-sorter="false" data-filter="false"></th>
      <th>{{Objet}}</th>
      <th>{{Équipement}}</th>
      <th>{{Nom}}</th>
      <th>{{Type générique}}</th>
    </tr>
  </thead>
  <tbody>
    <?php
    foreach ($allCmds as $cmd) {
      if (is_object($cmd)) {
        $tr = '';
        $tr .= '<tr data-cmd_id="' . $cmd->getId() . '">';
        $tr .= '<td>';
        $tr .= '<input type="checkbox" class="selectCmd">';
        $tr .= '</td>';
        $tr .= '<td>';
        $object = $eqLogic->getObject();
        if(is_object($object)){
          $tr .= $object->getName();
        }
        $tr .= '</td>';
        $tr .= '<td>';
        $tr .= $eqLogic->getName();
        $tr .= '</td>';
        $tr .= '<td>';
        $tr .= $cmd->getName();
        $tr .= '</td>';
        $tr .= '<td>';
        $tr .= $cmd->getGeneric_type();
        $tr .= '</td>';
        $tr .= '</tr>';
        echo $tr;
      }
    }
    ?>
  </tbody>
</table>

<script type="text/javascript">
initTableSorter()

$(document).ready(function() {
  var selectedIds = $('.eqLogicAttr[data-l2key=selectedCmdIds]').value()
  if (selectedIds != '') {
    let selectedIdsArray = selectedIds.split(',');
    $('#table_cmdsList tbody tr').each(function() {
      let cmdId = $(this).data('cmd_id');
      if (selectedIdsArray.includes(cmdId.toString())) {
        $(this).find('.selectCmd').prop('checked', true);
      }
      else {
        $(this).find('.selectCmd').prop('checked', false);
      }
    })
  }
})

$('#bt_cmdsListAlertApply').off().on('click', function() {
  var newSelection = ''
  $('.selectCmd:checkbox').each(function() {
    if ($(this).is(':checked')) {
      newSelection += $(this).closest('tr').attr('data-cmd_id') + ','
    }
  })
  $('.eqLogicAttr[data-l2key=selectedCmdIds]').value(newSelection.substr(0, newSelection.length - 1))
  modifyWithoutSave = true
  $('#md_modal').dialog('close')
})

$('#bt_allSelectCmd').off('click').on('click', function() {
  if( $("[class=selectCmd]").prop('checked')){
     $("[class=selectCmd]").not(this).prop('checked', false);
  }else{
     $("[class=selectCmd]").not(this).prop('checked', true);
  }
})
</script>
