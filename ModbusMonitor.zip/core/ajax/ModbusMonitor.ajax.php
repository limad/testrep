<?php

/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

try {
    require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';
    include_file('core', 'authentification', 'php');

    if (!isConnect('admin')) {
        throw new Exception(__('401 - Accès non autorisé', __FILE__));
    }

  /* Fonction permettant l'envoi de l'entête 'Content-Type: application/json'
    En V3 : indiquer l'argument 'true' pour contrôler le token d'accès Jeedom
    En V4 : autoriser l'exécution d'une méthode 'action' en GET en indiquant le(s) nom(s) de(s) action(s) dans un tableau en argument
  */
	ajax::init();
  

/* **************************************** */
	if(init('action') == 'importJson'){
         $uploaddir = __DIR__ . '/../../data/importJson';

        $eqLogic = eqLogic::byId(init('id'));
		if (!is_object($eqLogic)) {
			throw new Exception(__('EqLogic inconnu verifié l\'id', __FILE__));
		}
        

  		if (!file_exists($uploaddir)) {
  			mkdir($uploaddir);
  		}
  		if (!file_exists($uploaddir)) {
  			throw new Exception(__('Répertoire de téléversement non trouvé : ', __FILE__) . $uploaddir);
  		}
  		if (!isset($_FILES['file'])) {
  			throw new Exception(__('Aucun fichier trouvé. Vérifiez le paramètre PHP (post size limit)', __FILE__));
  		}
  		$extension = strtolower(strrchr($_FILES['file']['name'], '.'));
  		if (in_array($extension, array('.json'))) {

  		}else{
  			throw new Exception('Extension du fichier non valide (autorisé .json) : ' . $extension);
  		}
  		if (filesize($_FILES['file']['tmp_name']) > 10000000) {
  			throw new Exception(__('Le fichier est trop gros (maximum 10Mo)', __FILE__));
  		}
      	if (!move_uploaded_file($_FILES['file']['tmp_name'], $uploaddir . '/' . $_FILES['file']['name'])) {
			throw new Exception(__('Impossible de déplacer le fichier temporaire', __FILE__));
		}

  		if (!file_exists($uploaddir . '/' . $_FILES['file']['name'])) {
  			throw new Exception(__('Impossible de télécharger le fichier (limite du serveur web ?)', __FILE__));
  		}
      
        $pathToSend = $uploaddir . '/' . $_FILES['file']['name'];
        ModbusMonitor::importJson($pathToSend, init('id'));
        ajax::success();


    }

/* **************************************** */
	if(init('action') == 'sendValues'){

        ModbusMonitor::sendValues(init('functioncode'), init('cmd_id'), init('id'), init('value') );
        ajax::success();


    }

/* **************************************** */
	if(init('action') == 'exportCmd'){
        ModbusMonitor::exportJson(init('eqId'), init('cmds'));
        ajax::success();


    }

/* **************************************** */
	if(init('action') == 'createCmds'){
 		ModbusMonitor::importJson(init('path'), init('id'));
 		ajax::success();
    }

/* **************************************** */
	if(init('action') == 'connectGateway'){
      	$eqLogic = ModbusMonitor::byId(init('eqLogic_id'));
      	if (!is_object($eqLogic)) {
			//throw new Exception(__('Equipement ModbusMonitor non trouvé : ', __FILE__) . init('eqLogic_id'));
		}
      	$config = init('dataj');
      	log::add('ModbusMonitor', 'warning', "Ajax::connectGateway config ".json_encode($config) );
              	
      	foreach ($config as $configKey=>$value){
			if($value == ""){
				log::add('ModbusMonitor', 'warning', "Ajax::connectGateway [".$configKey."] is mandatory " );
              	throw new Exception(__('Ajax::setEqConfig ['.$eqLogic->getName().'] Echec parametre manquant: ', __FILE__));
			}
        }
      	$connect_type = $config['connect_type']; 
        $gatwayIp = $config['gatwayIp']; 
        $gatwayPort = $config['gatwayPort']; 
      	$result = ModbusMonitor::getModbus($gatwayIp, $connect_type, $gatwayPort, true);
      	ajax::success($result);
    }

/* **************************************** */
	if(init('action') == 'TestCmdRead'){
      	$config = init('dataj');
      	log::add('ModbusMonitor', 'warning', "Ajax::readCmd config ".json_encode($config) );
              	
      	foreach ($config as $configKey=>$value){
			if($value == ""){
				log::add('ModbusMonitor', 'warning', "Ajax::connectGateway [".$configKey."] is mandatory " );
              	throw new Exception(__('Ajax::setEqConfig ['.$eqLogic->getName().'] Echec parametre manquant: ', __FILE__));
			}
        }
      	$result = ModbusMonitor::TestCmdRead($config);
      	ajax::success($result);
    } 
/* **************************************** */
	if(init('action') == 'scanRegs'){
      	$config = init('dataj');
      	log::add('ModbusMonitor', 'warning', "Ajax::readCmd config ".json_encode($config) );
              	
      	foreach ($config as $configKey=>$value){
			if($value == ""){
				log::add('ModbusMonitor', 'warning', "Ajax::connectGateway [".$configKey."] is mandatory " );
              	throw new Exception(__('Ajax::setEqConfig ['.$eqLogic->getName().'] Echec parametre manquant: ', __FILE__));
			}
        }
      	$result = ModbusMonitor::scanRegs($config);
      	ajax::success($result);
    }
/* **************************************** */
	throw new Exception(__('Aucune méthode correspondante à : ', __FILE__) . init('action'));
    /*     * *********Catch exeption*************** */
} catch (Exception $e) {
    ajax::error(displayException($e), $e->getCode());
}