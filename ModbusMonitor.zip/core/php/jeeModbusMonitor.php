<?php
/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
*/

require_once __DIR__ . '/../../../../core/php/core.inc.php';
/*
 * Non obligatoire mais peut être utilisé si vous voulez charger en même temps que votre
 * plugin des librairies externes (ne pas oublier d'adapter plugin_info/info.xml).
 *
 *
*/
if (!jeedom::apiAccess(init('apikey') , 'ModbusMonitor'))
{
    echo __('Vous n\'etes pas autorisé à effectuer cette action', __FILE__);
    die();
}

/*
if (init('test') != '') {
	echo 'OK';
	die();
}*/

function operationForJeedom($value, $operation)
{
    //log::add('ModbusMonitor', 'debug', 'DEMANDE D OPERATION SUR LA VALEUR REMONTEE');
    $expr = strval($value) . strval($operation);
    $lenValue = strlen(strval($value));
    $lenTotal = strlen($expr);
    $operator = $expr[$lenValue];
    $lenCoefficient = strlen($operation);
    $coefficient = substr($expr, -$lenCoefficient + 1);
    if ($operator == '*')
    {
        $result = $value * $coefficient;
    }
    elseif ($operator == '/')
    {
        $result = $value / $coefficient;
    }
    elseif ($operator == '+')
    {
        $result = $value + $coefficient;
    }
    else
    {
        log::add('ModbusMonitor', 'debug', 'ERREUR DANS VOTRE COMMANDE OPERATION');
        return $value;
    }
    return $result;
}

$result = json_decode(file_get_contents("php://input") , true);

log::add('ModbusMonitor', 'debug', 'Result:' . json_encode($result));

if (!is_array($result))
{
    die();
}

if ($result['FUNC'] == 'readF')
{
    $dataCorrespond = $result['data'];
    log::add('ModbusMonitor', 'debug', 'DATACORRESPOND : ' . json_encode($dataCorrespond));
    //{"data":{"692":{"test":[{"StartRegister":50000,"CmdId":"9848","value":"83 79 67 79"}]}},"FUNC":"readF"}
  	foreach ($result['data'] as $id => $data)
    {
        $eqLogicId = $id;
      	foreach ($data as $nameCmd => $infos)
        {
            foreach ($infos as $info)
            {
                $cmdId = intval($info['CmdId']);
                $cmdsearch = cmd::byId($cmdId);
                if (is_object($cmdsearch))
                {
                    $formatIO = $cmdsearch->getConfiguration('formatIO');
                  	if ($cmdsearch->getConfiguration('choicefunctioncode') == 'fc03' &&  $formatIO != 'floatformat' && $formatIO != 'longformat')
                      //$formatIO == 'bitsformat'
                    {                     
                        $value = $info['value'];
                      	//log::add('ModbusMonitor', 'info', ''.$cmdsearch->getName()."($formatIO) value: " . $value);
                    }
                    else
                    {
                        $value = floatval($info['value']);
                        if ($cmdsearch->getLogicalId() == 'ecriturebit')
                        {
                            $cmdToEv = cmd::byEqLogicIdAndLogicalId($eqLogicId, 'infobitbinary');
                            if (is_object($cmdToEv))
                            {
								//log::add('ModbusMonitor', 'debug', 'value ecriturebit_infobitbinary : ' . $value);
                    			$reg = $cmdsearch->getConfiguration('startregister');
                                $cmdToEv->event(decbin($value));
                                $cmdToEv->setName(__('READ_HOLDING_' . $reg, __FILE__));
                                $cmdToEv->save();
							}
                        }
                    }
                    $cmdsearch->setConfiguration('historizeRound', $cmdsearch->getConfiguration('decimalafter', 0));
                    $operation = $cmdsearch->getConfiguration('operation');
                    if ($operation && $cmdsearch->getConfiguration('choicefunctioncode') != 'fc01' && $cmdsearch->getConfiguration('choicefunctioncode') != 'fc02')
                    {
                        $value = operationForJeedom($value, $operation);
                      	//log::add('ModbusMonitor', 'warning', ''.$cmdsearch->getName()."($formatIO) value operation: " . $value);
                    
                    }
                    $cmdsearch->save();
                    $cmdsearch->event($value);
                }
            }
        }
    }
    log::add('ModbusMonitor', 'debug', 'DECODER : ' . json_encode($result));

}
else if ($result['FUNC'] == 'write')
{
    log::add('ModbusMonitor', 'debug', 'RETURNFUNCTIONWRITE' . json_encode($result));
    if ($result['isOk'] == 'no')
    {
        message::add('ModbusMonitor', 'ERREUR ECRITURE', 'plop', 'messageWriteError');
        message::removeAll('ModbusMonitor', 'messageWriteError');

    }
    else
    {
        message::add('ModbusMonitor', 'ECRITURE OKI', 'plopr', 'messageWriteOk');
        message::removeAll('ModbusMonitor', 'messageWriteOk');

    }

}