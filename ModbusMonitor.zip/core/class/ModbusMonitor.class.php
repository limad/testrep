<?php
/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
*/

/* * ***************************Includes********************************* */
require_once __DIR__ . '/../../../../core/php/core.inc.php';

$autoload ='ModbusMonitor/3rdparty/krakorj-phpmodbus/autoload.php';
if (file_exists(dirname(__FILE__) . '/../../../'.$autoload)) {
	require_once dirname(__FILE__) . '/../../../'.$autoload;
}
class ModbusMonitor extends eqLogic {
	/*	* *************************Attributs****************************** */
	private static $_client = null;
	
	
/* ********************************** */
	public static function test_Connect($gatwayIp, $gatwayPort, $connectType) {
	
	}

/* ********************************** */
	public static function updateEq(array $eqConfig) {
      	log::add('ModbusMonitor', 'debug', __FUNCTION__.' start '.json_encode($eqConfig));
		$eqlogicId =  $eqConfig['id'];
        $gatwayIp = $eqConfig['gatwayIp'];
		$connectType = $eqConfig['connectType'];
		$gatwayPort = $eqConfig['gatwayPort'];
		$slaveId = +$eqConfig['slaveId'];
        $modbus = self::getModbus($gatwayIp, $connectType, $gatwayPort);
      	log::add('ModbusMonitor', 'debug', __FUNCTION__."gatwayIp: $gatwayIp -- connectType: $connectType -- gatwayPort: $gatwayPort");
      	$cmdsOptions =  $eqConfig['cmdsOptions'];
      	foreach($cmdsOptions as $cmdParms){
        	$startregister = +$cmdParms['startregister'];
        	$nbregister = +$cmdParms['nbregister'];
        	$functionCode = $cmdParms['functionCode'];
        	$byteReverse = boolval($cmdParms['byteReverse']);
        	$wordReverse = boolval($cmdParms['wordReverse']);
        	$unsigned = boolval($cmdParms['unsigned']);
          	$attendedFormat = $cmdParms['attendedFormat'];
          	//longformat;floatformat;bitsformat;stringformat,noneformat,hexaformat,binaryformat
			$operation = $cmdParms['operation'] ?? "";
          	log::add('ModbusMonitor', 'debug', __FUNCTION__." slaveId: $slaveId -- startregister: $startregister 
            -- functionCode: $functionCode -- $byteReverse: byteReverse -- wordReverse: $wordReverse 
            -- unsigned: $unsigned -- attendedFormat: $attendedFormat");
      	
          	//return; 	
          	try {
                $result = [];//$result['']
                if(!method_exists($modbus, $functionCode)){
                    throw new Exception(__("No methode corespending to '$functionCode'", __FILE__));
                }
                $recData = call_user_func_array([$modbus, $functionCode], [$slaveId, $startregister, $nbregister] );
                log::add('ModbusMonitor', 'debug', __FUNCTION__.' recData '.json_encode($recData));

                $nbBytes = count($recData);
                if($attendedFormat == "longformat"){
                  	if($unsigned){
					 	$result['Uint'] = modbusApi\MdBus::toUint($recData, $byteReverse, $wordReverse);
                    }
                    else{
                        $result['Int'] = modbusApi\MdBus::toInt($recData, $byteReverse, $wordReverse);
                    }
                }
                elseif($attendedFormat == "floatformat"){

                	if($nbBytes>=4 && $nbBytes<8) $bitSize = 32;
                    elseif($nbBytes>=8) $bitSize = 64; 
                    $result['float'] = modbusApi\MdBus::bytes2Float($recData, $byteReverse, $wordReverse, $bitSize);
                }
                elseif($attendedFormat == "bitsformat"){

                }
                elseif($attendedFormat == "stringformat"){
                    $result['string'] = modbusApi\MdBus::bytes2string($recData);
                }
                elseif($attendedFormat == "noneformat"){

                }
                elseif($attendedFormat == "hexaformat"){
                    $result['hex'] = modbusApi\MdBus::bytes2hexAr($recData);
                }
                elseif($attendedFormat == "binaryformat"){

                }
        	}
			catch (Exception $e) {
                log::add('ModbusMonitor', 'warning', __FUNCTION__.' Exception '.$e);
                throw new Exception(__($e->getMessage(), __FILE__));
            }
          
    		log::add('ModbusMonitor', 'debug', __FUNCTION__.' result '.json_encode($result).count($result));
    		$keyr = array_key_first($result);
    		$result = $result[$keyr];
    		if(is_array($result) && count($result)==1){
                $key = array_key_first($result);
                $result = +$result[$key];
            }
    		if(is_numeric($result) && $operation != ""){
                $result = self::calc($result, $operation);
                log::add('ModbusMonitor', 'debug', __FUNCTION__.' result calc: '.$result);
            }	
    		$cmdId = intval($cmdParms['cmdId']);
            $cmdsearch = cmd::byId($cmdId);
            if (is_object($cmdsearch)){
              	if(is_array($result)){
                    $key = array_key_first($result);
                    $result = json_encode($result);
                }
    			$cmdsearch->event($result);
              	log::add('ModbusMonitor', 'warning', __FUNCTION__." set cmd ".$cmdsearch->getName(). " to " .$result);
              	//$arrayValues = $cmdsearch->execCmd();
                     
            }
          	else{
              	log::add('ModbusMonitor', 'warning', __FUNCTION__." la commade $cmdId est inconnue ");
            }
                 
                  
          	//return $result;
        }
      
    }
  
/* ********************************** */
	public static function scanRegs(array $config) {
		log::add('ModbusMonitor', 'debug', __FUNCTION__.' start '.json_encode($config));
		$gatwayIp = $config['gatwayIp'];
		$connectType = $config['connectType'];
		$gatwayPort = $config['gatwayPort'];
		$modbus = self::getModbus($gatwayIp, $connectType, $gatwayPort);
	
	/////////////////////////	
		$cmdParms = $config['cmdParms'];
		$slaveId = +$cmdParms['slaveId'];
		$startregister = +$cmdParms['startregister'];
        $endregister = +$cmdParms['endregister'];
        $nbregister = +$cmdParms['nbregister'] ?? 1;
        $functionCode = $cmdParms['functionCode'];
        $byteReverse = boolval($cmdParms['byteReverse']);
        $wordReverse = boolval($cmdParms['wordReverse']);
        $unsigned = boolval($cmdParms['unsigned']);
        $attendedFormat = $cmdParms['attendedFormat'];
        //longformat;floatformat;bitsformat;stringformat,noneformat,hexaformat,binaryformat
		$operation = $cmdParms['operation'] ?? "";
      
      
       	if(!method_exists($modbus, $functionCode)){
			throw new Exception(__("No methode corespending to '$functionCode'", __FILE__));
		}
		$result = [];
    	$i=$startregister;
        for ($i=$startregister; $i<=$endregister; $i += $nbregister){
           	$regEnd = ($nbregister > 1) ? "-".($i + $nbregister-1):"";
      		
          	log::add('ModbusMonitor', 'debug', __FUNCTION__." $i -- slaveId: $slaveId -- startregister: $startregister 
            -- functionCode: $functionCode -- byteReverse: $byteReverse -- wordReverse: $wordReverse 
            -- unsigned: $unsigned -- attendedFormat: $attendedFormat -- nbregister: $nbregister -- regEnd: $regEnd operation : $operation");
          	
          	
            
          try {
                //$result['']
                $recData = call_user_func_array([$modbus, $functionCode], [$slaveId, $i, $nbregister] );
                //log::add('ModbusMonitor', 'debug', __FUNCTION__.' recData '.json_encode($recData));
                $nbBytes = count($recData);
                if($attendedFormat == "longformat"){
                    if($unsigned){
							$result[$i.$regEnd.' Uint'] = modbusApi\MdBus::toUint($recData, $byteReverse, $wordReverse);
                        }
                        else{
							$result[$i.$regEnd.' Int'] = modbusApi\MdBus::toInt($recData, $byteReverse, $wordReverse);
                        }
                  
                      	
              	
                      /*
                      if($nbBytes>=2 && $nbBytes<4){
                      if($unsigned){
                          	$result[$i.$regEnd.' Uint16'] = modbusApi\MdBus::bytes2Int_Usign($recData, $byteReverse);
                        }
                      	else{
                          	$Int16 = modbusApi\MdBus::bytes2Int_Sign($recData, $byteReverse);
                       		$result[$i.$regEnd.' Int16'] = $Int16;
						}
                    }
                    elseif($nbBytes>=4 && $nbBytes<8){
                        if($unsigned){
                          	$result[$i.$regEnd.' Uint32'] = modbusApi\MdBus::bytes2Int_Usign($recData, $byteReverse, $wordReverse, 32);
                        }
                      	else{
                          	$Int32 = modbusApi\MdBus::bytes2Int_Sign($recData, $byteReverse, $wordReverse, 32);
                       		$result[$i.$regEnd.' Int32'] = $Int32;
						}
                    }
                    elseif($nbBytes>=8){
                        if($unsigned){
                          	$result[$i.$regEnd.' Uint64'] = modbusApi\MdBus::bytes2Int_Usign($recData, $byteReverse, $wordReverse, 64);
                        }
                      	else{
                          	$Int64 = modbusApi\MdBus::bytes2Int_Sign($recData, $byteReverse, $wordReverse, 64);
                       		$result[$i.$regEnd.' Int64'] = $Int64;
						}
                    }
                    */
                }
                elseif($attendedFormat == "floatformat"){
					if($nbBytes>=4 && $nbBytes<8) $bitSize = 32;
					elseif($nbBytes>=8) $bitSize = 64; 
					$result[$i.$regEnd.' float'] = modbusApi\MdBus::bytes2Float($recData, $byteReverse, $wordReverse, $bitSize);
                }
                elseif($attendedFormat == "bitsformat"){

                }
                elseif($attendedFormat == "stringformat"){
                   $result[$i.$regEnd.' string'] = modbusApi\MdBus::bytes2string($recData);
                }
                elseif($attendedFormat == "noneformat"){

                }
                elseif($attendedFormat == "hexaformat"){
                   $result[$i.$regEnd.' hex'] = modbusApi\MdBus::bytes2hexAr($recData);
                }
                elseif($attendedFormat == "binaryformat"){

                }
                else{
                    $result[$i.$regEnd] = $recData;
                }
            
		  }
          catch (Exception $e) {
              $result[$i] = $e->getMessage();
              //log::add('ModbusMonitor', 'warning', __FUNCTION__.' Exception '.$e);
              //throw new Exception(__($e->getMessage(), __FILE__));
          }
        }
    	
      	if($operation != ""){
          	foreach($result as $keyReg=>$values){
              	log::add('ModbusMonitor', 'debug', __FUNCTION__." operation $key: ".$values);
        		if(is_array($values)){
                    foreach($values as $key=>$value){
                      	$newValues[$key] = self::calc($value, $operation);
                    }
                  	$result[$keyReg]=$newValues;
                    log::add('ModbusMonitor', 'debug', __FUNCTION__.' result calc: '.json_encode($result));
                }
              
              	elseif(is_numeric($values)){
        			$result[$keyReg] = self::calc($values, $operation);
        			log::add('ModbusMonitor', 'debug', __FUNCTION__.' result calc: '.json_encode($result));
                }
            }
    	}
      
      /*log::add('ModbusMonitor', 'debug', __FUNCTION__.' result '.json_encode($result).count($result));
    	$keyr = array_key_first($result);
    	$result = $result[$keyr];
    	if(is_array($result) && count($result)==1){
        	$key = array_key_first($result);
        	$result = $result[$key];
		}
    		
    	//log::add('ModbusMonitor', 'debug', __FUNCTION__.' Status '.$modbus);*/
    	return $result;
	}

/* ********************************** */
	public static function readCmd(array $config) {
		log::add('ModbusMonitor', 'debug', __FUNCTION__.' start '.json_encode($config));
		$gatwayIp = $config['gatwayIp'];
		$connectType = $config['connectType'];
		$gatwayPort = $config['gatwayPort'];
		$modbus = self::getModbus($gatwayIp, $connectType, $gatwayPort);
	
	/////////////////////////	
		log::add('ModbusMonitor', 'debug', __FUNCTION__." operation : $operation");
		$cmdParms = $config['cmdParms'];
		$slaveId = +$cmdParms['slaveId'];
		$startregister = +$cmdParms['startregister'];
        $nbregister = +$cmdParms['nbregister'];
        $functionCode = $cmdParms['functionCode'];
        $byteReverse = boolval($cmdParms['byteReverse']);
        $wordReverse = boolval($cmdParms['wordReverse']);
        $unsigned = boolval($cmdParms['unsigned']);
        $attendedFormat = $cmdParms['attendedFormat'];
        //longformat;floatformat;bitsformat;stringformat,noneformat,hexaformat,binaryformat
		$operation = $cmdParms['operation'] ?? "";
        log::add('ModbusMonitor', 'debug', __FUNCTION__." slaveId: $slaveId -- startregister: $startregister 
            -- functionCode: $functionCode -- byteReverse: $byteReverse -- wordReverse: $wordReverse 
            -- unsigned: $unsigned -- attendedFormat: $attendedFormat");
      	try {
			$result = [];//$result['']
			if(!method_exists($modbus, $functionCode)){
				throw new Exception(__("No methode corespending to '$functionCode'", __FILE__));
			}
			$recData = call_user_func_array([$modbus, $functionCode], [$slaveId, $startregister, $nbregister] );
			log::add('ModbusMonitor', 'debug', __FUNCTION__.' recData '.json_encode($recData));
		
			$nbBytes = count($recData);
			if($attendedFormat == "longformat"){
              	if($unsigned){
					 $result['Uint'] = modbusApi\MdBus::toUint($recData, $byteReverse, $wordReverse);
				}
                else{
					$result['Int'] = modbusApi\MdBus::toInt($recData, $byteReverse, $wordReverse);
				}
              	log::add('ModbusMonitor', 'debug', __FUNCTION__.' result_longformat '.json_encode($result));
               
			}
			elseif($attendedFormat == "floatformat"){
 			
			if($nbBytes>=4 && $nbBytes<8) $bitSize = 32;
				elseif($nbBytes>=8) $bitSize = 64; 
				$result['float'] = modbusApi\MdBus::bytes2Float($recData, $byteReverse, $wordReverse, $bitSize);
			}
			elseif($attendedFormat == "bitsformat"){
			
			}
			elseif($attendedFormat == "stringformat"){
 				$result['string'] = modbusApi\MdBus::bytes2string($recData);
			}
			elseif($attendedFormat == "noneformat"){
			
			}
			elseif($attendedFormat == "hexaformat"){
 				$result['hex'] = modbusApi\MdBus::bytes2hexAr($recData);
			}
			elseif($attendedFormat == "binaryformat"){
			
			}
	}
		catch (Exception $e) {
			log::add('ModbusMonitor', 'warning', __FUNCTION__.' Exception '.$e);
			throw new Exception(__($e->getMessage(), __FILE__));
   		}
    	log::add('ModbusMonitor', 'debug', __FUNCTION__.' result '.json_encode($result));
    	
      	$keyr = array_key_first($result);
    	$result = $result[$keyr];
    	if(is_array($result) && count($result)==1){
        	$key = array_key_first($result);
        	$result = $result[$key];
		}
    	/*if(is_numeric($result) && $operation != ""){
        	$result = self::calc($result, $operation);
        	log::add('ModbusMonitor', 'debug', __FUNCTION__.' result calc: '.$result);
    	}	*/
    	if($operation != ""){
          	foreach($result as $keyReg=>$values){
              	log::add('ModbusMonitor', 'debug', __FUNCTION__." operation $key: ".$values);
        		if(is_array($values)){
                    foreach($values as $key=>$value){
                      	if(is_numeric($values)) $newValues[$key] = self::calc($value, $operation);
                      	else $newValues[$key] = $value;
                    }
                  	$result[$keyReg]=$newValues;
                    log::add('ModbusMonitor', 'debug', __FUNCTION__.' result calc: '.json_encode($result));
                }
              
              	elseif(is_numeric($values)){
        			$result[$keyReg] = self::calc($values, $operation);
        			log::add('ModbusMonitor', 'debug', __FUNCTION__.' result calc: '.json_encode($result));
                }
              	else $result[$keyReg] = $value;
              
            }
    	}
      //log::add('ModbusMonitor', 'debug', __FUNCTION__.' Status '.$modbus);
        
    	return $result;
	}

/* ********************************** */
	public static function getModbus($gatwayIp, $connectType, $gatwayPort, $test=false) {
 		if (self::$_client === null){
			$client = new modbusApi\ModbusConnector($gatwayIp, $connectType, $gatwayPort);//($test_host_ip, "TCP", $client_port);
		}
 		else return self::$_client;
		
		if(!$test){
			self::$_client = $client;
			return $client;
		}else{
			try {
 				log::add('ModbusMonitor', 'debug', __FUNCTION__ ." Mode Test ('$gatwayIp', '$connectType', '$gatwayPort', '$test')");
				//$test_connect = $client->test_connect();
			}
			catch (Exception $ex) {
				$error_msg = $ex->getMessage();
				//throw new Exception($error_msg,__FILE__);
 				throw new Exception(__($error_msg, __FILE__));
			}
			if($test_connect == true){
				log::add('ModbusMonitor', 'debug', __FUNCTION__ .' Connected to gateway');
 				return true;
			}
		}
		return false;
	}

/* ********************************** */
	public static function TestCmdRead(array $config) {
	log::add('ModbusMonitor', 'debug', __FUNCTION__.' start '.json_encode($config));
		$gatwayIp = $config['gatwayIp'];
		$connectType = $config['connectType'];
		$gatwayPort = $config['gatwayPort'];
		$modbus = self::getModbus($gatwayIp, $connectType, $gatwayPort);
	
	/////////////////////////
		$cmdParms = $config['cmdParms'];
		$slaveId = +$cmdParms['slaveId'];
		$startregister = +$cmdParms['startregister'];
		$nbregister = +$cmdParms['nbregister'];
		$attendedFormat = $cmdParms['attendedFormat'];
		$byteReverse = boolval($cmdParms['byteReverse']);
		$wordReverse = boolval($cmdParms['wordReverse']);
		$unsigned = boolval($cmdParms['unsigned']);
		$functionCode = $cmdParms['functionCode'];
	/////////////////////////	
		try {
			if(!method_exists($modbus, $functionCode) ){
				throw new Exception(__("No methode corespending to '$functionCode'", __FILE__));
			}
			$recData = call_user_func_array([$modbus, $functionCode], [$slaveId, $startregister, $nbregister] );
			log::add('ModbusMonitor', 'debug', __FUNCTION__.' recData '.json_encode($recData));
	
			$result = [];//$result['']
			$result['recData'] = $recData;
			$recData16 = modbusApi\MdBus::bytes2Int_Sign($recData, false);
			$result['recData16'] = modbusApi\MdBus::bytes2Int_Sign($recData, false);
			$recData16_endian = modbusApi\MdBus::bytes2Int_Sign($recData, true);
			$result['recData16_endian'] = $recData16_endian;
			
			
			$result['string'] = modbusApi\MdBus::bytes2string($recData, $byteReverse, $wordReverse);
			//mb_convert_encoding($string, "UTF-8");
			$result['hex'] = modbusApi\MdBus::bytes2hexAr($recData);
			//log::add('ModbusMonitor', 'debug', __FUNCTION__.' string '.json_encode($result['string'])."--".$string);
				
			/*$result['unsignedInt'] = modbusApi\PhpType::bytes2unsignedInt($recData, $endianess);
				log::add('ModbusMonitor', 'debug', __FUNCTION__.' unsignedInt '.json_encode($result['unsignedInt']));
				
			$result['signedInt'] = modbusApi\PhpType::bytes2signedInt($recData, $endianess);
				//log::add('ModbusMonitor', 'debug', __FUNCTION__.' signedInt '.json_encode($result['signedInt']));
				
			$result['signedInt_Endian'] = modbusApi\PhpType::bytes2signedInt($recData, true);
				//log::add('ModbusMonitor', 'debug', __FUNCTION__.' signedInt_Endian '.json_encode($result['signedInt_Endian']));
				*/
			$result['float'] = modbusApi\MdBus::toFloat($recData, $byteReverse, $wordReverse);
				//log::add('ModbusMonitor', 'debug', __FUNCTION__.' float '.json_encode($result['float']));
				
				//log::add('ModbusMonitor', 'debug', __FUNCTION__.' hex '.json_encode($result['hex']));
				/*
					*/
			$nbBytes = count($recData);
			if($nbBytes>=2 && $nbBytes<4){
				$result['Int16'] = modbusApi\MdBus::bytes2Int_Sign($recData, false);
				$result['Int16_byteReverse'] = modbusApi\MdBus::bytes2Int_Sign($recData, true);
				$result['Uint16'] = modbusApi\MdBus::bytes2Int_Usign($recData, false);
				$result['Uint16_byteReverse'] = modbusApi\MdBus::bytes2Int_Usign($recData, true);
			}
			if($nbBytes>=4 && $nbBytes<8){
				$Int32 = modbusApi\MdBus::bytes2Int_Sign($recData, false, false, 32);
				$result['Int32_wordReverse'] = modbusApi\MdBus::bytes2Int_Sign($recData, false, true, 32);
				$result['Int32'] = $Int32;
				$result['Int32_wordReverse_byteReverse'] = modbusApi\MdBus::bytes2Int_Sign($recData, true, true, 32);
				$result['Int32_byteReverse'] = modbusApi\MdBus::bytes2Int_Sign($recData, true, false, 32);
				
 				$Uint32 = modbusApi\MdBus::bytes2Int_Usign($recData, false, false, 32);
 				if($Uint32 != $Int32 || $unsigned){
					$result['Uint32'] = $Uint32;
					$result['Uint32_wordReverse'] = modbusApi\MdBus::bytes2Int_Usign($recData, false, true, 32);
					$result['Uint32_byteReverse'] = modbusApi\MdBus::bytes2Int_Usign($recData, true, false, 32);
					$result['Uint32_byteReverse_wordReverse'] = modbusApi\MdBus::bytes2Int_Usign($recData, true, true, 32);
				}
			
 				//$float32 = modbusApi\MdBus::bytes2Float($recData, false, false, 32);
				$result['float32_wordReverse'] = modbusApi\MdBus::bytes2Float($recData, false, true, 32);
				$result['float32'] = modbusApi\MdBus::bytes2Float($recData, false, false, 32);
 				$result['float32_byteReverse_wordReverse'] = modbusApi\MdBus::bytes2Float($recData, true, true, 32);
 				$result['float32_byteReverse'] = modbusApi\MdBus::bytes2Float($recData, true, false, 32);
			}
			if($nbBytes>=8){
				$Int64 = modbusApi\MdBus::bytes2Int_Sign($recData, false, false, 64);
				$result['Int64_wordReverse'] = modbusApi\MdBus::bytes2Int_Sign($recData, false, true, 64);
				$result['Int64'] = $Int64;
				$result['Int64_wordReverse_byteReverse'] = modbusApi\MdBus::bytes2Int_Sign($recData, true, true, 64);
				$result['Int64_byteReverse'] = modbusApi\MdBus::bytes2Int_Sign($recData, true, false, 64);
				
 				$Uint64 = modbusApi\MdBus::bytes2Int_Usign($recData, false, false, 64);
 				if($Uint64 != $Int64 || $unsigned){
					$result['Uint64'] = $Uint64;
					$result['Uint64_wordReverse'] = modbusApi\MdBus::bytes2Int_Usign($recData, false, true, 64);
					$result['Uint64_byteReverse'] = modbusApi\MdBus::bytes2Int_Usign($recData, true, false, 64);
					$result['Uint64_byteReverse_wordReverse'] = modbusApi\MdBus::bytes2Int_Usign($recData, true, true, 64);
				}
 				$float64 = modbusApi\MdBus::bytes2Float($recData, false, false, 64);
				$result['float64_wordReverse'] = modbusApi\MdBus::bytes2Float($recData, false, true, 64);
				$result['float64'] = $float64;
				$result['float64_wordReverse_byteReverse'] = modbusApi\MdBus::bytes2Float($recData, true, true, 64);
 				$result['float64_byteReverse'] = modbusApi\MdBus::bytes2Float($recData, true, false, 64);
				
			}
	
		}
		catch (Exception $e) {
			log::add('ModbusMonitor', 'warning', __FUNCTION__.' Exception '.$e);
			throw new Exception(__($e->getMessage(), __FILE__));
		}
		$readCmd = self::readCmd($config);
		if(is_array($readCmd)){
			$key = array_key_first($readCmd) ?? "";
			$result['cmd'.$key] = $readCmd[$key];//[0]
		}
		else $result['cmd'] = $readCmd;
	
	
		//log::add('ModbusMonitor', 'debug', __FUNCTION__.' Status '.$modbus);
		log::add('ModbusMonitor', 'debug', __FUNCTION__.' result '.json_encode($result));
		return $result;
	}

/* ********************************** */
	public static function calc($value, $operation){
		if(!is_numeric($value)){
			return "Prvided value is not valid numeric number !".$value;
		}
		if(preg_match("([\+\-\*\/])", $operation, $operators)){
			return @eval("return " . $value.$operation . ";" );
		}
		else{
 			return __FUNCTION__.":: Invalid operator Or operation !";
		}
	}




/* ********************************** */
	public function updateDevices() {
		$cmdsOptions = array();
		/*$value = array(
			'apikey' => jeedom::getApiKey('ModbusMonitor'),
			'action' => 'updateDeviceToGlobals'
		);*/
		
		$value = array();

		foreach ($this->getCmd('info') as $cmd) {
			if($cmd->getConfiguration('infobitbinary') == 'yes') {
				continue;
			}
			//limad44
			if($cmd->getIsVisible() == false) {
				continue;
			}
			$startregister = $cmd->getConfiguration('startregister');
			$nbregister = $cmd->getConfiguration('nbregister');
			$wordReverse = boolval($cmd->getConfiguration('wordReverse', 1));//'1 = bigword'
			$byteReverse = boolval($cmd->getConfiguration('byteReverse', 0));//'1 = bigbyte'
			$unsigned = boolval($cmd->getConfiguration('unsigned', 0));//'0 = signed'
			$attendedFormat = $cmd->getConfiguration('attendedFormat');
			$offset = $cmd->getConfiguration('offset', 0);
			$functionCode = $cmd->getConfiguration('functionCode');
			if($startregister && $attendedFormat && $nbregister) {

				$offset = $cmd->getConfiguration('offset', 0);
				$cmdsOptions[] = array(
						'nameCmd' => $cmd->getName(),
						'cmdId' => $cmd->getId(),
						'attendedFormat' => $attendedFormat,
						'functionCode' => $functionCode,
						'nbregister' => $nbregister,
						'startregister' => $startregister,
						'wordReverse' => $wordReverse,
						'byteReverse' => $byteReverse,
						'unsigned' => $unsigned,
						'offset' => $offset,
						'decimal' => $cmd->getConfiguration('decimalafter',0),
						'operation' => $cmd->getConfiguration('operation', "")
				);
 				log::add('ModbusMonitor', 'debug', __FUNCTION__." cmdsOptions ". $cmd->getName() ."(".$cmd->getId().") : " . json_encode($cmdsOptions));
			}
			else{
 				log::add('ModbusMonitor', 'warning', __FUNCTION__." Parametres manquants (startregister/attendedFormat/nbregister) pour la commande: " . $cmd->getName() ."(".$cmd->getId().")");
			}
	
		
		}
		//end foreach
	
		$cmdMessage = $this->getCmd('action', 'ecriturebit');
		if (is_object($cmdMessage)) {
			$start = $cmdMessage->getConfiguration('startregister');
			$wordReverse = $cmdMessage->getConfiguration('wordReverse',1);
			$byteReverse = $cmdMessage->getConfiguration('byteReverse',0);
			$attendedFormat = $cmdMessage->getConfiguration('attendedFormat');
			$offset = $cmdMessage->getConfiguration('offset', 0);
			if($start && $wordReverse && $byteReverse && $attendedFormat) {
				$cmdsOptions[] = array(
					'cmdLogical' => 'ecriturebit',
					'nameCmd' => $cmdMessage->getName(),
					'cmdId' => $cmdMessage->getId(),
					'attendedFormat' => $attendedFormat,
					'functionCode' => 'fc03',
					'nbregister' => 1,
					'startregister' => $start,
					'wordReverse' => $wordReverse,//
					'byteReverse' => $byteReverse,//$byteReverse
					'offset' => $offset
				);

			}
		}

		if ($this->getConfiguration('connectType') == 'TCP') {
			$value = array(
						'connectType' => $this->getConfiguration('connectType', 0),
						'id' => $this->getId(),
						'slaveId' => $this->getConfiguration('slaveId', 1),	
						'gatwayPort' => $this->getConfiguration('gatwayPort', 502),
						'gatwayIp' => $this->getConfiguration('gatwayIp'),
						'eqlogicName' => $this->getName(),
						'cmdsOptions' => $cmdsOptions
			);

		}
		else if ($this->getConfiguration('connectType') == 'RTU') {
			$value = array(
					'connectType' => $this->getConfiguration('connectType', 0),
					'portserial' => $this->getConfiguration('portserial', 0),
					'baudrate' => intval($this->getConfiguration('baudrate', 0)),
					'slaveId' => intval($this->getConfiguration('slaveId', 0)),
					'parity' => $this->getConfiguration('parity', 0),
					'stopbits' => intval($this->getConfiguration('stopbits', 0)),
					'bytesize' => intval($this->getConfiguration('bytesize', 0)),
					'id' => $this->getId(),
					'eqlogicName' => $this->getName(),
					'cmdsOptions' => $cmdsOptions
			);

		}
		else{
			log::add('ModbusMonitor', 'warning', __FUNCTION__." Unknown connectType" . $this->getConfiguration('connectType'));
		}
		//$deviceInfos = json_encode($value);
		log::add('ModbusMonitor', 'debug', __FUNCTION__." Equipement: " . json_encode($value));
		return self::updateEq($value);
		//return $value;
      	//self::socketConnection($value);

	}

/* ********************************** */
	public function deleteDevice() {
		if ($this->getId() == '') {
			return;
		}
		$value = json_encode([
			'apikey' => jeedom::getApiKey('ModbusMonitor'),
			'action' => 'deleteDevice',
			'deviceInfo' => ['id' => $this->getId()]
		]);
		self::socketConnection($value);
	}

// Fonction exécutée automatiquement avant la création de l'équipement
	public function preInsert() {

	}

// Fonction exécutée automatiquement après la création de l'équipement
	public function postInsert() {

	}

// Fonction exécutée automatiquement avant la mise à jour de l'équipement
	public function preUpdate() {

		if ($this->getConfiguration('gatwayIp', 'ModbusMonitor') == '') {
			throw new Exception(__('Ip du Device non rempli', __FILE__));
			message::add(__CLASS__, 'Ip du Device non rempli');
		}
	}

// Fonction exécutée automatiquement après la mise à jour de l'équipement
	public function postUpdate() {

		$cmd = $this->getCmd(null, 'ecriturebit');
		if (!is_object($cmd)) {
			$cmd = new ModbusMonitorCmd();
			$cmd->setLogicalId('ecriturebit');
			$cmd->setIsVisible(1);
			$cmd->setName(__('Ecriture Bit', __FILE__));
			$cmd->setOrder(1);
		}
		$cmd->setType('action');
		$cmd->setSubType('message');
		$cmd->setDisplay('title_placeholder', 'Changement de Bit');
		$cmd->setDisplay('message_placeholder', 'ValeurBit&PositionBit');
		$cmd->setConfiguration('functionCode', 'fc03');
		$cmd->setConfiguration('defCmd', '1');
		$cmd->setEqLogic_id($this->getId());
		$cmd->save();


		$cmd = $this->getCmd(null, 'multicoils');
		if (!is_object($cmd)) {
			$cmd = new ModbusMonitorCmd();
			$cmd->setLogicalId('multicoils');
			$cmd->setIsVisible(1);
			$cmd->setName(__('Ecriture MultiCoils', __FILE__));
			$cmd->setOrder(1);
		}
		$cmd->setType('action');
		$cmd->setSubType('message');
		$cmd->setDisplay('title_placeholder', 'Ecriture MultiCoils');
		$cmd->setDisplay('message_placeholder', 'Valeurs des Coils a la suite');
		$cmd->setEqLogic_id($this->getId());
		$cmd->setConfiguration('functionCode', 'fc15');
		$cmd->setConfiguration('defCmd', '2');
		$cmd->save();


		$cmd = $this->getCmd(null, 'infobitbinary');
		if (!is_object($cmd)) {
			$cmd = new ModbusMonitorCmd();
			$cmd->setLogicalId('infobitbinary');
			$cmd->setIsVisible(1);
			$cmd->setOrder(1);
		}
		$cmd->setName(__('LECTURE COMMANDE BINAIRE', __FILE__));
		$cmd->setType('info');
		$cmd->setSubType('string');
		$cmd->setEqLogic_id($this->getId());
		$cmd->setConfiguration('defCmd', '3');
		$cmd->setConfiguration('infobitbinary','yes');
		$cmd->save();

		$cmd = $this->getCmd(null, 'ecrituremultiRegisters');
		if (!is_object($cmd)) {
			$cmd = new ModbusMonitorCmd();
			$cmd->setLogicalId('ecrituremultiRegisters');
			$cmd->setIsVisible(1);
			$cmd->setName(__('Ecriture Multi Registre', __FILE__));
		}
		$cmd->setType('action');
		$cmd->setSubType('message');
		$cmd->setDisplay('title_placeholder', 'Ecriture Multi Registre');
		$cmd->setDisplay('message_placeholder', 'Valeur&NbRegistre|Valeur&NbRegistre');
		$cmd->setConfiguration('functionCode', 'fc16');
		$cmd->setConfiguration('defCmd', '4');
		$cmd->setEqLogic_id($this->getId());
		$cmd->save();
	}

/* ********************************** */
	public function postAjax() {
		$this->updateSliders();
		if($this->getIsEnable()){
          	$this->updateDevices();
			$this->creaCoils();
        }  
		message::removeAll(__CLASS__, 'updateslider');
          
		//self::deamon_start();
	}

/* ********************************** */
	public function preSave() {

	}

/* ********************************** */
	public function postSave() {

	}

/* ********************************** */
	public function creaCoils() {

		foreach ($this->getCmd('info') as $cmd) {
			if (is_object($cmd)) {

				$function_code = $cmd->getConfiguration('functionCode');

				if ($function_code != 'fc01' && $function_code != 'fc02') {
					continue;
				}

				$attendedFormat = $cmd->getConfiguration('attendedFormat', 'bitsformat');
				$offset = $cmd->getConfiguration('offset', 0);
				$subtype = $cmd->getSubType();
				$nbBytes = $cmd->getConfiguration('nbregister','');
				$registre_depart = $cmd->getConfiguration('startregister','');
				$wordReverse = boolval($cmd->getConfiguration('wordReverse', 1));
				$byteReverse = boolval($cmd->getConfiguration('byteReverse', 0));
				$unsigned = boolval($cmd->getConfiguration('unsigned', 0));
				if ($nbBytes >= 1 && $cmd->getConfiguration('alreadycreate') != 'yes') {
					for ($i = 0;$i < $nbBytes;$i++) {
						$newAdresseValue = intval($registre_depart) + $i;
						if ($function_code == 'fc01') {
							$cmdName = 'ReadCoil' . '_' . $newAdresseValue;
						}
						elseif ($function_code == 'fc02') {
							$cmdName = 'ReadDiscrete' . '_' . $newAdresseValue;
						}
						$newCmd = $this->getCmd(null, $cmdName);
						if (!is_object($newCmd)) {
							$newCmd = new ModbusMonitorCmd();
							$newCmd->setLogicalId($cmdName);
							$newCmd->setIsVisible(1);
							$newCmd->setName(__($cmdName, __FILE__));
						}
						$newCmd->setType('info');
						$newCmd->setSubType($subtype);
						$newCmd->setEqLogic_id($this->getId());
						$newCmd->setConfiguration('attendedFormat', $attendedFormat);
						$newCmd->setConfiguration('functionCode', $function_code);
						$newCmd->setConfiguration('wordReverse', $wordReverse);
						$newCmd->setConfiguration('byteReverse', $byteReverse);
						$newCmd->setConfiguration('unsigned', $unsigned);
						$newCmd->setConfiguration('startregister', $newAdresseValue);
						$newCmd->setConfiguration('nbregister', 1);
						$newCmd->setConfiguration('offset', $offset);
						$newCmd->setConfiguration('alreadycreate', 'yes');
						$cmd->remove();
						$newCmd->save();
					}
				}
			}
			else {
				return;
			}
		}
	}

/* ********************************** */
	public function updateSliders() {
		foreach ($this->getCmd('action') as $cmd) {
			if ($cmd->getSubType() == 'slider') {
				$stepchoice = $cmd->getConfiguration('stepchoice', 1);
				$arr = $cmd->getDisplay('parameters');
				if ($cmd->getConfiguration('attendedFormat') == 'floatformat') {
					$arr['step'] = $stepchoice;
					$cmd->setDisplay(parameters, $arr);
					$cmd->setTemplate('dashboard', 'button');
					$cmd->setTemplate('mobile', 'button');
					/*$cmd->setConfiguration('minValue', $cmd->getConfiguration('minValue', 0));
					$cmd->setConfiguration('maxValue', $cmd->getConfiguration('maxValue', 100));*/
					$cmd->save();
				}
				elseif ($cmd->getConfiguration('attendedFormat') == 'longformat') {
					$arr['step'] = 1;
					$cmd->setDisplay(parameters, $arr);
					$cmd->setTemplate('dashboard', 'default');
					$cmd->setTemplate('mobile', 'default');
					$cmd->save();
				}
				message::add(__CLASS__, 'Les commandes Sliders ont été mises à jour', 'slider', 'updateslider');
			}
		}

	}

/* ********************************** */
	public function preRemove() {
		$this->deleteDevice();
		sleep(1);
		//self::deamon_start();
	}


/* ********************************** */
	public function postRemove() {

	}



	/*
	* Non obligatoire : permet de modifier l'affichage du widget (également utilisable par les commandes)
		public function toHtml($_version = 'dashboard') {

		}
	*/

	/*
	* Non obligatoire : permet de déclencher une action après modification de variable de configuration
	public static function postConfig_<Variable>() {
	}
	*/

	/*
	* Non obligatoire : permet de déclencher une action avant modification de variable de configuration
	public static function preConfig_<Variable>() {
	}
	*/
	/* ********************************** */
	public static function socketConnection($value) {
		try {
			log::add('ModbusMonitor', 'warning', __FUNCTION__." value " . $value);
				$socket = socket_create(AF_INET, SOCK_STREAM, 0);
			//socket_set_timeout($socket, 180);
			socket_connect($socket, '127.0.0.1', config::byKey('socketport', 'ModbusMonitor', 55030));
			socket_write($socket, $value, strlen($value));
				//$response = socket_read($socket, 1000);
			//$jsonresp = json_decode($response, true);
			//log::add('ModbusMonitor', 'debug', __FUNCTION__ .' jsonresp: '.$jsonresp);
		
			socket_close($socket);
		}
		catch(Exception $e) {
			log::add('ModbusMonitor', 'debug', 'Exception reçue : ' . $e->getMessage());
		}
	}//heartbeat, interact
////////////////////////////*********************///////////////////////////////////// 
	public static function cron($eqLogicid=null, $from=__FUNCTION__) {
		log::add('ModbusMonitor', 'debug', __FUNCTION__." start ");
      	$time = time();
        foreach (eqLogic::byType('ModbusMonitor', true) as $eqLogic){
			$deviceInfos = $eqLogic->updateDevices();
          
		}
      	$laps = time() - $time;
      	log::add('ModbusMonitor', 'debug', __FUNCTION__." End in $laps secondes");
      	
      	
	}
  ////////////////////////////*********************///////////////////////////////////// 
	public static function pull($_options) {
		log::add('ModbusMonitor', 'debug', __FUNCTION__." start ");
      	foreach (eqLogic::byType('ModbusMonitor', true) as $eqLogic){
			$deviceInfos = $eqLogic->updateDevices();
		}
	}
  	public static function setCronModbusMonitor($create) {
    if($create == 1) {
      $cron = cron::byClassAndFunction(__CLASS__, 'pullModbusMonitor');
      //$cron = cron::byClassAndFunction(__CLASS__, 'pull', array('ModbusMonitor_id' => intval($this->getId())));
				
      if(!is_object($cron)) {
        $cron = new cron();
        $cron->setClass(__CLASS__);
        $cron->setFunction('pullModbusMonitor');
        //$cron->setOption($options);
		//$cron->setTimeout($this->getConfiguration('cycle', 60) + 10);
		$cron->setEnable(1);
        $cron->setDeamon(0);
        $cron->setSchedule(rand(1,59) .' * * * *');
        //$cron->setOnce(1);
		$cron->save();
      }
    }
    else {
      $cron = cron::byClassAndFunction(__CLASS__, 'pullModbusMonitor');
      if(is_object($cron)) {
        $cron->remove();
      }
    }
  }
/* ********************************** */
	public static function sendDevices(){
		
		$arrayDevices = array();
		$i = 0;
		foreach (eqLogic::byType('ModbusMonitor', true) as $eqLogic){
			$deviceInfos = $eqLogic->updateDevices();
			$arrayDevices[$i] = $deviceInfos;
			$i++;
			usleep(500);
		}
		$value = json_encode(array(
			'apikey' => jeedom::getApiKey('ModbusMonitor'),
			'action' => 'updateDeviceToGlobals',
			'deviceInfo' => $arrayDevices
			)
		);
		self::socketConnection($value);
	}

/* ********************************** */
	public static function exportJson($eqId, $cmdArray) {
		$eqLogic = eqLogic::byId($eqId);
		if(is_object($eqLogic)) {
			$arrayJson = Array();

			log::add('ModbusMonitor', 'debug', json_encode($arrayJson));
			$occurences = count($cmdArray);
			log::add('ModbusMonitor', 'debug', $occurences);
			for($i=0;$i <= $occurences; $i++) {
				log::add('ModbusMonitor', 'debug', $cmdArray[$i]);
				$cmdId = $cmdArray[$i];
				$cmd = cmd::byId($cmdArray[$i]);			
				if(is_object($cmd)) {
					$arrayJson["infos"][$i]["eqLogicID"] = $eqId;
					$arrayJson["infos"][$i]["cmdID"] = $cmdId;
					$arrayJson["infos"][$i]["cmdName"] = $cmd->getName();
					$arrayJson["infos"][$i]["type"] = $cmd->getType();
					$arrayJson["infos"][$i]["sousType"] = $cmd->getSubType();
					$arrayJson["infos"][$i]["unite"] = $cmd->getUnite();
					$arrayJson["infos"][$i]["offset"] = $cmd->getConfiguration('offset');
					$arrayJson["infos"][$i]["byteReverse"] = boolval($cmd->getConfiguration('byteReverse', 0));
					$arrayJson["infos"][$i]["wordReverse"] = boolval($cmd->getConfiguration('wordReverse', 1));
					$arrayJson["infos"][$i]["unsigned"] = boolval($cmd->getConfiguration('unsigned', 0));
					$arrayJson["infos"][$i]["nbRegister"] = $cmd->getConfiguration('nbregister');
					$arrayJson["infos"][$i]["startRegister"] = $cmd->getConfiguration('startregister');
					$arrayJson["infos"][$i]["functionCode"] = $cmd->getConfiguration('functioncode');
					$arrayJson["infos"][$i]["decimalafter"] = $cmd->getConfiguration('decimalafter');
					$arrayJson["infos"][$i]["minValue"] = $cmd->getConfiguration('minValue');
					$arrayJson["infos"][$i]["maxValue"] = $cmd->getConfiguration('maxValue');
					$arrayJson["infos"][$i]["stepchoice"] = $cmd->getConfiguration('stepchoice');	
					$arrayJson["infos"][$i]["attendedFormat"] = $cmd->getConfiguration('attendedFormat');
					$arrayJson["infos"][$i]["operation"] = $cmd->getConfiguration('operation');
					$arrayJson["infos"][$i]["isSpecific"] = $cmd->getConfiguration('isSpecific');
					$arrayJson["infos"][$i]["isHistorize"] = $cmd->getIsHistorized();//limad44
					$arrayJson["infos"][$i]["isVisible"] = $cmd->getIsVisible();//limad44
					$arrayJson["infos"][$i]["lissage"] = $cmd->getConfiguration('historizeMode', 'avg');
				}
			}
			$json = json_encode($arrayJson);

			$bytes = file_put_contents(__DIR__ . '/../../data/cmdsModbus.json', $json); 

		}else {
	log::add('ModbusMonitor', 'error', "ERREUR SUR L'EQUIPEMENT LORS DE L'EXPORT DES COMMANDES");
			return;
		}

	}

/* ********************************** */
	public static function importJson($jsonpath, $eqId) {
		$file = file_get_contents($jsonpath);
		$jsonarray = json_decode($file, TRUE);
		$eqLogic = eqLogic::byId($eqId);
		if(is_object($eqLogic)) {	
			foreach($jsonarray['infos'] as $key=>$value) {
				if($value['cmdName'] != 'Ecriture Multi Registre' && $value['cmdName'] != 'Ecriture Bit' 
          && $value['cmdName'] != 'Ecriture MultiCoils' && $value['cmdName'] != 'LECTURE COMMANDE BINAIRE') {
					$cmd = cmd::byTypeEqLogicNameCmdName('ModbusMonitor', $eqLogic->getName(), $value['cmdName']);
					if (!is_object($cmd)) {					
						$cmd = new ModbusMonitorCmd();
						$cmd->setName(__($value['cmdName'], __FILE__));
					}
					$cmd->setType($value['type']);
					$cmd->setSubType($value['sousType']);
					$cmd->setConfiguration('functioncode', $value['functionCode']);
					$cmd->setConfiguration('offset', $value['offset']);
					$cmd->setConfiguration('byteReverse', boolval($value['byteReverse']));
					$cmd->setConfiguration('wordReverse', boolval($value['wordReverse']));
					$cmd->setConfiguration('unsigned', boolval($value['unsigned']));
					$cmd->setConfiguration('attendedFormat', $value['attendedFormat']);
					$cmd->setUnite(strval($value['unite']));
					$cmd->setIsVisible(intval($value['isVisible']));
					$cmd->setIsHistorized(intval($value['isHistorize']));
					$cmd->setConfiguration('historizeMode', $value['lissage']);
					if($value['startRegister'] != '') {
						$cmd->setConfiguration('startregister', intval($value['startRegister']));
					}
					if($value['nbRegister'] != '') {
						$cmd->setConfiguration('nbregister', intval($value['nbRegister']));
					}
					if($value['minValue'] != '') {
						$cmd->setConfiguration('minValue', intval($value['minValue']));
					}
					if($value['maxValue'] != '') {
						$cmd->setConfiguration('maxValue', intval($value['maxValue']));
					}
					if($value['stepchoice'] != '') {
						$cmd->setConfiguration('stepchoice', intval($value['stepchoice']));
					}
					if($value['decimalafter'] != '') {
						$cmd->setConfiguration('decimalafter', $value['decimalafter']);
					}
					if($value['operation'] != '') {
						$cmd->setConfiguration('operation', $value['operation']);
					}															
					$cmd->setConfiguration('isSpecific', intval($value['isSpecific']));
					$cmd->setEqLogic_id($eqId);
					$cmd->save();
				}
			}
		}		
	}
	/*	* **********************Getteur Setteur*************************** */
}

class ModbusMonitorCmd extends cmd {
	/*	* *************************Attributs****************************** */

	/*
		public static $_widgetPossibility = array();
	*/

	/*	* ***********************Methode static*************************** */

	/*	* *********************Methode d'instance************************* */

	/*
	* Non obligatoire permet de demander de ne pas supprimer les commandes même si elles ne sont pas dans la nouvelle configuration de l'équipement envoyé en JS
		public function dontRemoveCmd() {
		return true;
		}
	*/

	// Exécution d'une commande
	public function execute($_options = array()) {

		if ($this->type != 'action') {
			return;
		}

		$cmdlogical = $this->getLogicalId();
		$eqLogic = $this->getEqLogic();
		$offset = $this->getConfiguration('offset', 0);
		$slaveId = intval($eqLogic->getConfiguration('slaveId', 0));

		$cmdsOptions = array(
			'nameCmd' => $this->getName(),
			'cmdId' => $this->getId(),
			'attendedFormat' => $this->getConfiguration('attendedFormat', 0),
			'functionCode' => $this->getConfiguration('functionCode', 0),
			'nbregister' => $this->getConfiguration('nbregister', 0),
			'startregister' => $this->getConfiguration('startregister', 0),
			'wordReverse' => boolval($this->getConfiguration('wordReverse', 1)),
			'byteReverse' => boolval($this->getConfiguration('byteReverse', 0)),
			'unsigned' => boolval($this->getConfiguration('unsigned', 0)),
			'offset' => $offset,
			'operation' => $this->getConfiguration('operation',"")
		);

		$connectType = $eqLogic->getConfiguration('connectType', 0);

		$value = (array(
			'apikey' => jeedom::getApiKey('ModbusMonitor'),
			'connectType' => $connectType,
			'action' => 'writeAction',
			'slaveId' => $slaveId

		));

		$value['options'] = $cmdsOptions;	

		if ($connectType == 'RTU') {
			$value['deviceInfo'] = array(
				'connectType' => $eqLogic->getConfiguration('connectType', 0),
				'portserial' => $eqLogic->getConfiguration('portserial', 0),
				'baudrate' => intval($eqLogic->getConfiguration('baudrate', 0)),
				'slaveId' => $slaveId,
				'parity' => $eqLogic->getConfiguration('parity', 0),
				'stopbits' => intval($eqLogic->getConfiguration('stopbits', 0)),
				'bytesize' => intval($eqLogic->getConfiguration('bytesize', 0)),
				'id' => $eqLogic->getId()
			);

		}
		elseif ($connectType == 'TCP') {
			$value['deviceInfo'] = array(
				'connectType' => $connectType,
				'id' => $eqLogic->getId(),
				'gatwayPort' => $eqLogic->getConfiguration('gatwayPort', 502),
				'slaveId' => $eqLogic->getConfiguration('slaveId', 1),
				'gatwayIp' => $eqLogic->getConfiguration('gatwayIp', 'ModbusMonitor')
			);

		}


		if ($this->getSubtype() == 'slider') {
			if ($this->getConfiguration('startregister') == '') {
				log::add('ModbusMonitor', 'info', 'Registre de depart non renseigne pour Commande : '.$this->getName());
				return;
			}
			if($this->getConfiguration('attendedFormat') == 'floatformat') {
					$value['options']['value'] = floatval($_options['slider']);
			}elseif($this->getConfiguration('attendedFormat') == 'longformat' && $this->getConfiguration('functionCode') != 'fc06') {
				$value['options']['value'] = intval($_options['slider']);
			}
		}



		if ($this->getSubtype() == 'message') {

			$isSpecific = $this->getConfiguration('isSpecific');
			$arrayMultipleRegisters = explode('|', $_options['message']);
			$i = 0;
			foreach ($arrayMultipleRegisters as $k => $v) {
			list($val, $nbregister) = explode('&', $v);
				$result[$k]['nbregister'] = $nbregister;
				$arrayB = explode('!', $val);
				$result[$i]['startregister'] = $arrayB[0];
				$result[$i]['valeur'] = $arrayB[1];
				$result[$i]['specificAutomat'] = 'yes';
				$i++;
			}
			$arrayMultipleRegisters = $result;
			$value['options']['valuesrequest'] = $arrayMultipleRegisters;
			$value['options']['isSpecific'] = $isSpecific;
		}

		if ($this->getSubtype() == 'other') {
			if ($this->getConfiguration('startregister') == '') {
				log::add('ModbusMonitor', 'info', 'Registre de depart non renseigne pour Commande : '.$this->getName());
				return;

			}
			$toverif = $this->getConfiguration('valeurToAction');
			if (strlen($toverif) == 1 && ($toverif == '0' || $toverif == '1')) {
				$value['options']['value'] = $this->getConfiguration('valeurToAction');
			}
			else {
				log::add('ModbusMonitor', 'info', 'VALEUR POUR ECRITURE COIL NON VALIDE');
				return;
			}
		}
			
		if ($cmdlogical == 'ecriturebit') {
			if ($this->getConfiguration('functionCode', 0) == 'fc03') {
				$infoBinary = cmd::byEqLogicIdAndLogicalId($eqLogic->getId(), 'infobitbinary');
				if (is_object($infoBinary)) {
					$valueInfo = intval($infoBinary->execCmd());
				}
				$arrayMessageBit = explode('&', $_options['message']);
				$valueBit = $arrayMessageBit[0];
				$position = $arrayMessageBit[1];
				$arrayTemp = array_map('intval', $array = str_split($valueInfo));
				$toReplace = count($arrayTemp) - $position;
				$arrayTemp[$toReplace] = $valueBit;
				$stringToConvert = implode($arrayTemp);
				$stringDecimal = bindec($stringToConvert);
				log::add('ModbusMonitor', 'debug', 'STRINGDECIMAL ' . $stringDecimal);
				$value['options']['value'] = $stringDecimal;
				$value['options']['functionCode'] = 'fc06';
			}
		}

		if ($cmdlogical == 'ecrituremultiRegisters') {
			if ($this->getConfiguration('functionCode', 0) == 'fc16') {
				$arrayMultipleRegisters = explode('|', $_options['message']);
				foreach ($arrayMultipleRegisters as $k => $v) {
					list($val, $nbregister) = explode('&', $v);
					$result[$k]['valeur'] = $val;
					$result[$k]['nbregister'] = $nbregister;
				}
				$arrayMultipleRegisters = $result;
				$value['options']['valuesrequest'] = $arrayMultipleRegisters;
			}
		}


		if ($cmdlogical == 'multicoils') {
			if ($this->getConfiguration('functionCode', 0) == 'fc15') {
				$arrayMultipleCoils = array_map('intval', $arrayMultipleCoils = str_split($_options['message'], 1));
				foreach ($arrayMultipleCoils as $val) {
					if ($val != 0 && $val != 1) {
						log::add('ModbusMonitor', 'info', 'ERREUR DANS VOS DONNEES COILS : N ECRIRE QUE 0 ou 1');
						return;
					}
				}
				$value['options']['valuesrequest'] = $arrayMultipleCoils;
			}
		}

		$value = json_encode($value);
		log::add('ModbusMonitor', 'debug', 'WRITETEST : ' . $value);
		ModbusMonitor::socketConnection($value);

	}

	/*	* **********************Getteur Setteur*************************** */
}