# Plugin Modbus Jeedom


Plugin pour monitorer vos équipements Modbus TCP et Modbus RTU
Non compatible Wago a l heure actuelle

