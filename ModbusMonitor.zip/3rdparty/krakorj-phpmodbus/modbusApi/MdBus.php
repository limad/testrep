<?php
namespace modbusApi;
use log as log;
/**
 * modbusApi Copyright (c) 2004, 2010 Jan Krakora, WAGO Kontakttechnik GmbH & Co. KG (http://www.wago.com)
 *
 * This source file is subject to the "PhpModbus license" that is bundled
 * with this package in the file license.txt.
 *
 * @author Jan Krakora
 * @copyright Copyright (c) 2004, 2010 Jan Krakora, WAGO Kontakttechnik GmbH & Co. KG (http://www.wago.com)
 * @license PhpModbus license
 * @category modbusApi
 * @package modbusApi
 * @version $id$
 *
 */

/**
 * MdBus
 *
 * The class includes set of methods that convert the received Modbus data
 * (array of bytes) to the PHP data type, i.e. signed int, unsigned int and float.
 *
 * @author Jan Krakora
 * @copyright  Copyright (c) 2004, 2010 Jan Krakora, WAGO Kontakttechnik GmbH & Co. KG (http://www.wago.com)
 * @package modbusApi
 *
 */
use Exception;
class MdBus extends ModbusMaster {

	public static $range_Int_16=[-32768, 32767];
	public static $range_Uint_16=[0, 65535];
	
	public static $range_Int_32=[-2147483648, 2147483647];
	public static $range_Uint_32=[0, 4294967295];
	
	public static $range_Int_64=[-9223372036854775808, 9223372036854775807];
  	public static $range_Uint_64=[0, 18446744073709551615];//2^64-1
  
  /*
  *
  *
  *
  */
  /* ********************************************************************************** */	
  	public static function toInt0(array $data, $byteReverse=null, $wordReverse=null, bool $doRangeCheck = true){//: int
	 	$nbBytes = count($data);
        if($nbBytes==2){
          	$result = self::bytes2Int_Sign($data, $byteReverse, 16);
        }
      	elseif($nbBytes==4){
          	$result = self::bytes2Int_Sign($data, $byteReverse, $wordReverse, 32);
        }
      	elseif($nbBytes==6){
          	$chunked = array_chunk($data, 4);
          	$result1=self::toInt($chunked[0], $byteReverse, $wordReverse);
            $result2=array_chunk(self::toInt($chunked[1], $byteReverse, $wordReverse));
            $result[] = +($result1.".".$result2);
          	log::add('ModbusMonitor', 'warning', __CLASS__."::".__FUNCTION__." result1 ".json_encode($result2)."--". $result2."--". array_chunk($result2));
          log::add('ModbusMonitor', 'warning', __CLASS__."::".__FUNCTION__." result ".json_encode($result));
		
        }
          	
        elseif($nbBytes>=8){
          	$result = self::bytes2Int_Sign($data, $byteReverse, $wordReverse, 64);
        }
      	//$result = array_chunk($data, $nb);
      	return $result;
	}
  /* ********************************************************************************** */	
  	public static function toInt(array $data, $byteReverse=null, $wordReverse=null){//: int
	 	$nbBytes = count($data);
        if($nbBytes==2){
          	$result = self::bytes2Int_Sign($data, $byteReverse, 16);
        }
      	elseif($nbBytes==4){
          	$result = self::bytes2Int_Sign($data, $byteReverse, $wordReverse, 32);
        }
      	elseif($nbBytes==6){
          	$chunked = array_chunk($data, 4);
          	$result = [+(self::toInt($chunked[0], $byteReverse, $wordReverse).".".self::toInt($chunked[1], $byteReverse, $wordReverse))];
          	//$result[] = self::toUint($chunked[1], $byteReverse, $wordReverse);
          	log::add('ModbusMonitor', 'warning', __CLASS__."::".__FUNCTION__.' result '.json_encode($result));
		
        }
      	elseif($nbBytes>=8){
          	$result = self::bytes2Int_Sign($data, $byteReverse, $wordReverse, 64);
        }
      	return array_shift($result);
      
	}
  
  /* ********************************************************************************** */	
  	public static function toUint(array $data, $byteReverse=null, $wordReverse=null){//: int
	 	$nbBytes = count($data);
        if($nbBytes==2){
          	$result = self::bytes2Int_Usign($data, $byteReverse, 16);
        }
      	elseif($nbBytes==4){
          	$result = self::bytes2Int_Usign($data, $byteReverse, $wordReverse, 32);
        }
      	elseif($nbBytes==6){
          	$chunked = array_chunk($data, 4);
          	$result = [+(self::toUint($chunked[0], $byteReverse, $wordReverse).".".self::toUint($chunked[1], $byteReverse, $wordReverse))];
          	 log::add('ModbusMonitor', 'warning', __CLASS__."::".__FUNCTION__.' Non Conventinnel nbBytes 6 attended 2,4,8'.json_encode($result));
		
        }
      	elseif($nbBytes>=8){
          	$result = self::bytes2Int_Usign($data, $byteReverse, $wordReverse, 64);
        }
      	return array_shift($result);
      
	}
  
  /* ********************************************************************************** */	
  	public static function toFloat(array $data, $byteReverse=null, $wordReverse=null, $bitSize=16, bool $doRangeCheck = true){
	 	$nbBytes = count($data);
        if($nbBytes>=2 && $nbBytes<4){
          	$result = self::bytes2Float($data, $byteReverse, 16);
        }
      	elseif($nbBytes>=4 && $nbBytes<8){
          	$result = self::bytes2Float($data, $byteReverse, $wordReverse, 32);
        }
      	elseif($nbBytes>=8){
          	$result = self::bytes2Float($data, $byteReverse, $wordReverse, 64);
        }
      	return array_shift($result);
      
	}
  
  /* ********************************************************************************** */	
  	public static function bytes2Int_Usign($data, $byteReverse=null, $wordReverse=null, $bitSize=16) {
		$nb = $bitSize/8;
  		//$data = self::bytesRevert($data);
      	$return = [];
      	$pack_format = "C*";
  		if($bitSize==16){
          $format16 = "S";//(S,n)
          $data = self::bytesRevert($data);
  		
        }
  		if($byteReverse) $data = self::bytesRevert($data);
  		$format32 = ($wordReverse) ? "N" : "V";
  		$format64 = ($wordReverse) ? "J" : "P";
  		$format = ${"format".$bitSize};
  		$datas = array_chunk($data, $nb);
  		foreach($datas as $ar_bytes){
          	$unpack = unpack($format, pack($pack_format, ...$ar_bytes));
            if($unpack[1] !== null) $return[] = $unpack[1];
        }     
        //log::add('ModbusMonitor', 'warning', __CLASS__."::".__FUNCTION__.' return '.json_encode($return));
      
  		return $return;
  
  
	}
  
  /* ********************************************************************************** */	
  	public static function bytes2Int_Sign(array $data, $byteReverse=null, $wordReverse=null, $bitSize=16) {
		$nb = $bitSize/8;
  		if($byteReverse) $data = self::bytesRevert($data);
  		$return = [];
      	$pack_format = "c*";
  		if($bitSize==16){
          $format16 = "n";//($byteReverse) ? "v" : "n";//"S";s S v
          $data = self::bytesRevert($data);
  		}
      	//64 q,Q,J,P
      	//32 l, L,N, V
  		if($wordReverse==true){
          	$data = array_reverse($data);
        }
      	$format32 = "l";//(s,i,l)
        $format64 ="P" ;//Big(i ,l) : little q Q P
  		
      	$format = ${"format".$bitSize};
  		$datas = array_chunk($data, $nb);
  		foreach($datas as $ar_bytes){
          	$unpack = unpack($format, pack($pack_format, ...$ar_bytes));
            if($unpack[1] !== null) $return[] = $unpack[1];
        }     
        //log::add('ModbusMonitor', 'warning', __CLASS__."::".__FUNCTION__.' return '.json_encode($return));
        return $return;
  	}
  	
/* LIMAD44 array2string 8 16 32 */
	public static function bytes2hexStr(array $data, $signed=true): string {
		$asciiStr = "";
		$asciiAr = [];
		for ($i = 0; $i < count($data); $i++){
			$ascii = (string)dechex(intval($data[$i]));
			$asciiStr .= !$ascii ? "\x".$ascii : "";
		}
		return $asciiStr;//mb_convert_encoding($asciiStr, "ISO-8859-1");
	}
  /* LIMAD44 array2string 8 16 32 */
	public static function bytes2hexAr(array $data, $byteReverse=null): array {
		$ascii = "";
		$asciiAr = [];
		for ($i = 0; $i < count($data); $i+=2){
          	if($byteReverse) $byte = (($data[$i+1] & 0xFF) << 8) | (($data[$i] & 0xFF));
            else $byte = (($data[$i] & 0xFF) << 8) | (($data[$i+1] & 0xFF));
              //
			$ascii = "\x".strtoupper(dechex(intval($byte)));
			//$asciiStr .= $ascii;
			$asciiAr[] = $ascii;
			//echo "<br> ascii $i : ".$ascii;
		}
		return $asciiAr;
//echo '<br> ascii : '.$ascii;
 //echo '<br> asciiAr : '.json_encode($asciiAr).'---'.$asciiAr[2].$asciiAr[3]; 
  
	}
  /*
  *
  *
  *
  */
  	public static function bytes2Float($data, $byteReverse=null, $wordReverse=null, $bitSize=16) {
		$nb = $bitSize/8;
  		//$data = self::bytesRevert($data);
      	if($byteReverse == true) $data = self::bytesRevert($data);
  		$return = [];
      	$pack_format = "c*";
  		if($bitSize==16){
          $format16 = ($byteReverse) ? "v" : "n";//"S";$format16 = "G";//G// f, g // f,g
          //$data = self::bytesRevert($data);
  		}
  		if($wordReverse == true){
          	$data = array_reverse($data);
        }
      	$format32 = "g";// big endian
        $format64 ="e" ;//Big(i ,l) : little q Q P
  		
      	$format = ${"format".$bitSize};
  		$datas = array_chunk($data, $nb);
  		foreach($datas as $ar_bytes){
          	$unpack = unpack($format, pack($pack_format, ...$ar_bytes));
            if($unpack[1] !== null) $return[] = is_nan($unpack[1]) ? "NaN" : $unpack[1];
          	
        }     
        //if($wordReverse) $return = array_reverse($return);
  		return $return;
  
  
	}
/* LIMAD44 array2string 8 16 32 */
	public static function bytes2hex(array $data, $signed=true): string {
		if($signed){
			$intVal = self::bytes2signedInt($data);
		}else{
			$intVal = self::bytes2unsignedInt($data);
		}
		return dechex($intVal);
	}
	/* LIMAD44 array2string 8 16 32 */
	public static function bytes2string(array $data, $endianness=false): string {
		$result = '';
		$encodeType = "V";
		if($endianness){
		  $result = pack($encodeType."*", ...$data);
		}
		else{
			foreach ($data as $value){
			  $str = pack($encodeType, $value);//little endian
			  for($i = 0; $i < strlen($str); $i += 2){
					$r = strrev(substr($str, $i, 2));
					$result .= $r;
					//echo "<br> r: $i $str =>".$r;
			  }
			}
		}
		//$string = (string) trim(preg_replace( "/[\\x00-\\x20]+/" , '' , $result ), "\\x00-\\x20");
		$string =  mb_convert_encoding($result, "UTF-8");
		return $string;
	}
  
/* ********************************************************************************** */	
  	public static function bytesRevert(array $data) {
		$result = array();
		for($i = 0; $i < count($data); $i += 2){
				$result[] = $data[$i+1];
				$result[] = $data[$i];
		}
		return $result;
}
  
/* ********************************************************************************** */	
  	public static function real2float($value) {
		// get unsigned long
		$ulong = pack("L", $value);
		// set float
		$float = unpack("f", $ulong);
		
		return $float[1];
	}
  
/* ********************************************************************************** */	
  	private static function checkData(array $data, $endianness) {
		// Check the data
		$count = count($data);
		if ( $count != 2 && $count != 4) {
			if($count > 4){
				$bitSize = 16;
				$newdata = self::combineResultBytes($data, $bitSize, $endianness);
				$data = self::checkData($newdata, $endianness);
			}else{
				throw new Exception(__FUNCTION__.' The input data should be an array of 2 or 4 bytes... counted: '.$count);
			}
			return $data;
		}
		// Fill the rest of array by zeroes
		if ($count == 2) {
			$data[2] = 0;
			$data[3] = 0;
		}
		// Check the values to be number
		if (!is_numeric($data[0]) || !is_numeric($data[1]) || !is_numeric($data[2]) || !is_numeric($data[3])) {
			throw new Exception(__FUNCTION__.' Data are not numeric or the array keys are not indexed by 0,1,2 and 3');
		}

		return $data;
	}
}
/* End CLASS */
?>