<?php
namespace modbusApi;
use log as log;
/**
 * modbusApi Copyright (c) 2004, 2010 Jan Krakora, WAGO Kontakttechnik GmbH & Co. KG (http://www.wago.com)
 *
 * This source file is subject to the "PhpModbus license" that is bundled
 * with this package in the file license.txt.
 *
 * @author Jan Krakora
 * @copyright Copyright (c) 2004, 2010 Jan Krakora, WAGO Kontakttechnik GmbH & Co. KG (http://www.wago.com)
 * @license PhpModbus license
 * @category modbusApi
 * @package modbusApi
 * @version $id$
 *
 */

/**
 * PhpType
 *
 * The class includes set of methods that convert the received Modbus data
 * (array of bytes) to the PHP data type, i.e. signed int, unsigned int and float.
 *
 * @author Jan Krakora
 * @copyright  Copyright (c) 2004, 2010 Jan Krakora, WAGO Kontakttechnik GmbH & Co. KG (http://www.wago.com)
 * @package modbusApi
 *
 */
use Exception;
class PhpType extends ModbusMaster {

	public static $range_Int_16=[-32768, 32767];
	public static $range_Uint_16=[0, 65535];
	
	public static $range_Int_32=[-2147483648, 2147483647];
	public static $range_Uint_32=[0, 4294967295];
	
	public static $range_Int_64=[-9223372036854775808, 9223372036854775807];
  	public static $range_Uint_64=[0, 18446744073709551615];//2^64-1
	
/**
	 * bytes2float
	 *
	 * The function converts array of 4 bytes to float. The return value
	 * depends on order of the input bytes (endianning).
	 *
	 * @param array $values
	 * @param bool $endianness
	 * @return float
	 */
	public static function bytes2float($values, $endianness=false) {
		$data = array();
		$real = 0;

		// Set the array to correct form
		$data = self::checkData($values, $endianness);
		// log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__.' checkData : '.json_encode($data));
		// Combine bytes
		//$real = self::combineResultBytes($data, 16, $endianness);
		$real = self::combineBytes($data, $endianness);
		//log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__.' real : '.json_encode($real));
		// Convert the real value to float
		$return = (float) self::real2float($real);
		//log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__.' '.$return);
		return $return;
	}

/**
	 * bytes2signedInt
	 *
	 * The function converts array of 2 or 4 bytes to signed integer.
	 * The return value depends on order of the input bytes (endianning).
	 *
	 * @param array $values
	 * @param bool $endianness
	 * @return int
	 */
	public static function bytes2signedInt($values, $endianness=false) {
		$data = array();
		$int = 0;
		// Set the array to correct form
		$data = self::checkData($values, $endianness);
		log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__.' checkData : '.json_encode($data));
		// Combine bytes
		//$int = self::combineResultBytes($data, 16, $endianness);;
		$int = self::combineBytes($data, $endianness);
		log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__.' combineBytes int: '.json_encode($int)."--".(0x8000 & $int));
		//$int = $data;// In the case of signed 2 byte value convert it to 4 byte one
		if ((count($values) == 2) && ((0x8000 & $int) > 0)) {
			$int = 0xFFFF8000 | $int;
			log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__.' int : '.json_encode($int));
		
		}
		// Convert the value
		return (int) self::dword2signedInt($int);
	}

/**
	 * bytes2unsignedInt
	 *
	 * The function converts array of 2 or 4 bytes to unsigned integer.
	 * The return value depends on order of the input bytes (endianning).
	 *
	 * @param array $values
	 * @param bool $endianness
	 * @return int|float
	 */
	public static function bytes2unsignedInt($values, $endianness=false) {
		$data = array();
		$int = 0;
		// Set the array to correct form
		$data = self::checkData($values, $endianness);
		// Combine bytes
		//$int = self::combineResultBytes($data, 16, $endianness);;
		$int = self::combineBytes($data, $endianness);
		// Convert the value
		return self::dword2unsignedInt($int);
	}

/**
	 * bytes2string
	 *
	 * The function converts an values array to the string. The function detects
	 * the end of the string by 0x00 character as defined by string standards.
	 *
	 * @param array $values
	 * @param bool $endianness
	 * @return string
	 */
	public static function bytes2string_ori($values, $endianness=false) {
		// Prepare string variable
		$str = "";
		// Parse the received data word array
		for($i=0;$i<count($values);$i+=2) {
			if ($endianness) {
				if($values[$i] != 0)
					$str .= chr($values[$i]);
				else
					continue;
				if($values[$i+1] != 0)
					$str .= chr($values[$i+1]);
				else
					break;
			}
			else {
				if($values[$i+1] != 0)
					$str .= chr($values[$i+1]);
				else
					continue;
				if($values[$i] != 0)
					$str .= chr($values[$i]);
				else
					break;
			}
		}
		// return string
		return $str;
	}
  	
/* ********************************************************************************** */	
  	public static function bytes2stringv($values, $endianness=false) {
		// Prepare string variable
		$str = "";
		// Parse the received data word array
		for($i=0;$i<count($values);$i+=2) {
			if ($endianness) {
				if($values[$i] != 0) $str .= chr($values[$i]);
				/*else
					continue;*/
				if($values[$i+1] != 0) $str .= chr($values[$i+1]);
			}	
			else {
				if($values[$i+1] != 0) $str .= chr($values[$i+1]);
				if($values[$i] != 0) $str .= chr($values[$i]);
			}
		}
		// return string
		return $str;
	}
  	
/* ********************************************************************************** */	
  	public static function bytes2string2($values, $endianness=false) {
		$count = count($values);
		if($coun>4) $return = pack("n*", ...$values);
		else $return = pack("V*", ...$values);
		return $return;
	}


  






/**
	 * real2float
	 *
	 * This function converts a value in IEC-1131 REAL single precision form to float.
	 *
	 * For more see [{@link http://en.wikipedia.org/wiki/Single_precision Single precision on Wiki}] or
	 * [{@link http://de.php.net/manual/en/function.base-convert.php PHP base_convert function commentary}, Todd Stokes @ Georgia Tech 21-Nov-2007] or
	 * [{@link http://www.php.net/manual/en/function.pack.php PHP pack/unpack functionality}]
	 *
	 * @param value value in IEC REAL data type to be converted
	 * @return float float value
	 */
	public static function real2float($value) {
		// get unsigned long
		$ulong = pack("L", $value);
		// set float
		$float = unpack("f", $ulong);
		
		return $float[1];
	}

/**
	 * dword2signedInt
	 *
	 * Switch double word to signed integer
	 *
	 * @param int $value
	 * @return int
	 */
	private static function dword2signedInt($value) {
		if ((0x80000000 & $value) != 0) {
			return -(0x7FFFFFFF & ~$value)-1;
		} else {
			return (0x7FFFFFFF & $value);
		}
	}

/**
	 * dword2signedInt
	 *
	 * Switch double word to unsigned integer
	 *
	 * @param int $value
	 * @return int|float
	 */
	private static function dword2unsignedInt($value) {
		if ((0x80000000 & $value) != 0) {
			return ((float) (0x7FFFFFFF & $value)) + 2147483648;
		} else {
			return (int) (0x7FFFFFFF & $value);
		}
	}

/**
	 * checkData
	 *
	 * Check if the data variable is array, and check if the values are numeric
	 *
	 * @param int $data
	 * @return int
	 */
	private static function checkData(array $data, $endianness) {
		// Check the data
		$count = count($data);
		if ( $count != 2 && $count != 4) {
			if($count > 4){
				$bitSize = 16;
				$newdata = self::combineResultBytes($data, $bitSize, $endianness);
				$data = self::checkData($newdata, $endianness);
			}else{
				throw new Exception(__FUNCTION__.' The input data should be an array of 2 or 4 bytes... counted: '.$count);
			}
			return $data;
		}
		// Fill the rest of array by zeroes
		if ($count == 2) {
			$data[2] = 0;
			$data[3] = 0;
		}
		// Check the values to be number
		if (!is_numeric($data[0]) ||
				!is_numeric($data[1]) ||
				!is_numeric($data[2]) ||
				!is_numeric($data[3])) {
			throw new Exception(__FUNCTION__.' Data are not numeric or the array keys are not indexed by 0,1,2 and 3');
		}

		return $data;
	}

/**
	 * combineBytes
	 *
	 * Combine bytes together
	 *
	 * @param int $data
	 * @param bool $endianness
	 * @return int
	 */
	private static function checkDatao($data) {
		// Check the data
		if (!is_array($data) ||
				count($data)<2 ||
				count($data)>4 ||
				count($data)==3) {
			throw new Exception('The input data should be an array of 2 or 4 bytes.');
		}
		// Fill the rest of array by zeroes
		if (count($data) == 2) {
			$data[2] = 0;
			$data[3] = 0;
		}
		// Check the values to be number
		if (!is_numeric($data[0]) ||
				!is_numeric($data[1]) ||
				!is_numeric($data[2]) ||
				!is_numeric($data[3])) {
			throw new Exception('Data are not numeric or the array keys are not indexed by 0,1,2 and 3');
		}

		return $data;
	}
  	
/* ********************************************************************************** */	
  	public static function combineBytes0($data, $endianness=false) {
		$value = 0;
		// Combine bytes
		if ($endianness == 0)
			$value = (($data[3] & 0xFF)<<16) |
					(($data[2] & 0xFF)<<24) |
					(($data[1] & 0xFF)) |
					(($data[0] & 0xFF)<<8);
		else
			$value = (($data[3] & 0xFF)<<24) |
					(($data[2] & 0xFF)<<16) |
					(($data[1] & 0xFF)<<8) |
					(($data[0] & 0xFF));

		return $value;
	}
  	
/* ********************************************************************************** */	
  	public static function combineResultBytes0(array $data, int $bitSize = 16, $endianness=false): array {
		$nb = $bitSize/8;
		$return = [];
		for($i = 0; $i < count($data); $i += $nb) {
			if(isset($data[$i + $nb - 1])){
				if($bitSize == 16){
					if($endianness) $byte = (($data[$i+1] & 0xFF) << 8) | (($data[$i] & 0xFF));
					else $byte = (($data[$i+1] & 0xFF)) | (($data[$i] & 0xFF) << 8);
					$return[] = $byte;
				}
				elseif($bitSize == 32){
					if(!isset($data[$i+3]) || !isset($data[$i+2])){
						$return[] = '';
					}
					if($endianness){
						$byte = (($data[$i+3] & 0xFF) << 24) |
								(($data[$i+2] & 0xFF) << 16) |
								(($data[$i+1] & 0xFF) << 8) |
								(($data[$i] & 0xFF));
					}else{
						$byte = (($data[$i+3] & 0xFF) << 16) |
								(($data[$i+2] & 0xFF) << 24) |
								(($data[$i+1] & 0xFF)) |
								(($data[$i] & 0xFF) << 8);
					}
					$return[] = $byte;
				}
			}
		}
		return $return;
	}
  	
/* ********************************************************************************** */	
  	public static function combineResultBytes(array $data, int $bitSize = 16, $endianness=false, $usign=false): array {
		$data = self::bytesRevert($data);
		if ($endianness){
			$data = array_reverse($data);
		  
		}
	
		//else $unpack_format = "V";
	
		$nb = $bitSize/8;
		$return = [];
		for($i = 0; $i < count($data); $i += $nb) {
			if(isset($data[$i + $nb - 1])){
				if($bitSize == 16){
					if (!$usign) $unpack_format = "s";
					else $unpack_format = "S";
					if ($endianness) $unpack_format = !$usign ? "n" : "v";
		
					$byte = array_shift(unpack($unpack_format, pack("CC", $data[$i], $data[$i+1]) ));
				  
					//if(!!$usign) 
					//else $byte = array_shift(unpack("S", pack("CC", $data[$i+1], $data[$i]) ));
					$return[] = $byte;
				}
				elseif($bitSize == 32){
					if(!isset($data[$i+3]) || !isset($data[$i+2])){
						$return[] = '';
					}
					if (!$usign) $unpack_format = "l";
					else $unpack_format = "L";
					if ($endianness){
					  $unpack_format = "N";//"V""N"
					  $unpack_format = !$usign ? "V" : "N";
					  $data = self::bytesRevert($data);
					}
					$byte = array_shift(unpack($unpack_format, pack("C*", ...$data) ));
					$return[] = $byte;
				}
			}
		}
		if ($endianness){
			$return = array_reverse($return);
		}
		return $return;
	}
  	
/* ********************************************************************************** */	
  	public static function bytes2Int16(array $dataR, bool $byteReverse=null, bool $wordReverse=null): array {
		$pack_format="C*";
		$return = [];
		$returnAr = [];
	  for($i = 0; $i < count($dataR); $i += 2) {
		$data = [$dataR[$i], $dataR[$i+1]];
		if (!$byteReverse){
				$unpack_format = "s";
				$data = self::bytesRevert($data);
			}else{
				$unpack_format = "s";
			}
		/*elseif ($byteReverse && !$wordReverse){
				$unpack_format = "V";
			}elseif ($byteReverse && $wordReverse){
				$unpack_format = "N";
				$data = self::bytesRevert($data);
			}
			*/
			$result = unpack($unpack_format, pack($pack_format, ...$data));
			
		
			$return[] = array_shift($result); 
			//$returnAr[] = $result;
			log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__." i: $i  --data : ".json_encode($data)." --result : ".json_encode($return));
		
		}
		return $return;
	}
  	
/* ********************************************************************************** */	
  	public static function bytes2Uint16(array $dataR, bool $byteReverse=null): array {
		$pack_format="C*";
		$return = [];
		$returnAr = [];
	  for($i = 0; $i < count($dataR); $i += 2) {
		$data = [$dataR[$i], $dataR[$i+1]];
		if (!$byteReverse){
				$unpack_format = "n";
				//$data = self::bytesRevert($data);
			}else{
				$unpack_format = "v";
			}
		$result = unpack($unpack_format, pack($pack_format, ...$data));
			
		
			$return[] = array_shift($result); 
			//$returnAr[] = $result;
			log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__." i: $i  --data : ".json_encode($data)." --result : ".json_encode($return));
		
		}
		return $return;
	}
  	
/* ********************************************************************************** */	
  	public static function bytes2Uint32(array $dataR, bool $byteReverse=null, bool $wordReverse=null): array {
		$pack_format="C*";
		$return = [];
		$returnAr = [];
	  for($i = 0; $i < count($dataR); $i += 4) {
		$data = [$dataR[$i], $dataR[$i+1], $dataR[$i+2], $dataR[$i+3]];
			if (!$byteReverse && !$wordReverse){
				$unpack_format = "V";
				$data = self::bytesRevert($data);
			}elseif (!$byteReverse && $wordReverse){
				$unpack_format = "N";
			 }elseif ($byteReverse && !$wordReverse){
				$unpack_format = "V";
			}elseif ($byteReverse && $wordReverse){
				$unpack_format = "N";
				$data = self::bytesRevert($data);
			}
			$result = unpack($unpack_format, pack($pack_format, ...$data));
			
		
			$return[] = array_shift($result); 
			//$returnAr[] = $result;
			log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__." i: $i  --data : ".json_encode($data)." --result : ".json_encode($return));
		
		}
		return $return;}
  	
/* ********************************************************************************** */	
  	public static function bytes2Int32(array $dataR, bool $byteReverse=null, bool $wordReverse=null): array {
		$pack_format="C*";
		$return = [];
		$returnAr = [];
		for($i = 0; $i < count($dataR); $i += 4) {
			$data = [$dataR[$i], $dataR[$i+1], $dataR[$i+2], $dataR[$i+3]];
			if (!$byteReverse && !$wordReverse){
				$unpack_format = "l";
				$data = self::bytesRevert($data);
			}elseif (!$byteReverse && $wordReverse){
				$unpack_format = "N";
			}
			elseif ($byteReverse && !$wordReverse){
				$unpack_format = "V";
			}elseif ($byteReverse && $wordReverse){
				$unpack_format = "N";
				$data = self::bytesRevert($data);
			}
			
			$result = unpack($unpack_format, pack($pack_format, ...$data));
			
		
			$return[] = array_shift($result); 
			//$returnAr[] = $result;
			log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__." i: $i  --data : ".json_encode($data)." --result : ".json_encode($return));
		
		}
		return $return;
	}
  	
/* ********************************************************************************** */	
  	public static function bytes2Uint64(array $dataR, bool $byteReverse=null, bool $wordReverse=null): array {
      	//data32b[2] * 4294967296 + data32b[1] OR data32b[1] * 4294967296 + data32b[2]
		$pack_format="C*";
		$return = [];
		$returnAr = [];
	  	for($i = 0; $i < count($dataR); $i += 8) {
			$data = [
              		$dataR[$i], $dataR[$i+1], $dataR[$i+2], $dataR[$i+3],
                	$dataR[$i+4], $dataR[$i+5], $dataR[$i+6], $dataR[$i+7]
            ];
			if (!$byteReverse && !$wordReverse){
				$unpack_format = "P";
				$data = self::bytesRevert($data);
			}elseif (!$byteReverse && $wordReverse){
				$unpack_format = "J";
			 }elseif ($byteReverse && !$wordReverse){
				$unpack_format = "P";
			}elseif ($byteReverse && $wordReverse){
				$unpack_format = "J";
				$data = self::bytesRevert($data);
			}
			$result = unpack($unpack_format, pack($pack_format, ...$data));
			
		
			$return[] = array_shift($result); 
			//$returnAr[] = $result;
			log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__." i: $i  --data : ".json_encode($data)." --result : ".json_encode($return));
		
		}
		return $return;}
  	
/* ********************************************************************************** */	
  	public static function bytes2Int64(array $dataR, bool $byteReverse=null, bool $wordReverse=null): array {
		$pack_format="C*";
		$return = [];
		$returnAr = [];
		for($i = 0; $i < count($dataR); $i += 8) {
			$data = [
              		$dataR[$i], $dataR[$i+1], $dataR[$i+2], $dataR[$i+3],
                	$dataR[$i+4], $dataR[$i+5], $dataR[$i+6], $dataR[$i+7]
            ];
			if (!$byteReverse && !$wordReverse){
				$unpack_format = "q";
				$data = self::bytesRevert($data);
			}elseif (!$byteReverse && $wordReverse){
				$unpack_format = "J";
			}
			elseif ($byteReverse && !$wordReverse){
				$unpack_format = "P";
			}elseif ($byteReverse && $wordReverse){
				$unpack_format = "J";
				$data = self::bytesRevert($data);
			}
			
			$result = unpack($unpack_format, pack($pack_format, ...$data));
			
		
			$return[] = array_shift($result); 
			//$returnAr[] = $result;
			log::add('ModbusMonitor', 'debug', __CLASS__.'::'.__FUNCTION__." i: $i  --data : ".json_encode($data)." --result : ".json_encode($return));
		
		}
		return $return;
	}
  	

  	
/* ********************************************************************************** */	
  	public static function bytesRevert(array $data) {
		$result = array();
		for($i = 0; $i < count($data); $i += 2){
				$result[] = $data[$i+1];
				$result[] = $data[$i];
		}
		return $result;
}
  	
/* ********************************************************************************** */	
  	public static function combineBytes(array $data, $endianness=false) {
		$bitSize = 16;
		  $nb = $bitSize/8;
		$return = 0;
		for($i = 0; $i < count($data); $i += $nb) {
			if(isset($data[$i + $nb - 1])){
				if($bitSize == 16){
					if($endianness) $byte = (($data[$i+1] & 0xFF) << 8) | (($data[$i] & 0xFF));
					else $byte = (($data[$i+1] & 0xFF)) | (($data[$i] & 0xFF) << 8);
					$return += $byte;
				}
				elseif($bitSize == 32){
					if(!isset($data[$i+3]) || !isset($data[$i+2])){
						$return += 0;
					}
					if($endianness){
						$byte = (($data[$i+3] & 0xFF) << 24) |
								(($data[$i+2] & 0xFF) << 16) |
								(($data[$i+1] & 0xFF) << 8) |
								(($data[$i] & 0xFF));
					}else{
						$byte = (($data[$i+3] & 0xFF) << 16) |
								(($data[$i+2] & 0xFF) << 24) |
								(($data[$i+1] & 0xFF)) |
								(($data[$i] & 0xFF) << 8);
					}
					$return += $byte;
				}
			}
		}
		return $return;
	}
  	
/* ********************************************************************************** */	
  	public static function toInt32(int $data, int $toEndian = null, bool $doRangeCheck = true): string{
	 
	}
  	
/* ********************************************************************************** */	
  	public static function toUint32(array $data, bool $byteReverse=null, bool $wordReverse=null): int{
		$data = self::bytesRevert($data);
		$data = array_reverse($data);
		  
		
		$nb = $bitSize/8;
		$return = [];
		for($i = 0; $i < count($data); $i += 2) {
			$doubleDec = array($data[$i], $data[$i+1]);
			$return = self::getAeBytesForInt32Parse($doubleDec, $byteReverse, $wordReverse);
		}
	}
  	
/* ********************************************************************************** */	
  	private static function getAeBytesForInt32Parse(array $doubleDec, bool $byteReverse=null, bool $wordReverse=null): array {	
		//$endianness = self::getCurrentEndianness($endianness);
		if(count($doubleDec) > 2){
			throw new Exception(__FUNCTION__.' array data must count 2 values! given: '.count($doubleDec));
		}
		if($byteReverse==null && $wordReverse==null){
			$left = 'low';
			$right = 'high';
			$format = 'n';//v
		}
		elseif($byteReverse==null && $wordReverse==true){
			
			$left = 'low';
			$right = 'high';
			$format = 'n';//v
		}elseif($byteReverse==true && $wordReverse==null){
			$left = 'low';
			$right = 'high';
			$format = 'n';//v
		}
		elseif($byteReverse==true && $wordReverse==true){
			$left = 'low';
			$right = 'high';
			$format = 'n';//v
		}
		else{
			throw new Exception(__FUNCTION__.' Unsupported endianness given!');
		}
		$unpack = unpack("{$format}{$left}/{$format}{$right}", $doubleWord);
		return $unpack;
	}
	
}
/* End CLASS */
?>