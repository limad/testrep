<?php


header('Content-Type: text/plain');
require_once realpath(dirname(__FILE__) . '/../../../core/php/core.inc.php');
/*$plugPath=realpath(__DIR__ . '/../../../../plugins/naEnergie');
$thrdParty = realpath(__DIR__ . '/../../../../plugins/naEnergie/3rdparty');
$api_load='/vendor/autoload.php';
if (file_exists($thrdParty .$api_load )) {
	require_once $thrdParty . $api_load;
  	//echo $api_load ." Loaded..."."\n";
}
if (file_exists(dirname(__FILE__) . '/to_log.php')) {
	//require_once dirname(__FILE__) . '/to_log.php';
  //echo  " to_log.php Loaded..."."\n";
}
*/
$file= __FILE__;
echo "file: {$file} "."\n\n";
$dir    =  __DIR__;
echo "dir: {$dir} "."\n\n";
$files1 = scandir($dir);
echo "files1:  ".json_encode($files1)."\n\n";
$files2 = scandir($dir, 1);
echo "files2:  ".json_encode($files2)."\n\n";

$result = [];


/*foreach ($cdir as $value){
  if (!in_array($value,array(".","..")) ){// && is_dir($dir . DIRECTORY_SEPARATOR . $value)  $dir . DIRECTORY_SEPARATOR . 
      echo "Directory {$key} : {$value}"."\n\n";
    	getPhpFiles($value);
  }
  //echo "value:".$dir . DIRECTORY_SEPARATOR . $value."\n\n";
}*/
$baseDir = __DIR__.'/';//.'/'lib/
        
$cdir = scandir($baseDir);
//$cdir = scandir($dir);
foreach ($cdir as $value){
  if (!in_array($value,array(".","..")) && is_dir($dir . DIRECTORY_SEPARATOR . $value)){//$dir . DIRECTORY_SEPARATOR . 
      echo "Directory {$key} : {$value}"."\n\n";
    	//getPhpFiles($value);
  }
  //echo "value:".$dir . DIRECTORY_SEPARATOR . $value."\n\n";
}
function getPhpFiles($path){
  $files = scandir($path);
  	foreach ($files as $file){
      	$filepath = $path .DIRECTORY_SEPARATOR .$file;
      	if (!in_array($file,array(".","..")) && is_file($filepath) ){//  $dir . DIRECTORY_SEPARATOR . 
            echo "	file : ".$filepath."\n\n";
        //echo "file : {$file}"."\n\n";
        }
      //echo "value:".$dir . DIRECTORY_SEPARATOR . $value."\n\n";
    }
}