<?php
error_reporting(E_ALL);
//header('Content-type: application/json');
header('Content-Type: text/plain');
//header('Content-Type: multipart/form-data; boundary=something');
require_once realpath(dirname(__FILE__) . '/../../../core/php/core.inc.php');
/*echo 'session_id : '.session_id()."\n";  
if(session_id() == ""){
	session_start();
}

$_SESSION['sessionid'] = session_id();  
$_SESSION['handle']='';
echo $_SESSION['handle']."\n";
//session_id('na_ws');
//session_start();

echo '_SESSION : '.json_encode($_SESSION)."\n";
//echo 'session_id2 : '.session_id()."\n";  
return;
*/
$pidStatus = cache::bykey('proteo' . '_pidStat')->getValue();
$lastAlive = cache::bykey('proteo_wss' . 'lastAlive')->getValue();

//echo '['.date("d-m-Y H:i:s").'] '."🌸 \n";
echo '['.date("d-m-Y H:i:s").'] '." 🔸🔸 Starting proteo_Daemon ************************* last pidStatus: ".$pidStatus.' lastAlive : '.(time() - $lastAlive)."🔸🔸\r\n";
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Formatter\LineFormatter;
//use Monolog\Handler\FirePHPHandler;

//▶️ ❕♻️ ❌ ®️ 🟠 🔴 🟡 🟢 ⛔ 🔔
//use log as log;
//$plugPath=realpath(__DIR__ . '/../../../plugins/proteo');
$thrdParty = realpath(__DIR__ . '/../../../plugins/proteo/3rdparty');
//$api_load='/vendor/autoload.php';
$api_load='/websocket/autoload.php';
//$api_load='/textalk_websocket/vendor/autoload.php';
if (file_exists($thrdParty .$api_load )) {
	require_once $thrdParty . $api_load;
}else{
  	exit( d_log(' websocket_API not found... ') );
}
/* **************************************************************************************************** */
/*																										*/
// **************************************************************************************************** //


$_pushUrl;
$_apikey;
$_ip=""; 
$_port="";
$_hostUri = '';
//$_hostIP='51.145.143.28';
$ClientWs = null;


$_callback = function ($message, $connection = '', $type = null ){
  	global $ClientWs;
    if(is_array($message)){
      	list ($final, $data, $opcode, $masked) = $message;
  	}else{
      	$opcode = null;
        $data = $message;
    }
  	if(is_null($connection)){
		d_log("{Callback} Not connected: ".(int)$connection, 'error');
	}
  	if($opcode == 'text'){
      	$push = json_decode($data, TRUE);
		if(!$push){
          	d_log('⚠️ {Callback}'.' '.$type ." invalid push : " .$data, 'warning');
          	return;
        }
		if(isset($push['push_type'])){ //&& $push['push_type'] == "temperature_changed"
			//cache::set('proteo_wss' . 'lastAlive' , time());
				$push_type = $push['push_type'];
          		$push_param = isset($push['push_type']) ? $push['extra_params'] : false;
          	if($push_type &&  $push_param){
              	d_log("{Callback} ♻️ $opcode : " .$data, 'info');
				pushInfo("message", $data);
          	}
          
          	if($push['push_type'] != "temperature_changed"){
              	
            }
		}elseif(isset($push['error'])){
			d_log('⚠️ {Callback} '.$type ." 'error ...' : " .$push['error']['message'], 'warning');
			pushInfo($type, $data);
		}elseif(isset($push['status'])){
          
          	if ($push["status"] == "ok"){
				$timestmp= time();
                cache::set('proteo_wss' . 'lastAlive' , $timestmp);
				cache::set('proteo_wss' . 'authTime' , $timestmp);
            }
          	d_log("{Callback} " .$type." 'status' : " .$push['status'], 'info');
			pushInfo($type, $data);
        }else{
			d_log("{Callback} Unknown push type : " .$data, 'info');
			pushInfo("message", $data);
		}
    }	
	elseif($opcode == 'ping'){
		//d_log("{Callback} '$type':  ping received");
      	cache::set('proteo_wss' . 'lastAlive' , time());
		//$push = json_decode($data, TRUE);
	}
	elseif($opcode == 'pong'){
		d_log("{Callback} '$type':  pong received");
      	
		cache::set('proteo_wss' . 'lastAlive' , time());
		//$push = json_decode($data, TRUE);
	}                                        
	elseif($opcode == 'binary'){
      	d_log("{Callback} binary : " .$data, 'info');
		cache::set('proteo_wss' . 'lastAlive' , time());
		//$push = json_decode($data, TRUE);
	}                                        
	elseif($opcode == 'close'){
		d_log("❗ {Callback} " .$type ." : " .$opcode,'error');
		//$push = json_decode($data, TRUE);
	}                                        
	else{//Log message
      	$arLog=['emergency','alert','critical','error','warning','notice','info','debug'];
      	$type = ($type != null) ? strtolower($type) : 'alert'; 
      	$opcode =  ($opcode != null) ? ' Unknown opcode '.$opcode : '';
      	
      	if (strtolower($type) == 'notice') {
          	$push = json_decode($data, TRUE);
          	if ($push["status"] == "connected"){
              	$authTime = cache::bykey('proteo_wss' . 'authTime' )->getValue();
                  	
				if(isset($GLOBALS['ClientWs']) && (!$authTime || ($authTime + 30) < time() )){
                  	d_log(' {Callback::Status} : ' .$data. "...execute auth");
                    cmdExec("auth", null, 'callback');
                }
              	
              	/**/
            }
          	else{
				d_log('⚠️ {Callback::LOGN} : ' .$data, $type);
            }
        }
      	elseif (in_array(strtolower($type), $arLog)) {
			d_log(' {Callback::LOG} : ' .$data, $type);
        }else{
          	d_log('🌸 {Callback:: !} : ' .$data, 'debug');
        }
	}                                       
	readcmd();
  //ob_start();
	//ob_end_clean();
    return true;
 
  	                                            
       
};// end $_callback
process($argv);
echo '['.date("d-m-Y H:i:s").'] '."process() End / Daemon exited..."."\n";

// **************************************************************************************************** //
function process($argv){
  	//echo '['.date("d-m-Y H:i:s").'] '.__FUNCTION__." start..."."\n";
	if(isset($argv) && is_array($argv)){
  		$arg = getArg($argv);
	}elseif(is_array($_GET)){
  		$arg=$_GET;
	}
	if($arg['send']){
    	$cmd = $arg['send'];
    }
  	if($arg['ip']){
    	global $_ip;
      	$_ip = $arg['ip'];
    }
  	if($arg['port']){
    	global $_port;
      	$_port = $arg['port'];
    }
  	else{
      $_port = '23';
    }
  	
  	$_hostUri$ = $_ip.":".$_port;
    $cmd = ($arg['send']) ? "send={$arg['send']}" : (($arg['cmd']) ? $arg['cmd'] : null);
      
      //$cmd = ($arg['cmd']) ? $arg['cmd'] : null;
  	//$send = ($arg['send']) ? $arg['send'] : null;
	//echo '['.date("d-m-Y H:i:s").'] '.' cmd : '.$cmd."\n";

	$apikey = $arg['apikey'];
	//echo 'apikey : '.$apikey."\n";
	if($cmd == "Connect"){
        $tok = urldecode($arg['token']);
        if(!$tok || strlen($tok) < 57 ){
            //log::add('proteo', 'info', 'Invalid token '.$tok .'=>'.strlen($tok));
            echo '['.date("d-m-Y H:i:s").'] '.' Invalid token Argument '.$tok .'=>'.strlen($tok)."\n";
            //proteo::deamon_stop();
            exit(0);
        }
        //define("PUSHURL", urldecode($arg['url'].'apikey='.$apikey));
        global $_pushUrl;
    
      	$_pushUrl = urldecode($arg['url'].'apikey='.$apikey);
        //echo '_pushUrl : '.$_pushUrl."\n";
        writecmd("");
        wsconnect($tok);
    }
    elseif($cmd != null){
        echo '['.date("d-m-Y H:i:s").'] '.' cmd detected: [' .$cmd.']'."\n";
        writecmd($cmd);
        //die();
    }else{
      	echo '['.date("d-m-Y H:i:s").'] '.' Nothing to do: [' .$cmd.']'."\n";
    }
  	//echo '['.date("d-m-Y H:i:s").'] '.__FUNCTION__." exited..."."\n";
	
}

// **************************************************************************************************** //
function getArg($_ARG){
    $result=array();
  	if(isset($_ARG)) {
        foreach ($_ARG as $arg) {
          list($key,$value) = explode('=', $arg, 2);
          	if (isset($key) && isset($value)) {
              	$param=explode('--', $key);
                if (isset($param[0])){
                  	$keyList=$param[1];
                  	$i=1;
                  	$valList=$value;
                  	foreach($value[$i] as $suplvalue){
                      $valList .=(isset($value[$i])) ? $value[$i] : '';
                      
                    }
                	$result[$keyList] = $valList;
                }
            }
        }
	}
 	return $result;
}

// **************************************************************************************************** //
function wsconnect($tok, $forced=false){
  	//global $ClientWs;
  	global $_hostUri;
  	$_hostUri = 
  	global $_callback;
  
  	$log = 'proteo_DWS';
  	$logLevel = "DEBUG";//(proteo::$_isMaster) ? "DEBUG": null;//"DEBUG"// "INFO"// log::getLogLevel('proteo')
    $logger = new Logger('');
  	$handler = new StreamHandler(log::getPathToLog($log), $logLevel);
  	//"[%datetime%] %channel%.%level_name%: %message% %context% %extra%\n"
  	$handler->setFormatter(new LineFormatter("[%datetime%][%level_name%] : %message%\n", "Y-m-d H:i:s"));
  	$lineFormatter = new LineFormatter("[%datetime%] %channel%.%level_name%: %message%\n");
	$logger->pushHandler($handler);
	$options = [
		'callback'			=> $_callback,//function to get return
      	'persistent'		=> true,
		//'async'			=> true,
		'timeout'			=> 20,
		//'fragment_size' => 4096,
		//'context'       => null,
		//'headers'       => null,
		'return_obj'		=> false,
		'logger'			=> $logger,//(proteo::$_isMaster) ? $logger : null,
		'filter' 			=> ['text', 'binary', 'ping', 'pong', 'close'],
		'headers' 		=> [
                'Cache-Control'				=> 'no-cache',
				'Connection'            	=> 'keep-alive, Upgrade',
				'Pragma'           			=> 'no-cache',
				'Sec-WebSocket-Extensions'	=> 'permessage-deflate',
          		'Origin'       			    => 'https://my.netatmo.com',
          		'Host'						=> 'app.netatmo.net',
          		'Accept-Language'			=> 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
		],
		//'origin'        => 'https://my.netatmo.com',//null, // @deprecated
	];
  	try{
      	d_log(__FUNCTION__ ." Connecting ..." );//.HOSTURI
        
        $client = new WebSocket\Client($_hostUri, $options);//async
      	if(!$client){
      		throw new Exception(__FUNCTION__ .' client not ready',0);
        }
      	//$linked = $client->connect();
      	//sleep(3);
      	/*$i = 1;
      	while ($client->connection == true) {
			if($i >= 10){
              	//d_log(__FUNCTION__ .' '." connection  ".$client->connection);
      			break;
        	}
			d_log(__FUNCTION__ .' '.$i." connection  ".$client->connection);
      		sleep(3);
            	
			$i++;
		}
      	if($client->connection != true){
      		throw new Exception(__FUNCTION__ .' No connection');
        }
      */
      
      	$json_auth = getAuth($tok, __FUNCTION__);
       	if(!$json_auth){
      		throw new Exception(__FUNCTION__ .' unable to get json_auth');
        }else{
			$GLOBALS['ClientWs'] = $client;
          	$auth = sendAuth($json_auth, 'initial');
			if ($auth === true){
            	d_log(__FUNCTION__ .' ✔️ '." Authenticated...");//👍
				listenWS();
            }
          	elseif (!empty($auth)){
              	$msg = " {$auth} ";
            	//d_log(" !empty(auth) ".$msg );
            	$code = null;
            	if (isset($auth["error"])){
            		$msg =  $auth["error"]["message"];
            		$code = $auth["error"]["code"];
            	}
            	
              	$client->close();
            	throw new Exception($msg, $code);
			}
		}
    }
  	catch (Exception $e){
		$auth =  (!isset($auth)) ? '' : " --auth: {$auth}" ;
      	$e_msg = $e->getMessage();
		$e_code = ($e->getCode() != null) ? " --code: {$e->getCode()}" : "" ;
		$e_file = print_r(str_replace('/var/www/html/plugins/proteo', '', $e->getFile()), true)." @ Line : {$e->getLine()} ";
		$state = (!$client || !$client->isConnected()) ? " --state: Not Connected" : " --state: Connected" ;
		$msg = $e_msg." @ ".$e_file .$e_code .$state .$auth;
		//exit( d_log( __FUNCTION__ .' Failled ! exiting... '.$msg) );
      	if(!$forced){
			d_log( __FUNCTION__ . " Exception Failled to connect ($msg) retry...", "error" );
			wsconnect(null, true);
		}else{
			//$resp = array("push_type" => "Exception", "state" => $state, "read" => $read, "msg" => $msg);
			exit( d_log( __FUNCTION__ ." Exception Failled reconnect exiting... ($msg)", "error") );
		}
	}
  	catch (Error $e) {
      	$class = get_class($e);
		$par_class = get_parent_class($e); 
		$ex = error_get_last();
      	//d_log(''.__FUNCTION__ .' '."class: ".$class. ' par_class: '.$par_class.' ex:' .json_encode($ex), 'warning');
      
      
      $auth =  (!isset($auth)) ? '' : " --auth: {$auth}" ;
      	$e_msg = $e->getMessage();
		$e_code = ($e->getCode() != null) ? " --code: {$e->getCode()}" : "" ;
		$e_file = print_r(str_replace('/var/www/html/plugins/proteo', '', $e->getFile()), true)." @ Line : {$e->getLine()} ";
		//$state = (!$client || !$client->isConnected()) ? " --state: Not Connected" : " --state: Connected" ;
		$state = "unknown";
          $msg = $e_msg." @ ".$e_file .$e_code .$state .$auth;
		
      	exit( d_log( __FUNCTION__ . " Error while connecting : ".$msg , "error") );
      
    }
    
}

// **************************************************************************************************** //
function sendAuth($json_auth, $authType = 'initial', $retry = false){
  	$ClientWs = $GLOBALS['ClientWs'];
	if(!$json_auth){
      	$json_auth = getAuth(false, __FUNCTION__);
    }
  	d_log("	".__FUNCTION__ ." (_$authType) message : $json_auth " );
  	cache::set('proteo_wss' . 'authTime' , 0);
	try{
        //$status = $ClientWs->sendread($json_auth);
      	$send = $ClientWs->send($json_auth);
      	//$send = $ClientWs->pushMessage($json_auth);
      	if($authType == 'refresh'){
			return true;
        }
      	$return = false;
       	$timeStart = time();
      	do {
			//$message = $ClientWs->pullMessage();
          	$message = $ClientWs->receive();
          	d_log("	".__FUNCTION__ . " new msg :".$message);
           		$Ar_status = json_decode($message, TRUE);
                if (isset($Ar_status["status"]) && $Ar_status["status"] == "ok"){
                    cache::set('proteo_wss' . 'authTime' , $timeStart);
                  	cache::set('proteo_wss' . 'lastAlive' , $timeStart);
                    d_log("	".__FUNCTION__ ."  received status : Ok" );
                    return true;
                }
              	elseif( isset($Ar_status["error"]) ){
            		$return = ' Authtication Failled';
                  	$return .=  " server response: ".$Ar_status["error"]["message"];
            		$code = $Ar_status["error"]["code"];
                  	if($Ar_status["error"]["message"] == 'Invalid access token' && !$retry){
                        d_log("	".__FUNCTION__ .$return." retry... ", 'warning');
                      	$login = proteo_W::getlogin(true);
                        return sendAuth(null, $authType, true);
					}
                  	
                  	/*if(!$forced){
                      	d_log(__FUNCTION__ .$return." retry...", 'warning');
                  		return sendAuth($ClientWs, null, true);
                    }*/
                  	d_log("	".__FUNCTION__ ." ".$return, 'error');
                  	
                  	return $return;
                  	//throw new Exception(__FUNCTION__ .$return, $code);
            	}
          		else{
                    d_log("	".__FUNCTION__ . " response not match ");
                  	continue;
                    //return $return;
                }
           // }
          	d_log( __FUNCTION__." if exited ",'INFO');
          	if (time() >= ($timeStart + 10)) {
              	$return = ' Authtication Failled: No response after 10 sec';
          		d_log("	".__FUNCTION__." ".$return,'error');
              	//throw new Exception(__FUNCTION__ .$return);
              	break;
            }
          	
          	
		} while (!$return);
        return $return;
    }
  	catch (Exception $e) {
		d_log( __FUNCTION__ . " Exception Authtication Failled : ".$e->getMessage(), "error" );
	}
	return;
		
}
//

function listenWS(){
	d_log( __FUNCTION__ ." Start ");
    $client = $GLOBALS['ClientWs'];
  	//$callback = $GLOBALS['_callback'];
  	global $_callback;
  	if($_callback == null){
      	d_log('⚠️ '.__FUNCTION__ .' _callback is null', 'warning');
    }
  	
  	try{
		while ($client->connection) {
			//$client->receive1();
			//$client->listen($_callback);
            $client->listen($_callback);
			//$client->receive();
			//$client->receive();
			//$client->syncRreceive();
			
         } ;
       // } while ($client->connection);
            $state = $client->isConnected();
            d_log('⚠️ '.__FUNCTION__ .' '."loop exited  : ".$state, 'warning');
            if (!$state){ //error
              $resp = array("push_type" => "Exception", "state" => $state);
              writecmd("");
              cache::set('proteo_wss' . 'lastAlive' , null);
              exit( d_log('❗ '.__FUNCTION__ .' '."Daemon error ".$state, 'error') );
        	}
    } catch (Throwable $e) {
      	
		if (!($e instanceof Exception || $e instanceof Throwable)) {
              $ex = error_get_last();
          	d_log( __FUNCTION__ . " ex : ".$ex->getMessage() );
        }
      	//$auth =  (!isset($auth)) ? '' : " --auth: {$auth}" ;
      	$e_msg = $e->getMessage();
		$e_code = ($e->getCode() != null) ? " --code: {$e->getCode()}" : "" ;
		$e_file = print_r(str_replace('/var/www/html/plugins/proteo', '', $e->getFile()), true)." @ Line : {$e->getLine()} ";
		$state = (!$client || !$client->isConnected()) ? " --state: Not Connected" : " --state: Connected" ;
		$msg = $e_msg." @ ".$e_file .$e_code .$state ;
		cache::set('proteo_wss' . 'lastAlive' , null);
      	exit( d_log( __FUNCTION__ . " Error while listening : ".$msg ) );
    }
  	
}

// **************************************************************************************************** //
function d_log($data, $_level = "debug"){
  	$level = '['.strtoupper($_level).']';
  	$DateM = '['.date("d-m-Y H:i:s").']';
  	echo $DateM.$level." : ".$data."\n";
}

// **************************************************************************************************** //
function pushInfo($_url=null, $post){
  	global $_pushUrl;
    try{
      	//$apikey = jeedom::getApiKey('proteo');
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $_pushUrl);//."&".$apikey
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($curl);
        curl_close($curl);
    } catch (Exception $e){//return $result;
    	d_log( __FUNCTION__ .' Failled ! : '.$result);
	}
}

// **************************************************************************************************** //
function writecmd($cmd="") {
	cache::set('proteo_wss' . '_cmd' , $cmd);
}

// **************************************************************************************************** //
function readcmd() {
	$cmd = "";
  	//$cache = cache::bykey('proteo_wss' . '_cmd');
  	try{
        $cmd = cache::bykey('proteo_wss' . '_cmd')->getValue();
  	
        if($cmd != "") {
			cache::set('proteo_wss' . '_cmd' , "");
			cmdExec($cmd, null, 'read');
            //return $cmd;
        }
        return $cmd;
     } catch (Exception $e){//return $result;
    	d_log( __FUNCTION__ .' Failled ! : '.$cmd." ".$e->getMessage());
	}
  	ob_start();
	ob_end_clean();
}

// **************************************************************************************************** //
function cmdExec($cmd, $arg=null, $origine) {
  	d_log("👉 ".__FUNCTION__ ." executing: $cmd from $origine");
  	$cmd = strtolower($cmd);
  	if($cmd == ""){
		return;
    }
  
  
  	if($GLOBALS['ClientWs']){
          $client = $GLOBALS['ClientWs'];
    }else{
      	d_log('❗ '.__FUNCTION__ ." ClientWs is null ","error");
		$object = cache::bykey('proteo_wss' . 'wss_client')->getValue();
      	if($object != null){
			$client = unserialize($object);
    	}
      	else throw new Exception(__FUNCTION__ ." No client found ");
    }
  
    
  	if($cmd == "infos"){
		 infosWs();
    }
    elseif($cmd == "disconnect"){
		$client->close();
		infosWs();
    }
    elseif($cmd == "test"){
		$test=$client->test();
		d_log(__FUNCTION__ ." test ".$test);
    }
    elseif($cmd == "isalive"){
		$isAlive = $client->isAlive();
		if(!$isAlive) {
          	d_log(__FUNCTION__ ."  isAlive false ".$test);
        }
    }
    elseif($cmd == "auth"){
      	
		$json_auth = getAuth(false, __FUNCTION__);
		if(!$json_auth){
          	d_log('❗ '.__FUNCTION__ ." executing: ".$cmd ." : " .$json_auth, "error");
          
        }else{
        	//$auth_rsp = refreshAuth($client, $json_auth);
          	$auth_rsp = sendAuth($json_auth, 'refresh');
          	if(!$auth_rsp) {
              	d_log('❗ '.__FUNCTION__ ." refreshAuth: ".$auth_rsp, "error");
            }
        }
	}
  	elseif(substr($cmd, 0, 5) == "send="){
		$arg=substr($cmd, 5, strlen($cmd));
		d_log(__FUNCTION__ ." sending payload : ".$arg);
        //$send=$client->send("", $arg);
      	$send=$client->send($arg,"text");
    }
    elseif($cmd == "ping"){
		//$arg=substr($cmd, 5, strlen($cmd));
		d_log(__FUNCTION__ ." sending ping ");
        $send=$client->send("", 'ping');
      	
    }
	else{
		//$arg=substr($cmd, 5, strlen($cmd));
		d_log(__FUNCTION__ ." Unknown cmd ");
    }
  	return;
}

// **************************************************************************************************** //
function getAuth($_token = false, $origin = null){
	if(!$_token){
		$login = proteo_W::getlogin();
		$token = isset($login['access_token']) ? $login['access_token'] : null;
	}
  	else{
		$token = urldecode($_token);
    }
	if(!$token){
      	d_log('❗ '.__FUNCTION__ ." unable to get token "." -forced: ".$origin, "error");
      	//throw new Exception(__FUNCTION__ ." unable to get token "." -forced: ".$origin);
      	return false;
    }
	$auth = array(
                "action" => "Subscribe",
                "filter" => "all",
                "access_token" => $token,
                "app_type" => "app_magellan",//app_thermostat,app_energy,app_magellan
                "platform" => "Web",//"Android"
			);
    return json_encode($auth);
}

// **************************************************************************************************** //
function infosWs(){
  	d_log(__FUNCTION__ .' '."infosWs started ");
  	$client = $GLOBALS['ClientWs'];
  	if($client){
      	$arInfos = $client->getInfos();
		//d_log(__FUNCTION__ .' '."<pre>".json_encode($arInfos, JSON_PRETTY_PRINT)."<pre>"); 
	}else  d_log(__FUNCTION__ .' '."! client NULL"); 
}

// **************************************************************************************************** //
function OnEvent0($type = null,  $opcode = null, $data = null){
  	//d_log(__FUNCTION__ .' start '.$opcode,'info');
	//$client = $GLOBALS['ClientWs'];
	//d_log(" ".$type ." : " .$data."\n");		
	if($opcode == 'text'){
      	$push = json_decode($data, TRUE);
		if(!$push){
          	d_log('⚠️ '.__FUNCTION__ .' '.$type ." invalid push : " .$data, 'warning');
          	return;
        }
		if(isset($push['push_type'])){ //&& $push['push_type'] == "temperature_changed"
			//cache::set('proteo_wss' . 'lastAlive' , time());
			if($push['push_type'] != "temperature_changed"){
              	d_log(" ".__FUNCTION__ ." $opcode : " .$data, 'info');
				//pushInfo("message", $data);
            }
		}elseif(isset($push['error'])){
			d_log('⚠️ '.__FUNCTION__ .' '.$type ." 'error ...' : " .$push['error']['message'], 'warning');
			//pushInfo($type, $data);
		}elseif(isset($push['status'])){
          	if (isset($push["status"]) && $push["status"] == "ok"){
				$timestmp= time();
                cache::set('proteo_wss' . 'lastAlive' , $timestmp);
				//cache::set('proteo_wss' . 'authTime' , $timestmp);
            }
          	d_log(" ".__FUNCTION__ ." " .$type." 'status' : " .$push['status'], 'info');
			//pushInfo($type, $data);
        }else{
			d_log(" ".__FUNCTION__ ." Unknown push type : " .$data, 'info');
			//pushInfo("message", $data);
		}
    }	
	elseif($opcode == 'ping'){
		//d_log(" ".__FUNCTION__ ." '$type':  ping received");
      	cache::set('proteo_wss' . 'lastAlive' , time());
	}
	elseif($opcode == 'pong'){
		d_log(" ".__FUNCTION__ ." '$type':  pong received");
      	
		cache::set('proteo_wss' . 'lastAlive' , time());
	}                                        
	elseif($opcode == 'binary'){
      	d_log(" ".__FUNCTION__ ." binary : " .$data, 'warning');
		cache::set('proteo_wss' . 'lastAlive' , time());
		//$push = json_decode($data, TRUE);
	}                                        
	elseif($opcode == 'close'){
		d_log('❗ '.__FUNCTION__ .' '.$type ." : " .$opcode,'error');
	}                                        
	else{
      	$arLog=['emergency','alert','critical','error','warning','notice','info','debug'];
      	$opcode =  ($opcode != null) ? ' Unknown opcode '.$opcode : '';
      	if (in_array(strtolower($type), $arLog)) {
			d_log(' '.__FUNCTION__ .' LOG : ' .$data, $type);
        }else{
          	//$type = ($type != null) ? $type : 'warning'; 
      		d_log('⚠️ '.__FUNCTION__ .' Event : ' .$data, 'debug');
        }
	}                                        
	//ob_start();
	//ob_end_clean();
    return true;
  	                                            
       
}







// **************************************************************************************************** //

// **************************************************************************************************** //
function log_backtrace() {
        $e = new Exception();
        $s = print_r(str_replace('/var/www/html', '', $e->getTraceAsString()), true);
        echo "_log_backtrace: ".$s."\n";
  		//log::add('proteo', 'debug', $s);
    }

// **************************************************************************************************** //
function index(LoggerInterface $logger){
  	echo "_index: ".$message."\n";
    $logger->info('I just got the logger');
    $logger->error('An error occurred');

    $logger->critical('I left the oven on!', [
        // include extra "context" info in your logs
        'cause' => 'in_hurry',
    ]);

    // ...
}
// **************************************************************************************************** //
function logger0($str = '', $level = 'debug'){
        echo "logger: ".$message."\n";
  		if (is_array($str)) $str = json_encode($str);
        $function_name = debug_backtrace(false, 2)[1]['function'];
        $class_name = debug_backtrace(false, 2)[1]['class'];
        $msg = '['.$class_name.'] <'. $function_name .'> '.$str;
        log::add('proteo', $level, $msg);
  		$class = get_class($object);
  		'c' === $class[0] && 0 === strpos($class, "class@anonymous\0") ? get_parent_class($class).'@anonymous' : $class;
  		$data = call_user_func($this->callback, $data);
  //call_user_func('logger', "au bol");
  		//call_user_func(__NAMESPACE__ .'\Foo::test');
  		
  		//$bsq = new barber;
		//call_user_func(array(&$bsq,'shop'),'one','two','three');
    }

// **************************************************************************************************** //

/*
function sig_handler($signo) {
  	global $SIG;
	$SIG = false;
	global $SIG;
	$SIG = true;
}
*/
//pcntl_signal(SIGTERM, "sig_handler");
//pcntl_signal(SIGHUP, "sig_handler");

// **************************************************************************************************** //
function pdebug() {
      	 echo __FUNCTION__." start"."\n";
        $arg = func_get_args();
        ob_start();
        foreach($arg as $v) {
            var_dump($v);
        }
        $o = ob_get_contents();
        ob_end_clean();
        file_put_contents('.debug.txt', $o, FILE_APPEND);
}