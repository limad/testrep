<?php

/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */
 

try {
	require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';
	require_once dirname(__FILE__) . '/../../../proteo/core/class/proteo.class.php';
	include_file('core', 'authentification', 'php');

	if (!isConnect('admin')) {
		throw new Exception(__('401 - Accès non autorisé...', __FILE__));
	}

ajax::init();


	////////// 
	if (init('action') == 'syncData'){
		$return = proteo::connectProteo();
		//proteo::cron();
		//log::add('proteo', 'debug', ' ajax return: '.$return);
		
		if (substr($return, 0, 11) != 'bad request') {
			//log::add('proteo', 'debug', ' ajax return no bad request: '.substr($return, 11));
			//ajax::success();
            ajax::success($return);
        } else {
			log::add('proteo', 'debug', ' ajax err : '.substr($return, 11));
            ajax::error($return);
        }
	}
	
	
	////////// 
	if (init('action') == 'removeAll') {
        $return = proteo::removeAll();
        
        if ($return[0]) {
            ajax::success($return[1]);
        } else {
            ajax::error($return[1]);
        }
    }
    
    
	
///////////////////////////////////////////Graph
	
//////////    
	if (init('action') == 'getData') {
		$type = init('type');
		$path = dirname(__FILE__) . '/../../data/' . $type . '.json';
		if (!file_exists($path)) {
			log::add('proteo', 'debug', 'fichier introuvable');
			return array();
		}	else {
			log::add('proteo', 'debug', 'fichier ok');
		}
		com_shell::execute(system::getCmdSudo() . 'chmod 777 ' . $path) ;
		$lines = explode("\n", trim(file_get_contents($path)));
		$result = array();
		foreach ($lines as $line) {
			$result[] = json_decode($line, true);
		}
		ajax::success($result);
	}
///////////////////
	if (init('action') == 'cronHourly') {
		proteo::cronHourly();
		ajax::success();
	}
//////////////////	





	throw new Exception(__('Aucune methode ne correspondante à : ', __FILE__) . init('action'));
	/*     * *********Catch exeption*************** */
} catch (Exception $e) {
	ajax::error(displayExeption($e), $e->getCode());
}

?>