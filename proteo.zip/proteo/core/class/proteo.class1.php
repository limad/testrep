<?php
error_reporting(E_ALL);
/* * ***************************Includes********************************* */

require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';
//if (!class_exists('proteoAPI')) {
    //require_once dirname(__FILE__) . '/../../../proteo/3rdparty/proteoAPI.php';
//}


class proteo extends eqLogic 
{
	/*     * *************************Attributs****************************** */
	private static $_client = null;
	public static $_widgetPossibility = array('custom' => true);
	private static $_widgetType = array();
	public static $_data = array();
	public static $_conf = array();
		
	
/////////////////////////////////////*********************///////////////////////////////////// 
	public function pppreSave() {//preUpdate,preSave preInsert
        if ($this->getConfiguration('username') == '') {
			throw new Exception(__('Le champs utilisateur ne peut etre vide', __FILE__));
		}
        if ($this->getConfiguration('password') == '') {
			throw new Exception(__('Le champs mot de passe ne peut etre vide', __FILE__));
		}
    }
	
/////////////////////////////////////*********************/////////////////////////////////////	
 	public function connectProteo($cmd = null, $type = 'read'){
      	$connect = self::telnetExec('["status","about"]', 'read');
      	log::add('proteo', 'debug', __FUNCTION__ .' connect: '.json_encode($connect));
      	if($connect != false){
          	$host = config::byKey('ipProteo', 'proteo');
			$port = config::byKey('portProteo', 'proteo');
          	$return = self::addDevices($host, $port, $connect);
        }
  	}
   	public static function telnetExec($cmd = null, $type = 'read', $delay=500){//cmdExec
      $execCmd =""; 
      if($cmd == null){
      		//$cmds[] ='["status","about"]';
         $execCmd ='{"1234567":{"msgId":5, "read":["status","about"]}}'.'\n';
        //'{"1234567":{"msgId":5, "read":["status","about"]}}';
      }elseif(is_string($cmd)) {
        	//$cmds[] = $cmd;
        $execCmd ='{"1234567":{"msgId":5,"'.$type.'":'.$cmd.'}}';
      }
       
        
      $retrya = 0;
    a: 
        
		$host = config::byKey('ipProteo', 'proteo');
      	//$host = 'proteo.lan';
		$port = config::byKey('portProteo', 'proteo');
        log::add('proteo', 'debug', __FUNCTION__ .' start '.$host.':'.$port);
        //log::add('proteo', 'debug',  __FUNCTION__ .' DELAY = ' . $delay * 1000 . ' millisecondes');
		$socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
      	$connected = @socket_connect($socket, $host, $port);
      	$error = socket_last_error($socket);
      //$fsock = socket_connect($socket , $host, $port);
        $retryb = 0;
	b: 
      	if($connected){
          log::add('proteo', 'debug', __FUNCTION__ .' connected '.$host.':'.$port);
          //socket_set_block($socket);
          	//socket_set_nonblock($socket)
        	$retryb = $retryb + 1;
          	usleep($delay*1000);
                $response = '';
              	$sentcmd = @socket_write($socket, $execCmd, strlen($execCmd));
                $response = @socket_read( $socket, 4096 );
              	if($response != ''){
                    $jsonresp=json_decode($response, true)["1234567"]["read"];
                    @socket_close($socket);
                    log::add('proteo', 'debug',  __FUNCTION__ .' jsonresp: '.json_encode($jsonresp));
                  	//return;  
                 	$return = $jsonresp;
                }elseif($retryb < 6) {
                    log::add('proteo', 'debug',  __FUNCTION__ .' Retry cmd...: '.$retryb);
                    sleep(2);
                    goto b;
                }elseif($retryb >= 6) {
                    $retrya = $retrya + 1;
                    if($counta < 2) {
                        sleep(5);
                      	log::add('proteo', 'debug',  __FUNCTION__ .' Retry connection...: '.$retrya);
                        
                        @socket_close($socket);
                        goto a;
                        log::add('proteo', 'debug',  __FUNCTION__ .' countb...: '.$retryb);
                    }else{
                        log::add('proteo', 'debug',  __FUNCTION__ .' \r\nNo response Disconnecting... '.$retrya);
                        //socket_close($socket);
                        $return = false;
                    }

                }else{
                    log::add('proteo', 'debug',  __FUNCTION__ .' No response Disconnecting... '.$count);
                    @socket_close($socket);
                    $return = false;
                }
              	socket_close($socket);
        }
      	else{
          	
          
          	log::add('proteo', 'debug',  __FUNCTION__ .' Erreur de communication, Verifier l\'IP et la connectivité de station'."\n".socket_strerror($error));
          $return = false;
          
        }
        return $return;
    }
       
/////////////////////////////////////*********************///////////////////////////////////// 	
    public static function connectProteo0($type = "arg") {
		$ip = config::byKey('ipProteo', 'proteo');
		$port = config::byKey('portProteo', 'proteo');
      	log::add('proteo', 'debug', __FUNCTION__ .' start '.$ip.'---'.$port);
		
      	$url = 'http://'.$ip.':'.$port;
      	$cmd = '{"1234567":{"msgId":5, "read":["status","about"]}}';
      //$token = cache::bykey('proteo' . '_token_auth')->getValue();
		$fsock = fsockopen($ip, $port, $errno, $errstr, 10   );
      	if (! $fsock ) {
            fclose($fsock);
          throw new Exception(__('Communication error check @IP ',__FILE__));
		}else{
			fwrite($fsock, $cmd);
  			$response .= fgets($fsock, 1160);
        	log::add('proteo', 'debug', __FUNCTION__ . ' response : '.$response);
		
        }
      
      	
		return $response;
       
    }
/////////////////////////////////////*********************///////////////////////////////////// 
	
    
////////////////////////////////*********************************************////////////////////////////////////////////////
    
    
    public static function writedataStat($data) {
		
      log::add('proteo', 'info', __FUNCTION__ .' started *****************');
      $path = dirname(__FILE__) . '/../../data';
      if (!is_dir($path)) {
      	com_shell::execute(system::getCmdSudo() . 'mkdir ' . dirname(__FILE__) . '/../../data' . ' > /dev/null 2>&1;');
     	com_shell::execute(system::getCmdSudo() . 'chmod 777 -R ' . dirname(__FILE__) . '/../../data' . ' > /dev/null 2>&1;');
      	log::add('proteo', 'debug', 'Dossier data crée...');
      } else {
      	com_shell::execute(system::getCmdSudo() . 'chmod 777 -R ' . dirname(__FILE__) . '/../../data' . ' > /dev/null 2>&1;');
      	log::add('proteo', 'debug', 'Le dossier data existe, droit sudo ok');
      }
		
		file_put_contents($path.'/data.json', json_encode($data));
		log::add('proteo', 'debug', 'Fin '.__FUNCTION__);	 		  
	}
	
////////////////////////////////*********************************************////////////////////////////////////////////////
    public static function syncInfos($eqLogicid = null,$Int = null) {
        if($eqLogicid != null || $this != null){
            $eqLogic = proteo::byLogicalId($eqLogicid, 'proteo');
        }
        else if($this != null){
            $eqLogic = $this;
            $eqLogicid = $eqLogic->getLogicalId();
        }
        //log::add('proteo','debug', __FUNCTION__ .'***** ');
        log::add('proteo','debug', __FUNCTION__ .' start... * eqLogicid: '.$eqLogicid.' -> '.$eqLogic->getName());
        //$eqLogic = eqLogic::byLogicalId($eqLogicid,'proteo');
        if (!is_object($eqLogic)) {
            //continue;
        }
        $arrAll=array();
        $eqLogic->refreshWidget();
    }

/////////////////////////////////////*********************///////////////////////////////////// 
    public function preInsert() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function postInsert() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function preSave() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
        
    }

    public function preUpdate() {
       // log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function postUpdate() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function preRemove() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function postRemove() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }    
    public function postSave() {
		log::add('proteo', 'info', __FUNCTION__ .' started *****************'.$this->getName());
		$eqLogic = eqLogic::byLogicalId($this->getLogicalId(),'proteo');
		if ($this->getConfiguration('configType') != $this->getConfiguration('type')) {
			$this->makeCmd($this->getLogicalId());
		}
		//log::add('proteo', 'info', __FUNCTION__ .' started on: '.$eqLogic->getName());
    }
/////////////////////////////////////*********************///////////////////////////////////// 
    public function makeCmd($eqLogic=NULL) {
		$this->setConfiguration('configType', $this->getConfiguration('type'));
			$eqLogic=$this;
			$eqtype = $eqLogic->getConfiguration('type');
		
		log::add('proteo', 'info','        '. __FUNCTION__ .' started for: '.$eqLogic->getName());
		//////////////////////////////////////////////////	
		$cmd = $eqLogic->getCmd(null, 'refresh');
			if (! is_object($cmd)) {
				$cmd = new proteoCmd();
				$cmd->setLogicalId('refresh');
				$cmd->setIsVisible(1);
			}
		$cmd->setName(__('Rafraichir', __FILE__));
		$cmd->setType('action');
		$cmd->setSubType('other');
		$cmd->setEqLogic_id($eqLogic->getId());
		$cmd->setOrder(21);
		$cmd->save();
		//////*CMD BOX////////////////////////////////////////
		
      			////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'preFilter_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('preFilter_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat preFiltre', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'filterOne_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('filterOne_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat filtre 1', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'filterTwo_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('filterTwo_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat filtre 2', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'defect');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('defect');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Nombre de défaillances', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'uvc_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('uvc_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat uvc', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('binary');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      			////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'uvc_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('uvc_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Uvc state', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
      			////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'nb_alerts');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('nb_alerts');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Nombre d\'alertes', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'mode');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('mode');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Mode', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('binary');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
				$cmd = $eqLogic->getCmd(null, 'conso-day');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('conso-day');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Conso du jour', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'conso-week');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('conso-week');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Conso semaine', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
				$cmd = $eqLogic->getCmd(null, 'conso-month');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('conso-month');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Conso du mois', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'conso-year');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('conso-year');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Consos mensuelles', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('string');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'debit-inst');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('debit-inst');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Débit instantané', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(2);
				$cmd->save();
				////////////////////////////////////////////////////////
				$cmd = $eqLogic->getCmd(null, 'debit-moy');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('debit-moy');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Débit moyen', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(2);
				$cmd->save();
				////////////////////////////////////////////////////////
				$cmd = $eqLogic->getCmd(null, 'debit-max');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('debit-max');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Débit max', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(2);
				$cmd->save();
				
                    ////////////////////////////////////////////////////////
                    $cmd = $eqLogic->getCmd(null, 'uvcCalendar');
                    if (! is_object($cmd)) {
                        $cmd = new proteoCmd();
                        $cmd->setLogicalId('uvcCalendar');
                        $cmd->setIsVisible(1);
                    }
                    $cmd->setName(__('Horaire uvc', __FILE__));
                    $cmd->setType('info');
                    $cmd->setSubType('numeric');//binary
                    $cmd->setEqLogic_id($eqLogic->getId());
                    $cmd->setTemplate('dashboard', 'line');
                    $cmd->setTemplate('mobile', 'line');	
                    $cmd->setUnite('Mbit/s');
                    $cmd->setOrder(13);
                    $cmd->save();
                    
        		
        		////////////////////////////////////////////////////////
				$cmd = $eqLogic->getCmd(null, 'time');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('time');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Time Proteo', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//binary
				$cmd->setEqLogic_id($eqLogic->getId());
         		$cmd->setUnite('sec');
				$cmd->setOrder(14);
				$cmd->save();
				
		///////////////////////////////////////////////////////////////////////////////////////        
		/////////////////////////////////*****CMD Actions*****/////////////////////////////////
				$cmd = $eqLogic->getCmd(null, 'synctime');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('synctime');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Synchroniser date et heure', __FILE__));
				$cmd->setType('action');
				$cmd->setSubType('other');
				$cmd->setEqLogic_id($eqLogic->getId());
			   	$cmd->save();
			
			
		//$eqLogic->save();
    }
/////////////////////////////////////*********************///////////////////////////////////// 
    public static function removeAll(){
        log::add('proteo', 'debug', __FUNCTION__ . ' start ');
        $eqLogics = eqLogic::byType('proteo');
        foreach ($eqLogics as $eqLogic) {
            $eqLogic->remove();
        }
        config::remove('macBox', __CLASS__);
        return array(true,'remove ok');//'remove ok'
    }
  
/////////////////////////////////////////	
    
   	public function toHtml0($_version = 'dashboard'){
        
    }
    
////////////////////////////*********************///////////////////////////////////// 
    public static function cron5($eqLogicid=null, $from=__FUNCTION__) {
		if (config::byKey('functionality::cron::enable', 'proteo', 0) == 1){
			config::save('functionality::cron5::enable', 0, 'proteo');
			return;
		}
		$ipProteo = config::byKey('ipProteo', 'proteo');
      	$cmds = array(
                  	'["status"]',
          			'["about"]',
                  	'["consumption"]', 
                  	'["flow"]', 
                  	'["wear"]', 
                  	'["config"]', 
                  	'["rtc"]' 
          			//'["alert"]'
                  	//'["cmd"]'
				);
      
      	$return=array();
      	foreach ($cmds as $cmdRqst) {
          $cmdVal = self::telnetExec($cmdRqst, 'read');
          if($cmdVal !=''){
            
              log::add('proteo', 'debug', __FUNCTION__.' array_keys: '.json_encode(array_keys($cmdVal)));
           //array_push($return, $cmdVal);
          	$return[json_decode($cmdRqst)[0]]=array_values($cmdVal)[0];//$cmdVal[1];
          }
        }
      	log::add('proteo', 'debug', __FUNCTION__.' connect: '.json_encode($return));
      /*$state = '{"1234567":{"msgId":5,"read":["status"]}}';
		$info = '{"1234567":{"msgId":5, "read":["status","about"]}}';
		$conso = '{"1234567":{"msgId":5,"read":["status","consumption"]}}';
		$debit = '{"1234567":{"msgId":5, "read":["status","flow"]}}';
		$filterstate = '{"1234567":{"msgId":5, "read":["status","wear"]}}';
		$alert = '{"1234567":{"msgId":5, "read":["status","alert"]}}';
		$config= '{"1234567":{"msgId":5,"read":["status","config"]}}';
		$lang = '{"1234567":{"msgId":5,"read":["status","lang"]}}';
      	$write_durte = '{"1234567":{"msgId":5, "write":{"config":{"waterQ":1}}}}';
		$write_time = '{"1234567":{"msgId":5,"read":["status","rtc"]}}';
		$write_time = '{"1234567":{"msgId":5,"write":{"rtc":{"date":[8,10,2019],"time":[0,9,0]}}}}';
		$write_lang = '{"1234567":{"msgId":5,"write":{"config":{"lang":0}}}}';
      
      */
     	if ( $ipProteo == '') {
          	log::add('proteo', 'debug', __FUNCTION__.' Proteo non configurée Exiting...');
			return; 
        }
      	//proteo::cronJob($eqLogicid, __FUNCTION__);
		log::add('proteo', 'info', 'Fin '.$from .'  ************************');
	}
////////////////////////////*********************///////////////////////////////////// 
    public static function cron($eqLogicid=null, $from =__FUNCTION__) {
		if (config::byKey('functionality::cron5::enable', 'proteo', 0) == 1){
			config::save('functionality::cron::enable', 0, 'proteo');
			return;
		}
      	$ipProteo=config::byKey('ipProteo', 'proteo');
     	if ( $ipProteo =='') {
          	log::add('proteo', 'debug', __FUNCTION__.' Proteo non configurée '.$macBox.' Exiting...');
			return; 
        }
      	//proteo::cronJob($eqLogicid, __FUNCTION__);
		log::add('proteo', 'info', 'Fin '.$from .'  ************************');	
    }
////////////////////////////*********************///////////////////////////////////// 
    public static function cronJob($eqLogicid=null, $from=__FUNCTION__) {
					
		if ($eqLogicid === null){
			$eqLogicid = config::byKey('ipProteo', 'proteo');
			$box_eqLogic = proteo::byLogicalId($eqLogicid, 'proteo');
			log::add('proteo', 'info', $from .' started for Box: '.$eqLogicid.' ');
			//proteo::syncInfos($eqLogicid);
		}else{
			log::add('proteo', 'info', $from .' started for known eqLogicid: '.$eqLogicid.' ');
			//proteo::syncInfos($eqLogicid);
			
		}
		//$eqLogic = proteo::byLogicalId($eqLogicid, 'proteo');
		$maxTimeUpdate="60";//min
		
		if($eqLogicid!=null) {
			foreach (proteo::byType('proteo') as $eqLogic) {
				$plugUptime=$eqLogic->getStatus('lastCommunication');
				$struptime=date('Y-m-d H:i:s', strtotime("$plugUptime + $maxTimeUpdate minutes"));
				if ($eqLogic->getIsEnable() == 1 ) {
					$plugUptime=$eqLogic->getStatus('lastCommunication');
					if (date('Y-m-d H:i:s') > date('Y-m-d H:i:s', strtotime("$plugUptime + $maxTimeUpdate minutes"))) {
						$eqLogic->setConfiguration('UpNumberFailed', $eqLogic->getConfiguration('UpNumberFailed', 0) + 1);
						//$eqLogic->save();
						log::add('proteo', 'error', 'Erreur du '.$eqLogic->getHumanName() . ' : Attention, il n\'y a pas eu de mise à jour des données depuis : '.  date("d-m-Y H:i", strtotime($plugUptime)) .' min'.' \n Vérifier la connexion du plugin ');
					}
					/*elseif (date('Y-m-d H:i:s') > date('Y-m-d H:i:s', strtotime("$comUptime + $maxTimeUpdate minutes"))) {
						$eqLogic->setConfiguration('UpNumberFailed', $eqLogic->getConfiguration('UpNumberFailed', 0) + 1);
						//$eqLogic->save();
						log::add('proteo', 'error', 'Erreur du '.$eqLogic->getHumanName() . ' : Attention, l\'équipement est injoignable depuis le : '.  date("d-m-Y H:i", strtotime($comUptime)) .' min.'.' \n Vérifier la conectivité de l\'appereil ');
						log::add('proteo', 'debug', 'Vérifier la conectivité de l\'appereil ');
					}
					*/
					else {
						$eqLogic->setConfiguration('UpNumberFailed', 0);
						//$eqLogic->save();
					}
				}
			}
		}
		
	}
/////////////////////////////////////*********************///////////////////////////////////// 
	
}//fin class
/////////*****************************************************************************************/////////////////////
class proteoCmd extends cmd {
/////////////////////////////////////*********************///////////////////////////////////// 	
	public function execute($_options = array()) {/////////// execute
		if ($this->getType() == '') {
			log::add('proteo', 'debug',"f execute NO getType : ".$this->getType());
			return '';
		}
		$eqLogic = $this->getEqlogic();
		$action= $this->getLogicalId();
		if ($action == 'refresh') {
			log::add('proteo', 'debug',"action : " .$action.'-'.$eqLogic->getLogicalId());
			$eqLogic->cron5($eqLogic->getLogicalId());
			//$eqLogic->syncInfos($eqLogic->getLogicalId());
			//ok proteo::cron();
		}elseif ($this->getConfiguration('request') !== '') {
			if ($this->getConfiguration('post') == true) { 
				log::add('proteo', 'debug', 'execute cmd action POST: ' . $this->getName());
				$request = proteoAPI::_request($this->getConfiguration('request'), $curlMethod = 'POST');
				log::add('proteo', 'debug', 'end ' . $this->getName() . ' = ' . json_encode($request['stat']));
			}else{
				log::add('proteo', 'debug', 'execute cmd action GET: ' . $this->getName());
				$request = proteoAPI::_request($this->getConfiguration('request'));
				log::add('proteo', 'debug', 'end ' . $this->getName() . ' = ' . json_encode($request['stat']));
			}
		}// end if ($this->getConfiguration('request')
		else{
			switch ($action) {
				case 'refreshCallhistoryList':
					log::add('proteo','debug', __FUNCTION__ .' action: '.$this->getName() . ' start... '.$eqLogic->getLogicalId());
					$exec = $eqLogic->getCallhistory($eqLogic->getLogicalId());
					log::add('proteo', 'debug', 'Fin cdm: ' . $this->getName() . ' = ' . json_encode($exec));
					break;
				case 'setLastIncomingCallRead':
					log::add('proteo','debug', __FUNCTION__ .' action: '.$this->getName() . ' start... '.$eqLogic->getLogicalId());
					$cmd = $eqLogic->getCmd('info', 'lastIncomingCallRead');
                    $cmd->event(true);
                    log::add('proteo', 'debug', 'Fin cdm: ' . $this->getName() . ' = ' . json_encode($exec));
					break;
				case 'resetlastCallLost':
					$cmd = $eqLogic->getCmd('info', 'lastCallLost');
                    $cmd->event(false);
					log::add('proteo', 'debug', 'ici ' . $this->getName() . ' = ' . $xmlstr);
					break;
				default:
					log::add('proteo', 'debug', 'default cmd inconnue:' . $this->getName() . ' = ' . $xmlstr);
			} 
			//end switch ($action)
		}//end else{
		
	} //////////Fin execute

}//////////Fin class

?>