<?php
error_reporting(E_ALL);
/* * ***************************Includes********************************* */

require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';
//if (!class_exists('proteoAPI')) {
    //require_once dirname(__FILE__) . '/../../../proteo/3rdparty/proteoAPI.php';
//}


class proteo extends eqLogic 
{
	/*     * *************************Attributs****************************** */
	private static $_client = null;
	public static $_widgetPossibility = array('custom' => true);
	private static $_widgetType = array();
	public static $_data = array();
	public static $_conf = array();
		
	
/////////////////////////////////////*********************///////////////////////////////////// 
	public function pppreSave() {//preUpdate,preSave preInsert
        if ($this->getConfiguration('username') == '') {
			throw new Exception(__('Le champs utilisateur ne peut etre vide', __FILE__));
		}
        if ($this->getConfiguration('password') == '') {
			throw new Exception(__('Le champs mot de passe ne peut etre vide', __FILE__));
		}
    }
	
/////////////////////////////////////*********************/////////////////////////////////////	
 	public function connectProteo($cmd = null, $type = 'read'){
      	$connect = self::telnetExec('["status","about"]', 'read');
      	log::add('proteo', 'debug', __FUNCTION__ .' connect: '.json_encode($connect));
      	if($connect != false){
          	$host = config::byKey('ipProteo', 'proteo');
			$port = config::byKey('portProteo', 'proteo');
          	$return = self::addDevices($host, $port, $connect);
        }
  	}
   	public static function telnetExec($cmd = null, $type = 'read'){//cmdExec
      /*$state = '{"1234567":{"msgId":5,"read":["status"]}}';
		$info = '{"1234567":{"msgId":5, "read":["status","about"]}}';
		$conso = '{"1234567":{"msgId":5,"read":["status","consumption"]}}';
		$debit = '{"1234567":{"msgId":5, "read":["status","flow"]}}';
		$filterstate = '{"1234567":{"msgId":5, "read":["status","wear"]}}';
		$alert = '{"1234567":{"msgId":5, "read":["status","alert"]}}';
		$config= '{"1234567":{"msgId":5,"read":["status","config"]}}';
		$lang = '{"1234567":{"msgId":5,"read":["status","lang"]}}';
      	$write_durte = '{"1234567":{"msgId":5, "write":{"config":{"waterQ":1}}}}';
		$write_time = '{"1234567":{"msgId":5,"read":["status","rtc"]}}';
		$write_time = '{"1234567":{"msgId":5,"write":{"rtc":{"date":[8,10,2019],"time":[0,9,0]}}}}';
		$write_lang = '{"1234567":{"msgId":5,"write":{"config":{"lang":0}}}}';
      
      */
      
      
      //if($mac !='' && $mac != null && filter_var($mac, FILTER_VALIDATE_MAC))
        //$cmd ='{"1234567":{"msgId":5, "read":["status","about"]}}';
       $execCmd =""; 
      //$cmds=array();
      //$return=array();
      if($cmd == null){
      		//$cmds[] ='["status","about"]';
         $execCmd ='{"1234567":{"msgId":5, "read":["status","about"]}}'.'\n';
        //'{"1234567":{"msgId":5, "read":["status","about"]}}';
      }elseif(is_string($cmd)) {
        	//$cmds[] = $cmd;
        $execCmd ='{"1234567":{"msgId":5,"'.$type.'":'.$cmd.'}}';
      }
       
        
      $counta = 0;
      //$execCmd ='{"1234567":{"msgId":5,"'.$type.'":'.$cmd.'}}';
      //log::add('proteo', 'debug',  __FUNCTION__ .' execCmd ' . $execCmd);
      	
	a: 
        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$host = config::byKey('ipProteo', 'proteo');
      	//$host = 'proteo.lan';
		$port = config::byKey('portProteo', 'proteo');
        $delay=500;
       
		log::add('proteo', 'debug', __FUNCTION__ .' start '.$host.':'.$port);
        //log::add('proteo', 'debug',  __FUNCTION__ .' DELAY = ' . $delay * 1000 . ' millisecondes');
		$fsock = socket_connect($socket , $host, $port);
        $countb = 0;
	b: 
      	if($fsock){
        	$countb = $countb + 1;
          	//usleep($delay*500);
            //foreach ($cmds as $cmdval) {
            	usleep($delay*1000);
                $response = '';
              //	$execCmd ='{"1234567":{"msgId":5,"'.$type.'":'.$cmdval.'}}';
              	//log::add('proteo', 'debug',  __FUNCTION__ .' execCmd: '.$execCmd);  
      			//return; 
                //ok $sentcmd = socket_write($socket, $execCmd."\r\n");
          		//$execCmd='{"1234567":{"msgId":5,"read":["status"]}}'.'{"1234567":{"msgId":5, "read":["status","flow"]}}'."\r\n";
              	$sentcmd = socket_write($socket, $execCmd, strlen($execCmd));
                $response = socket_read( $socket, 2048 );
              	if($response != ''){
                    $jsonresp=json_decode($response, true)["1234567"]["read"];
                    socket_close($socket);
                    log::add('proteo', 'debug',  __FUNCTION__ .' jsonresp: '.json_encode($jsonresp));
                  	//return;  
                 	$return = $jsonresp;
                }elseif($countb < 6) {
                    log::add('proteo', 'debug',  __FUNCTION__ .' Retry cmd...: '.$countb);
                    usleep($delay*1000);
                    goto b;
                }elseif($countb >= 6) {
                    $counta = $counta + 1;
                    if($counta < 3) {
                        log::add('proteo', 'debug',  __FUNCTION__ .' Retry connection...: '.$counta);
                        usleep($delay*1000);
                        socket_close($socket);
                        goto a;
                        log::add('proteo', 'debug',  __FUNCTION__ .' countb...: '.$countb);
                    }else{
                        log::add('proteo', 'debug',  __FUNCTION__ .' \r\nNo response Disconnecting... '.$counta);
                        //socket_close($socket);
                        $return = false;
                    }

                }else{
                    log::add('proteo', 'debug',  __FUNCTION__ .' No response Disconnecting... '.$count);
                    socket_close($socket);
                    $return = false;
                }
              	socket_close($socket);
              
              
            //}//foreach
            
          
         	/* usleep($delay*100);
            
            log::add('proteo','debug', __FUNCTION__.' CONNECTED, Exec CMD : '.$cmd . " at ". 'IP :' . $host .':'. $port);
          	$sentcmd = socket_write($socket, $execCmd."\r\n");
          	usleep($delay*100);
          	$response = socket_read( $socket, 1024 );
          	*/
        }else{
          	log::add('proteo', 'debug',  __FUNCTION__ .' Erreur de communication, Verifier l\'IP et la connectivité de station');
        }
        return $return;
    }
   
  	public static function addDevices($host, $port, $response){
        log::add('proteo', 'debug','    ' .__FUNCTION__ . ' start... ');
        $host = config::byKey('ipProteo', 'proteo');
		$port = config::byKey('portProteo', 'proteo');
      	
      	$hardware = $response["about"]["hw"];
        $firmware = $response["about"]["fw"];
        $model = $response["about"]["mod"];
        $serial = $response["about"]["sn"];
        $defect = $response["status"]["defect"];
        $nb_alerts = $response["status"]["warning"];
		
      	$proteoId = $host.'|'.$serial;	
		
				$box_eqLogic = proteo::byLogicalId($proteoId, 'proteo');
				if (!is_object($box_eqLogic)) {// || $box_eqLogic->getLogicalId() != $mac
					$box_eqLogic = new proteo();
					$box_eqLogic->setIsEnable(1);
					$box_eqLogic->setIsVisible(1);
											
					$box_eqLogic->setLogicalId($proteoId);
					$box_eqLogic->setName($model);
					$box_eqLogic->setEqType_name('proteo');
					//$box_eqLogic->setConfiguration('name', $name);
					$box_eqLogic->setConfiguration('ip', $host);
					//$box_eqLogic->setConfiguration('mac', $mac);
					$box_eqLogic->setConfiguration('type', 'PV2');
					$box_eqLogic->setConfiguration('firmware', $firmware);
					$box_eqLogic->setConfiguration('sn', $serial);
					$box_eqLogic->setCategory('other', 1);
					$box_eqLogic->save();
					log::add('proteo', 'debug', 'Votre Proteo : '.$proteoId .' est correctement configurée');
					//proteo::makeCmd($box_eqLogic);
				}
				config::save('ipProteo', $host, __CLASS__);
			
			
		return $box_eqLogic;
    }
       
/////////////////////////////////////*********************///////////////////////////////////// 	
    public static function connectProteo0($type = "arg") {
		$ip = config::byKey('ipProteo', 'proteo');
		$port = config::byKey('portProteo', 'proteo');
      	log::add('proteo', 'debug', __FUNCTION__ .' start '.$ip.'---'.$port);
		
      	$url = 'http://'.$ip.':'.$port;
      	$cmd = '{"1234567":{"msgId":5, "read":["status","about"]}}';
      //$token = cache::bykey('proteo' . '_token_auth')->getValue();
		$fsock = fsockopen($ip, $port, $errno, $errstr, 10   );
      	if (! $fsock ) {
            fclose($fsock);
          throw new Exception(__('Communication error check @IP ',__FILE__));
		}else{
			fwrite($fsock, $cmd);
  			$response .= fgets($fsock, 1160);
        	log::add('proteo', 'debug', __FUNCTION__ . ' response : '.$response);
		
        }
      
      	
		return $response;
       
    }
/////////////////////////////////////*********************///////////////////////////////////// 
	
    
////////////////////////////////*********************************************////////////////////////////////////////////////
    
    
    public static function writedataStat($data) {
		
      log::add('proteo', 'info', __FUNCTION__ .' started *****************');
      $path = dirname(__FILE__) . '/../../data';
      if (!is_dir($path)) {
      	com_shell::execute(system::getCmdSudo() . 'mkdir ' . dirname(__FILE__) . '/../../data' . ' > /dev/null 2>&1;');
     	com_shell::execute(system::getCmdSudo() . 'chmod 777 -R ' . dirname(__FILE__) . '/../../data' . ' > /dev/null 2>&1;');
      	log::add('proteo', 'debug', 'Dossier data crée...');
      } else {
      	com_shell::execute(system::getCmdSudo() . 'chmod 777 -R ' . dirname(__FILE__) . '/../../data' . ' > /dev/null 2>&1;');
      	log::add('proteo', 'debug', 'Le dossier data existe, droit sudo ok');
      }
		
		file_put_contents($path.'/data.json', json_encode($data));
		log::add('proteo', 'debug', 'Fin '.__FUNCTION__);	 		  
	}
	
////////////////////////////////*********************************************////////////////////////////////////////////////
    public static function syncInfos($eqLogicid = null,$Int = null) {
        if($eqLogicid != null || $this != null){
            $eqLogic = proteo::byLogicalId($eqLogicid, 'proteo');
        }
        else if($this != null){
            $eqLogic = $this;
            $eqLogicid = $eqLogic->getLogicalId();
        }
        //log::add('proteo','debug', __FUNCTION__ .'***** ');
        log::add('proteo','debug', __FUNCTION__ .' start... * eqLogicid: '.$eqLogicid.' -> '.$eqLogic->getName());
        //$eqLogic = eqLogic::byLogicalId($eqLogicid,'proteo');
        if (!is_object($eqLogic)) {
            //continue;
        }
        $arrAll=array();
        $eqLogic->refreshWidget();
    }

/////////////////////////////////////*********************///////////////////////////////////// 
    public function preInsert() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function postInsert() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function preSave() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
        
    }

    public function preUpdate() {
       // log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function postUpdate() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function preRemove() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }

    public function postRemove() {
        //log::add('proteo', 'info', __FUNCTION__ .' started on: '.$this->getName());
    }    
    public function postSave() {
		log::add('proteo', 'info', __FUNCTION__ .' started *****************'.$this->getName());
		$eqLogic = eqLogic::byLogicalId($this->getLogicalId(),'proteo');
		if ($this->getConfiguration('configType') != $this->getConfiguration('type')) {
			$this->makeCmd($this->getLogicalId());
		}
		//log::add('proteo', 'info', __FUNCTION__ .' started on: '.$eqLogic->getName());
    }
/////////////////////////////////////*********************///////////////////////////////////// 
    public function makeCmd($eqLogic=NULL) {
		$this->setConfiguration('configType', $this->getConfiguration('type'));
			$eqLogic=$this;
			$eqtype = $eqLogic->getConfiguration('type');
		
		log::add('proteo', 'info','        '. __FUNCTION__ .' started for: '.$eqLogic->getName());
		//////////////////////////////////////////////////	
		$cmd = $eqLogic->getCmd(null, 'refresh');
			if (! is_object($cmd)) {
				$cmd = new proteoCmd();
				$cmd->setLogicalId('refresh');
				$cmd->setIsVisible(1);
			}
		$cmd->setName(__('Rafraichir', __FILE__));
		$cmd->setType('action');
		$cmd->setSubType('other');
		$cmd->setEqLogic_id($eqLogic->getId());
		$cmd->setOrder(21);
		$cmd->save();
		//////*CMD BOX////////////////////////////////////////
		
      			////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'preFilter_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('preFilter_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat preFiltre', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'filterOne_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('filterOne_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat filtre 1', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'filterTwo_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('filterTwo_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat filtre 2', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'defect');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('defect');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Nombre de défaillances', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      ////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'uvc_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('uvc_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Etat uvc', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('binary');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
      			////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'uvc_state');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('uvc_state');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Uvc state', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
      			////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'nb_alerts');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('nb_alerts');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Nombre d\'alertes', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('numeric');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
      			$cmd = $eqLogic->getCmd(null, 'mode');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('mode');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Mode', __FILE__));
				$cmd->setType('info');
				$cmd->setSubType('binary');//string
				$cmd->setEqLogic_id($eqLogic->getId());
				$cmd->setOrder(1);
				$cmd->save();
				////////////////////////////////////////////////////////
				$cmd = $eqLogic->getCmd(null, 'conso-day');
				if (! is_object($cmd)) {
					$cmd = new proteoCmd();
					$cmd->setLogicalId('conso-day');
					$cmd->setIsVisible(1);
				}
				$cmd->setName(__('Conso du jour', __FILE__));
				$cmd->setType('info');
				$cmd->setSub