<?php

namespace WebSocket\Message;

class Binary extends Message
{
    protected $opcode = 'binary';
}
