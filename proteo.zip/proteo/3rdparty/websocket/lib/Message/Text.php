<?php

namespace WebSocket\Message;

class Text extends Message
{
    protected $opcode = 'text';
}
