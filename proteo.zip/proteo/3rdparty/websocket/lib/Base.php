<?php
/**
 * Copyright (C) 2014-2020 Textalk/Abicart and contributors.
 *
 * This file is part of Websocket PHP and is free software under the ISC License.
 * License text: https://raw.githubusercontent.com/Textalk/websocket-php/master/COPYING
 */

namespace WebSocket;
error_reporting(E_ALL);

//use NullLogger;
//use Psr\Log\{LoggerAwareInterface, LoggerAwareTrait, LoggerInterface, NullLogger};


use WebSocket\Exception\{BadOpcodeException,BadUriException,ConnectionException,Exception,TimeoutException};
use WebSocket\Message\{Factory, Message};
//use WebSocket\Exception\{ConnectionException,Exception,TimeoutException};
//use Closure;

class Base {
    protected $stream;
  	protected $eof = false;
    protected $options = [];
    protected $is_closing = false;
    protected $last_opcode = null;
    protected $close_status = null;
    protected $logger;
    private $read_buffer;
	private $listen = false;
	private $lastAlive = null;//timestamp last message
  	public $connection;
  	protected $msg_factory;
  
    
    protected static $opcodes = [
        'continuation' => 0,
        'text'         => 1,
        'binary'       => 2,
        'close'        => 8,
        'ping'         => 9,
        'pong'         => 10,
      	
    ];
	
    public function getLastOpcode(): ?string {
		//$this->logger->debug( __FUNCTION__." start");
        return $this->last_opcode;
    }

    public function getCloseStatus(): ?int {
		$this->logger->debug( __FUNCTION__." start");
        return $this->close_status;
    }

    /**
     * If connected to stream.
     * @return bool
     */
    public function isConnected(): bool {
      	$backtrace = debug_backtrace(false, 2)[1]['function'];
		//$this->logger->debug( __FUNCTION__." start from ".$backtrace);
      	$return = $this->stream && in_array($this->getType(), ['stream', 'persistent stream', 'async stream']);
        if (!$return) {
            $this->connection = false;
        }
      	return $return;
    }

    /**
     * Return type of connection.
     * @return string|null Type of connection or null if invalid type.
     */
    public function getType(): ?string {
		//$this->logger->debug( __FUNCTION__." start");
        return get_resource_type($this->stream);
    }

 

    public function setTimeout(int $timeout): void{
        $this->options['timeout'] = $timeout;

        if ($this->isConnected() && $this->options['persistent']) {
            stream_set_timeout($this->stream, $timeout);
        }
    }

    public function setFragmentSize(int $fragment_size): self{
        $this->options['fragment_size'] = $fragment_size;
        return $this;
    }
	public function getFragmentSize(): int {
        return $this->options['fragment_size'];
    }

	public function send(string $payload, string $opcode = 'text', bool $masked = true): void {
		$this->logger->debug("|        ".__FUNCTION__." start");
        
        if (!$this->isConnected() || $this->connection != true) {
            $this->connect();
        }

        if (!in_array($opcode, array_keys(self::$opcodes))) {
            $warning = "Bad opcode '{$opcode}'.  Try 'text' or 'binary'.";
            $this->logger->warning($warning);
            throw new BadOpcodeException($warning);
        }

        $factory = new Factory();
        $message = $factory->create($opcode, $payload);
      	$this->logger->debug("|        ".__FUNCTION__." Sent '{$opcode}' message");
        $this->pushMessage($message, $masked);
    }
   	private function autoRespond(array $frame) {
		$this->logger->debug("|          ". __FUNCTION__." start");
        list ($final, $payload, $opcode, $masked) = $frame;
        $payload_length = strlen($payload);

        switch ($opcode) {
            case 'ping':
                // If we received a ping, respond with a pong
                $this->logger->debug("|          ".__FUNCTION__." Received 'ping', sending 'pong'.");
                //$this->send($payload, 'pong', true);
            	//$factory = new Factory();
        		//$message = $factory->create('pong', $payload);
            	//$this->pushMessage($message, $masked);
            	$payload = '';//Ping acknowledged
            
            	$message = array(true, $payload, 'pong', true);//($final, $payload, $opcode, $masked)
        		$this->pushFrame($message);
                //$this->logger->debug("        |".__FUNCTION__." msg_factory: ".json_encode($message) );
            	return [true, $payload, $opcode, $masked];
            case 'close':
            	// If we received close, possibly acknowledge and close connection
                $status_bin = '';
                $status = '';
                if ($payload_length > 0) {
                    $status_bin = $payload[0] . $payload[1];
                    $status = current(unpack('n', $payload));
                    $this->close_status = $status;
                }
                // Get additional close message
                if ($payload_length >= 2) {
                    $payload = substr($payload, 2);
                }

                $this->logger->debug("|          ".__FUNCTION__." Received 'close', status: {$status}.");
                if (!$this->is_closing) {
                    $ack =  "{$status_bin} Close acknowledged: {$status}";
                    //$message = $this->msg_factory->create('close', $ack);
                  	$message = array(true, $ack, 'close', true);
        			$this->pushFrame($message);
                  	//$this->send($ack, 'close', true); 
                } else {
                    $this->is_closing = false; // A close response, all done.
                }
                $this->disconnect();
                return [$final, $payload, $opcode, $masked];
            default:
                return [$final, $payload, $opcode, $masked];
        }
    }

  	public function pushMessage(Message $message, bool $masked = true): void {
		$this->logger->debug("|          ".__FUNCTION__." start");
        $frames = $message->getFrames($masked, $this->options['fragment_size']);
        foreach ($frames as $frame) {
            $this->pushFrame($frame);
        }
      	$this->logger->debug("|          >> ".__FUNCTION__." Pushed {$message}"
					." opcode => ".$message->getOpcode()
					." content-length => ".$message->getLength()
					." frames => ".count($frames) );
    }    
	// Push frame to stream
    private function pushFrame(array $frame): void {
		$this->logger->debug("|            ".__FUNCTION__." start... ".json_encode($frame));
        list ($final, $payload, $opcode, $masked) = $frame;
        $data = '';
        $byte_1 = $final ? 0b10000000 : 0b00000000; // Final fragment marker.
        $byte_1 |= self::$opcodes[$opcode]; // Set opcode.
        $data .= pack('C', $byte_1);
		//$this->logger->debug("            |>> ".__FUNCTION__." data1 '{$data}'");
          	
        $byte_2 = $masked ? 0b10000000 : 0b00000000; // Masking bit marker.

        // 7 bits of payload length...
        $payload_length = strlen($payload);
        if ($payload_length > 65535) {
            $data .= pack('C', $byte_2 | 0b01111111);
            $data .= pack('J', $payload_length);
        } elseif ($payload_length > 125) {
            $data .= pack('C', $byte_2 | 0b01111110);
            $data .= pack('n', $payload_length);
        } else {
            $data .= pack('C', $byte_2 | $payload_length);
          	$encode_buffer = $byte_1 . chr(127) . pack("xxxxN", $payload_length) . $payload;
          	$encode_buffer = pack('C', $encode_buffer);
          //$this->logger->debug("            |>> ".__FUNCTION__." data2 '{$data}'"." encode_buffer '{$encode_buffer}'");
          	
        }

        // Handle masking
        if ($masked) {
            // generate a random mask:
            $mask = '';
            for ($i = 0; $i < 4; $i++) {
                $mask .= chr(rand(65, 122));
            }
            $data .= $mask;

            // Append payload to frame:
            for ($i = 0; $i < $payload_length; $i++) {
                $data .= $payload[$i] ^ $mask[$i % 4];
            }
          	///$this->logger->debug("            |>> ".__FUNCTION__." data31 '{$data}'");
        
        } else {
          	//$this->logger->debug("            |>> ".__FUNCTION__." data32 '{$data}'");
          	
            $data .= $payload;
        }
		//$hybi10 = $this->hybi10Encode($payload, $opcode, $masked = true);
      	$this->write($data);
      	//$this->write($data);
		//$this->logger->debug("|            >> ".__FUNCTION__." hybi10 '$hybi10'"." data '$data'");
        $this->logger->debug("|            🔔 >> ".__FUNCTION__." Pushed '{$opcode}' frame: ".$data." length: ".$payload_length." ar: ".json_encode($frame) , [
            'opcode' => $opcode,
            'final' => $final,
            'content-length' => strlen($payload),
        ]);
    }
	private function hybi10Encode($payload, $type = 'text', $masked = true){
        $frameHead = array();
        $payloadLength = strlen($payload);
        switch ($type) {
            case 'text':
                $frameHead[0] = 129;
                break;
            case 'close':
                $frameHead[0] = 136;
                break;
            case 'ping':
                $frameHead[0] = 137;
                break;
            case 'pong':
                $frameHead[0] = 138;
                break;
        }
        if ($payloadLength > 65535) {
            $payloadLengthBin = str_split(sprintf('%064b', $payloadLength), 8);
            $frameHead[1] = ($masked === true) ? 255 : 127;
            for ($i = 0; $i < 8; $i++) {
                $frameHead[$i + 2] = bindec($payloadLengthBin[$i]);
            }
            if ($frameHead[2] > 127) {
                $this->close(1004);
                return false;
            }
        } elseif ($payloadLength > 125) {
            $payloadLengthBin = str_split(sprintf('%016b', $payloadLength), 8);
            $frameHead[1] = ($masked === true) ? 254 : 126;
            $frameHead[2] = bindec($payloadLengthBin[0]);
            $frameHead[3] = bindec($payloadLengthBin[1]);
        } else {
            $frameHead[1] = ($masked === true) ? $payloadLength + 128 : $payloadLength;
        }
        foreach (array_keys($frameHead) as $i) {
            $frameHead[$i] = chr($frameHead[$i]);
        }
        if ($masked === true) {
            $mask = array();
            for ($i = 0; $i < 4; $i++) {
                $mask[$i] = chr(rand(65, 122));
            }
            $frameHead = array_merge($frameHead, $mask);
        }
        $frame = implode('', $frameHead);
        for ($i = 0; $i < $payloadLength; $i++) {
            $frame .= ($masked === true) ? $payload[$i] ^ $mask[$i % 4] : $payload[$i];
        }
        return $frame;
    }
  	protected function write(string $data, $retry=false): void {
		//$this->logger->debug( __FUNCTION__." start");
        $length = strlen($data);
        $written = @fwrite($this->stream, $data);
        if ($written === false) {
            $this->throwException("Failed to write {$length} bytes.");
        }
        if ($written < strlen($data)) {
          	if (!$retry) {
              	$this->logger->info("|              	".__FUNCTION__." retry write ".$retry);
          		$this->write($data, true);
              	return;
            }else{
            	$throwMsg = " Could only write {$written} out of {$length} bytes.";
                //$this->throwException($throwMsg);
          		$this->logger->error("|             ".__FUNCTION__.$throwMsg);
              	//$this->sendEvent("ERROR", "", $throwMsg);
              	$this->Event($throwMsg, "error");
            }
        }
        $this->logger->debug("|             >> ".__FUNCTION__." Wrote {$written} of {$length} bytes.");
    }

    public function receive(){
        $filter = $this->options['filter'];
        $return_obj = $this->options['return_obj'];

        if (!$this->isConnected() || $this->connection != true) {
            $this->connect();
        }

        while (true) {
            $message = $this->pullMessage();
          	list ($final, $payload, $opcode, $masked) = $message;
            if (in_array($opcode, $filter)) {
                $this->last_opcode = $opcode;
                $return = $return_obj ? $message : $payload;
                break;
            } elseif ($opcode == 'close') {
                $this->last_opcode = null;
                $return = $return_obj ? $message : 'close';
                break;
            }
        }
        $this->Event( ["", $return, $opcode, ""] );	//($final, $data, $opcode, $masked)
       	$this->logger->info( __FUNCTION__." return : ".$return);
      	return $return;
    }
  	
    /**
     * Receive one message.
     * Will continue reading until read message match filter settings.
     * Return Message instance or string according to settings.
     */
 	//public function listen(Closure $callback) {
    public function listen() {
        //throw new TimeoutException("test");
      	//$this->throwException("test");
      	$this->logger->debug("┌───────── ". __FUNCTION__." start...");
        
      	/*if(!is_callable($callback, true)){
          	$this->logger->warning("│ ".__FUNCTION__." callback is not valid");
          
        }*/
		$this->listen = true;
        while ($this->listen) {
            // Connect
            if (!$this->isConnected() || $this->connection != true) {
                $this->connect();
            }

            // Handle incoming
            $read = array($this->stream);
            $write = [];
            $except = [];
            if (stream_select($read, $write, $except, $this->options['timeout'])) {
                foreach ($read as $stream) {
                    try {
                        $result = null;
                        $peer = stream_socket_get_name($stream, true);
                        if (empty($peer)) {
                            $this->logger->warning("│ ".__FUNCTION__." Got detached stream '{$peer}'");
                            $infos = $this->getInfos();
                          	$errstr = " Connection lost : Got detached stream '{$peer}'";
                            $arMsg=json_encode(["status" => "detached stream","msg" => $errstr]);
                            $this->Event($arMsg, "notice");
                          	$this->connection = false;
                            if ($this->options['async'] || $this->options['persistent']) {
                                $connect = $this->connect();
                            }
                          	if ($this->connection != true) {
                                $this->throwException(__FUNCTION__.$errstr);
                          		return " Got detached stream";
                            }
                          	
                          	//break;
                          	continue;
                        }
                       // $this->logger->debug("│ ".__FUNCTION__." Listening {$peer}");
                        $message = $this->pullMessage();
                        if ($this->connection != true) {
                          	$this->logger->warning("│ ".__FUNCTION__." No connection");
                            break;
                        }
                        // Trigger callback according to filter
                      	list ($final, $payload, $opcode, $masked) = $message;
                        //$opcode = $message->getOpcode();
                        if (in_array($opcode, $this->options['filter'])) {
                            $this->last_opcode = $opcode;
                            $result = $message;
                          	//$result = $callback($message, $this->connection);
                          	$result = $this->Event($message);
                        }
                        // If callback returns not null, exit loop and return that value
                        if (!is_null($result)) {
                          	$this->logger->debug("└──────────────────────────────────── ");
                            return $result;
                        }
                      	$this->logger->warning("│ ".__FUNCTION__." No result");
                    } catch (Throwable $e) {
                        $this->logger->error(__FUNCTION__." Error occured on {$peer}; {$e->getMessage()}");
                    }
                }
            }
        }
      	$this->logger->debug(">──────────────────────────────────── ". __FUNCTION__." end");
      	$this->Event( __FUNCTION__."() exited...", "ERROR");
    }
	// Pull a message from stream
    private function pullMessage() {
		$this->logger->debug("|  ".__FUNCTION__." start");
        do {
            $frame = $this->pullFrame();
            list ($final, $payload, $opcode, $masked) = $frame;
            //$opcode = $frame[2];
            if ($opcode == 'close') {
              	$frame = $this->autoRespond($frame);
              	$this->logger->debug("|  ".__FUNCTION__." in_while Received 'close', status: {$this->close_status}.");
				//$this->sendEvent("ERROR", "",__FUNCTION__." Received 'close', status: {$this->close_status}.");
            	 $this->Event( " Received 'close'", "ERROR");
                $this->close();
            }
			if ($opcode == 'ping') {
              	$frame = $this->autoRespond($frame);
            }
          	//list ($final, $payload, $opcode, $masked) = $frame;
			
          
            // Continuation and factual opcode
            $continuation = $opcode == 'continuation';
            $payload_opcode = $continuation ? $this->read_buffer['opcode'] : $opcode;

            // First continuation frame, create buffer
            if (!$final && !$continuation) {
                $this->read_buffer = ['opcode' => $opcode, 'payload' => $payload, 'frames' => 1];
                continue; // Continue reading
            }

            // Subsequent continuation frames, add to buffer
            if ($continuation) {
                $this->read_buffer['payload'] .= $payload;
                $this->read_buffer['frames']++;
            }
        } while (!$final);
		// Final, return payload
        $frames = 1;
        if ($continuation) {
            $payload = $this->read_buffer['payload'];
            $frames = $this->read_buffer['frames'];
            $this->read_buffer = null;
        }
		//$this->msg_factory = new Factory();
        //$message = $this->msg_factory->create($payload_opcode, $payload);

        $this->logger->debug("|  >> ▶️ ". __FUNCTION__." Pulled {$opcode}:  {$payload}");
		$message = $this->msg_factory->create($payload_opcode, $payload);

       
      	/*$this->logger->debug( "	".__FUNCTION__." Factory_Pulled {$message}"
					." opcode => ".$message->getOpcode()//$payload_opcode
					." content-length => ".$message->getLength()//strlen($payload
					." frames => ".$frames );*/
      
      //$this->logger->info(" Pulled msg: {$message}");
       // return $message;
      	return [$final, $payload, $payload_opcode, $masked];
    }
	
  // Pull frame from stream
    private function pullFrame(): array {
        $this->logger->debug("|     ". __FUNCTION__." start");
        // Read the fragment "header" first, two bytes.
        $data = $this->read(2);
        /*if(!$data || $data == ""){//!is_array($data) || 
			$timeout = $this->options['timeout'];
			$this->logger->debug(__CLASS__."::".__FUNCTION__." invalid data: ".$data
                               ." timeout: {$timeout}"." lastAlive: {$this->lastAlive}"  );
          	$this->throwException("invalid data Empty read; connection dead ? ");
          	//exit();
        }*/
      	list ($byte_1, $byte_2) = array_values(unpack('C*', $data));
        $final = (bool)($byte_1 & 0b10000000); // Final fragment marker.
        $rsv = $byte_1 & 0b01110000; // Unused bits, ignore

        // Parse opcode
        $opcode_int = $byte_1 & 0b00001111;
        $opcode_ints = array_flip(self::$opcodes);
        if (!array_key_exists($opcode_int, $opcode_ints)) {
            $warning = "Bad opcode in websocket frame: {$opcode_int}";
            $this->logger->warning("|     ". __FUNCTION__." ".$warning);
        	throw new ConnectionException($warning, ConnectionException::BAD_OPCODE);
        }
        $opcode = $opcode_ints[$opcode_int];
		if ($opcode && $opcode != "close") {
            $this->lastAlive = time();
        }
        // Masking bit
        $masked = (bool)($byte_2 & 0b10000000);

        $payload = '';

        // Payload length
        $payload_length = $byte_2 & 0b01111111;
		//$this->logger->debug("|     ".__FUNCTION__." masked: {'$masked'}"." opcode: {'$opcode'}"." payload_length: {'$payload_length'}"." data: ".json_encode($data));
        if ($payload_length > 125) {
            if ($payload_length === 126) {
                $data = $this->read(2); // 126: Payload is a 16-bit unsigned int
                $payload_length = current(unpack('n', $data));
            } else {
                $data = $this->read(8); // 127: Payload is a 64-bit unsigned int
                $payload_length = current(unpack('J', $data));
            }
        }

        // Get masking key.
        if ($masked) {
            $masking_key = $this->read(4);
          	$this->logger->debug("|     ".__FUNCTION__." masked '{$opcode}' masking_key ". json_encode($masking_key));
        }

        // Get the actual payload, if any (might not be for e.g. close frames.
        if ($payload_length > 0) {
            $data = $this->read($payload_length);

            if ($masked) {
                // Unmask payload.
                for ($i = 0; $i < $payload_length; $i++) {
                    $payload .= ($data[$i] ^ $masking_key[$i % 4]);
                }
            } else {
                $payload = $data;
            }
        }

        $this->logger->debug("|     >> ".__FUNCTION__." Pulled '{$opcode}' frame");
      	return [$final, $payload, $opcode, $masked];
    }

  
  	public function read(string $length): string {
      	$this->logger->debug("|       ".__FUNCTION__." start length: {$length}");
        $rev_opcodes = [
				0 => 'continuation',
				1 => 'text',
				2 => 'binary',
				3 => '_ttfn',
				8 => 'close',
				9 => 'ping',
				10 => 'pong',
				11 => '_json',
        ];
      	$data = '';
        while (strlen($data) < $length) {
            $buffer = fread($this->stream, $length - strlen($data));
          	//$this->logger->debug("|       ".__FUNCTION__." Reading length: {$length}...");
            if ($buffer === false) {
                $read = strlen($data);
                $this->throwException("Broken frame, read {$read} of stated {$length} bytes.");
            }
            if ($this->listen && $buffer === '') {
              	//$contents = stream_get_contents($this->stream);
				$metaData = stream_get_meta_data($this->stream);//$this->getMeta();// 
              	$timeout = $this->options['timeout'];
              	$this->lastAlive ? $this->lastAlive : $this->lastAlive = time();
              	$diffAlive = time() - $this->lastAlive;
                $errstr = null;
                $timeout = $this->options['timeout'];
              	$errstr = null;
              	/*if (!is_resource($this->stream) || (($metaData = @stream_get_meta_data($this->stream)) && $metaData['eof'])) {
                	return new Failure(new ClosedException("The stream was closed by the peer"));
            	}*/
              
              	if (!$this->options['async'] && !$this->options['persistent']) {
					$this->logger->debug("|       ".__FUNCTION__." Empty read (in no persistent mode).");
					$this->throwException("Empty read; connection dead?");
				}
				if ($metaData && $metaData['timed_out']) {
					$errstr = " Reading => timed_out: ".$metaData['timed_out'];
				}
				if ($metaData && $metaData['eof']) {//feof($this->socket)
					$errstr .= " Reading => eof: ".$metaData['eof'];//'Connection reset by peer'
                  	$this->onEof();
                  	//$this->logger->error("|       ".__FUNCTION__." Connection lost ".$errstr);
                  	//$this->throwException($errstr ." since: {$diffAlive} secondes");
				}
              	if (!$errstr) {//feof($this->socket)
					$this->logger->debug("|       ".__FUNCTION__." Empty read...");
				  	//$this->sendEvent("info", "", "Empty read...unknown");
				}else{
                  	//$this->logger->error("|       ".__FUNCTION__." Connection lost ".$errstr);
                  	//$this->sendEvent("warning", "", $errstr);
                  	if($diffAlive > max($timeout * 10, 60) ){
                  		if (!$errstr) {//feof($this->stream)
                        	$errstr = " Empty read; connection lost ?";//'Connection reset by peer'
                    		$this->logger->error(" ".__FUNCTION__." ".$errstr." eof: ".$metaData['eof']);
                    	} 
                  	
                  		$this->logger->debug("|       ". __FUNCTION__
                                   ." isConnected(): ".(bool)$this->isConnected()
                                   ." is_closing: ".(bool)$this->is_closing
                                   ." socket: {$this->stream} "
                                   ." close_status: ".(bool)$this->close_status
                                   ." meta_timed_out: ".(bool)$metaData['timed_out']
                                   ." meta_eof: ".(int)$metaData['eof']
                                   //." meta feof: ".feof($this->stream)
                                   ." meta_blocked: ".(int)$metaData['blocked']
                                   ." meta_unread_bytes:  {$metaData['unread_bytes']} "
                                   //." metadata:". json_encode($metaData)." buffer: {$buffer} "
                                    );
						//$this->sendEvent("error", "", __FUNCTION__." ".$errstr ." since: {$diffAlive} secondes");
                      	$this->Event( __FUNCTION__." ".$errstr ." since: {$diffAlive} secondes", "ERROR");
						
						
                      	$this->throwException($errstr ." since: {$diffAlive} secondes");
                	}
                }
				sleep(1);//continue;
				//break;
				//return "";
			}// End $buffer === ''
            $data .= $buffer;
            $read = strlen($data);
            if ($read != 0) {
              	$this->logger->debug("|       ".__FUNCTION__." Read {$read} of {$length} bytes. ");
            }
        }//End while
      	
      	$firstbyte    = ord($data[0]);
      	$secondbyte   = ord($data[1]);
      	$data_len     = $secondbyte & 127;
      	$is_fin_frame = $firstbyte >> 7;
      	$masked       = $secondbyte >> 7;
      
      	
      	$opcode = $firstbyte & 0x0F;
      	$rsv = ($firstbyte & 0x070) >> 4;
      	$isControlFrame = (int)($opcode >= 0x08);
    	$final = $firstbyte & 0x80;
    	$masked = $secondbyte & 0x80;
      	$masked2 = $secondbyte  >> 7;
    	$payload_len = $secondbyte & 0x7F;
      	$data_msg = ($opcode == 11) ? " data: {$data}" : "";
      
      	$this->logger->debug("|       >> ".__FUNCTION__." return opcode: {'$opcode'}( '$rev_opcodes[$opcode]' )"
                           ." final: '$final'"." masked: '$masked'"." len {'$payload_len'}"
                           ." isControlFrame: {'$isControlFrame'}"." rsv: {'$rsv'} " 
                           .$data_msg
                          );
      	if ($masked) {
              $this->logger->warning("|       ".__FUNCTION__." frame not masked so close the connection. ");
        }
      	if($opcode && $opcode!= "close") {
              $this->eof = false;
          	  $this->connection = true;	
        }
        //$parser = $this->parser($data);
      	//$this->logger->debug( __FUNCTION__." parser: ".json_encode($parser));
        return $data;
    }
	
	private function onEof(): void {
		//$this->logger->debug("        |".__FUNCTION__." start");
		if(!$this->eof){
			$this->connection = "eof";
            $this->eof = time();
			$errstr = " Connection lost : Reading => eof at : '$this->eof'";
          	$arMsg=json_encode(["status"=>"eof","msg"=>$errstr]);
          	$this->Event($arMsg, "notice");
			//$this->Event(__FUNCTION__ .$errstr, "warning");
			//$infos = $this->getInfos();
          	$this->logger->debug("|       ". __FUNCTION__ .$errstr." try reconnect");
          	if ($this->options['async'] || $this->options['persistent']) {
				$this->connect();
            }
            // $isAlive = $this->isAlive();
      		//$this->logger->debug("| ".  __FUNCTION__." isAlive: {$isAlive} ");
      	
			//$this->logger->debug("|       ". __FUNCTION__ ." infos: ".json_encode($infos));
		}
	}
	
  	public function isAlive()  {
		$this->logger->debug( "| ".__FUNCTION__." start");
      	$this->logger->debug( "| ".__FUNCTION__." Sending 'ping'.");
            
		$this->send("", "ping");
		//$return = "Nok";
      // Receive pong
      //$message[2]="";
        $return = false;
      	$i = 1;
      	$now= time();
      	do {
			$message = $this->pullMessage();
            if ($message[2] == 'pong') {
                $this->connection = true;
              	$this->logger->info("| ". __FUNCTION__." Received 'pong'.");
              	$this->lastAlive = time();
                $return = "ok";//
              	break;
              	//return $return;
            }
          	$i++;
          	//$this->logger->info( "| ".__FUNCTION__." if exited ".$i);
          	if (time() >= ($now + $this->options['timeout'])) {
              	$this->logger->info( "| ".__FUNCTION__." timeout");
              	break;
            }
          	if ($i >= 15) {
              	break;
            }
          	
		}while (!$return);
        //$this->logger->info( __FUNCTION__." while exited ");
        
        
      	if ($return != "ok") {
          	$return = "Nok";
            $this->connection = false;
            $this->stream = null;
          	$this->logger->error("| ".__FUNCTION__." Did not receive pong from remote.");
           // throw new ConnectionException("Did not receive pong from remote ");
        }
      	$this->logger->info("| ".__FUNCTION__." return ".$return);
      	//$return = true;
      	return $return;
    }
	
  	protected function sendEvent($type=null, $opcode=null, $data=null) : void{
		//$backtrace = debug_backtrace(false, 2)[1]['function'];
		//$this->logger->debug( __FUNCTION__." start from ".$backtrace);
      	$event_handler = $this->options['event_handler'];
        //$callable = is_callable($event_handler, true);
      	if($event_handler){
          	call_user_func($event_handler, $type, $opcode, $data); 
          //$this->logger->info( __FUNCTION__." ok end");
        }
    }
		
	
    /**
     * Convenience method to send text message
     * @param string $payload Content as string
     */
    public function text(string $payload): void {
		$this->logger->debug( __FUNCTION__." start");
        $this->send($payload);
    }

    /**
     * Convenience method to send binary message
     * @param string $payload Content as binary string
     */
    public function binary(string $payload): void {
		$this->logger->debug( __FUNCTION__." start");
        $this->send($payload, 'binary');
    }

    /**
     * Convenience method to send ping
     * @param string $payload Optional text as string
     */
    public function ping(string $payload = ''): void {
		$this->logger->debug( __FUNCTION__." start");
        $this->send($payload, 'ping');
    }

    /**
     * Convenience method to send unsolicited pong
     * @param string $payload Optional text as string
     */
    public function pong(string $payload = ''): void {
		$this->logger->debug( __FUNCTION__." start");
      		$this->send($payload, 'pong');
    }

    
    /**
     * Get name of remote socket, or null if not connected
     * @return string|null
     */
    public function getPeer(): ?string {
        $this->logger->debug("| ".__FUNCTION__." start");
      	return $this->isConnected() ? stream_socket_get_name($this->stream, true) : null;
    }
	public function getName(): ?string {
		$this->logger->debug("| ".__FUNCTION__." start");
      	$name = $this->isConnected() ? stream_socket_get_name($this->stream, false) : null;
      	$this->logger->debug("| ".__FUNCTION__." name: '$name'");
      	return $name;
    }
    public function getMeta(): array{
        $this->logger->debug("| ". __FUNCTION__." start");
      	return $this->isConnected() ? stream_get_meta_data($this->stream) : null;
    }
  	public function tell(): int {
        $this->logger->debug("| ". __FUNCTION__." start");
      	$tell = ftell($this->stream);
        if ($tell === false) {
          	$msg = 'Could not resolve stream pointer position';
          	$this->Event("| ".  __FUNCTION__." ".$msg, "WARNING");
			$this->logger->error(__FUNCTION__." ".$msg);
            $this->throwException($msg);
        }
        return $tell;
    }
  /**
     * Read line from stream.
     * @param int $length Maximum number of bytes to read
     * @param string $ending Line delimiter
     * @return string Read data
     */
    public function getLine(int $length, string $ending): string{
        $backtrace = debug_backtrace(false, 2)[1]['function'];
		$this->logger->debug( __FUNCTION__."() start... from: {$backtrace}");
      	$line = stream_get_line($this->stream, $length, $ending);
        if ($line === false) {
            $this->throwException('Could not read from stream');
        }
        $read = strlen($line);
        $this->logger->debug("Read {$read} bytes of line.");
        return $line;
    }
  /**
     * Get string representation of instance
     * @return string String representation
     */
    public function __toString(): string {
		$this->logger->debug( __FUNCTION__." start");
        return sprintf(
            "%s(%s)",
            get_class($this),
            $this->getName() ?: 'closed'
        );
    }
  	
    /**
     * Tell the socket to close.
     *
     * @param integer $status  http://tools.ietf.org/html/rfc6455#section-7.4
     * @param string  $message A closing message, max 125 bytes.
     */
    
	public function close(int $status = 1000, string $message = 'ttfn'): void {
		$backtrace = debug_backtrace(false, 2)[1]['function'];
		$this->logger->debug( __FUNCTION__."() start... from: {$backtrace}");
      	//$this->sendEvent("WARNING", "", __FUNCTION__."() start... from: {$backtrace}");
      	$this->Event( __FUNCTION__."() start... from: {$backtrace}", "WARNING");
						
        if (!$this->isConnected()) {
            return;
        }
        $status_binstr = sprintf('%016b', $status);
        $status_str = '';
        foreach (str_split($status_binstr, 8) as $binstr) {
            $status_str .= chr(bindec($binstr));
        }
        //$message = $this->msg_factory->create('close', $status_str . $message);
        //$this->pushMessage($message, true);
		$this->send($status_str . $message, 'close', true);
        $this->logger->debug( __FUNCTION__." Closing with status: {$status}.");
		//unset($this->stream);
        //stream_socket_shutdown($this->stream, STREAM_SHUT_RDWR);
        
        $this->is_closing = true;
        while (true) {
            $message = $this->pullMessage();
            if ($message[2] == 'close') {
                $this->connection = 'close';
              	$this->stream = null;
              	break;
            }
        }
    }
   
	protected function throwException(string $message, int $code = 0): void {
		$backtrace = debug_backtrace(false, 2)[1]['function'];
		$this->logger->debug( __FUNCTION__."() start... from: {$backtrace}");
      	$meta = ['closed' => true];
        /*if ($this->isConnected()) {
            $meta = $this->getMeta();stream_get_meta_data($this->stream);
            fclose($this->stream);
            $this->stream = null;
        }*/
      	$this->disconnect();
        $json_meta = json_encode($meta);
        if (!empty($meta['timed_out'])) {
            //$this->sendEvent("ERROR", "", $message." meta: ".$json_meta." code: ".$code);
            $this->Event( $message." meta: ".$json_meta." code: ".$code, "WARNING");
		
          	$this->logger->error($message, $meta);
          	throw new TimeoutException($message, ConnectionException::TIMED_OUT, $meta);
        }
        if (!empty($meta['eof'])) {
            $code = ConnectionException::EOF;
        }
       // $this->sendEvent("ERROR", "", $message." meta: ".$json_meta." code: ".$code);
      	$this->Event( __FUNCTION__." ".$message." meta: ".$json_meta." code: ".$code, "WARNING");
		$this->logger->error(__FUNCTION__." ".$message, $meta);
      	
            
        throw new ConnectionException($message, $code, $meta);
    }
  
  	// Trigger auto response for frame
    
    

    
	
  	
  /* **************************************************** */
  // Push a message to stream
    
    
  	/* ---------- getInfos methods -------------------------------------------------- */
  	public function getInfos() {
      	$this->logger->debug("| ". __FUNCTION__."() start...");
		$arInfos = [
                "stream" => (string)$this->stream,
                "eof" => $this->eof ? date("H:i:s", $this->eof) : 0,
                "is_closing" => (int)$this->is_closing,
                "last_opcode" => $this->last_opcode,
                "close_status" => (int)$this->close_status,
                "read_buffer" => $this->read_buffer,
                "listen" => (int)$this->listen,
                "lastAlive" => $this->lastAlive ? date("H:i:s", $this->lastAlive) : 0,
                "connection" => (int)$this->connection,
                "soketName" => $this->getName(),
                "soketPeer" => $this->getPeer(),
                "soketType" => $this->getType(),
          		"Meta" => $this->getMeta(),
          		"Tell" => $this->tell(), 
        ];
		/*$arInfos["stream"] = (string)$this->stream;
      $arInfos["connection"] = (int)$this->connection;
      $arInfos["eof"] = $this->eof;
      $arInfos["is_closing"] = (int)$this->is_closing;
      $arInfos["last_opcode"] = $this->last_opcode;
      $arInfos["close_status"] = (int)$this->close_status;
      $arInfos["read_buffer"] = $this->read_buffer;
      $arInfos["listen"] = (int)$this->listen;
      $arInfos["lastAlive"] = ($this->lastAlive) ? date("H:i:s", $this->lastAlive) : 0);
      */
      
      $this->Event( __FUNCTION__." arInfos: ".json_encode($arInfos), "info");
      $this->logger->debug("| >> 🌸 ".__FUNCTION__." arInfos: " .json_encode($arInfos));//, json_encode($arInfos)JSON_PRETTY_PRINT
      
      
      
      //$metaData = stream_get_meta_data($this->stream);
        //$this->logger->debug(__FUNCTION__." metadata: {$metaData}");
      
      	return $arInfos;
    }
    /* ---------- Frame I/O methods -------------------------------------------------- */

    
    
    
	public function factory_create(string $opcode, string $payload = ''): Message {
		$this->logger->debug( __FUNCTION__." start");
        switch ($opcode) {
            case 'text':
                return new Text($payload);
            case 'binary':
                return new Binary($payload);
            case 'ping':
                return new Ping($payload);
            case 'pong':
                return new Pong($payload);
            case 'close':
                return new Close($payload);
        }
        throw new BadOpcodeException("Invalid opcode '{$opcode}' provided");
    }
    
  
      /**
     * Close connection stream.
     * @return bool
     */
   
  
  
  
  
  /* public function loop() {
        $client = $this->client;
        while (count($this->results) > 0) {
            $pool = $this->createPool($client, $this);
            if ($pool === false) continue;
            $o = new stdClass();
            $o->current = 0;
            $o->count = count($this->results);
            $o->responses = array();
            $o->requests = array();
            $o->readpool = array();
            $o->writepool = $pool;
            $o->buffers = $this->buffers;
            $o->deadlines = $this->deadlines;
            $o->results = $this->results;
            $this->buffers = array();
            $this->deadlines = array();
            $this->results = array();
            while (count($o->results) > 0) {
                $read = array_values($o->readpool);
                $write = array_values($o->writepool);
                $except = null;
                $timeout = max(0, min($o->deadlines) - microtime(true));
                $tv_sec = floor($timeout);
                $tv_usec = ($timeout - $tv_sec) * 1000;
                $n = stream_select($read, $write, $except, $tv_sec, $tv_usec);
                if ($n === false) {
                    $e = $this->getLastError('unkown io error.');
                    foreach ($o->results as $result) {
                        $result->reject($e);
                    }
                    $o->results = array();
                }
                if ($n > 0) {
                    foreach ($write as $stream) $this->asyncWrite($stream, $o);
                    foreach ($read as $stream) $this->asyncRead($stream, $o);
                }
                $this->checkTimeout($o);
                if (count($o->results) > 0 &&
                    count($o->readpool) + count($o->writepool) === 0) {
                    $o->writepool = $this->createPool($client, $o);
                }
            }
            foreach ($o->writepool as $stream) $this->fclose($stream);
            foreach ($o->readpool as $stream) $this->fclose($stream);
        }
    }
    public function asyncSendAndReceive($buffer, stdClass $context) {
        $deadline = ($context->timeout / 1000) + microtime(true);
        $result = new Future();
        $this->buffers[] = $buffer;
        $this->deadlines[] = $deadline;
        $this->results[] = $result;
        return $result;
    }*/
  
  
}