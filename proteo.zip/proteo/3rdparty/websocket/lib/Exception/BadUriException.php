<?php

//namespace WebSocket;
namespace WebSocket\Exception;
class BadUriException extends Exception
{
}