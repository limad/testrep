<?php

//namespace WebSocket;
namespace WebSocket\Exception;
class BadOpcodeException extends Exception
{
  	public function __construct(string $message, int $opcode = 0, array $data = [], Throwable $prev = null){
        parent::__construct("BadOpcodeException::".$message, $opcode, $prev);
    }
}