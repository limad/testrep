<?php

//namespace WebSocket;
namespace WebSocket\Exception;
class Exception extends \Exception {
    
}