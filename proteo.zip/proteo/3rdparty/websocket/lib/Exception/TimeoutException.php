<?php

//namespace WebSocket;
namespace WebSocket\Exception;
class TimeoutException extends ConnectionException
{
    public function __construct(string $message, int $code = 1024, Throwable $prev = null){
        parent::__construct("TimeoutException::".$message, 1024, [], $prev);
    }
}