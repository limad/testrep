<?php
/**
 * Copyright (C) 2014-2020 Textalk/Abicart and contributors.
 *
 * This file is part of Websocket PHP and is free software under the ISC License.
 * License text: https://raw.githubusercontent.com/Textalk/websocket-php/master/COPYING
 */

namespace WebSocket;
error_reporting(E_ALL);

//use NullLogger;
//use Psr\Log\{LoggerAwareInterface, LoggerAwareTrait, LoggerInterface, NullLogger};


use WebSocket\Exception\{BadOpcodeException,BadUriException,ConnectionException,Exception,TimeoutException};
use WebSocket\Message\{Factory, Message};
//use WebSocket\Exception\{ConnectionException,Exception,TimeoutException};
//use Closure;

class Connector {
   protected $sync;
   public function send_Old(string $payload, string $opcode = 'text', bool $masked = true): void {
		$this->logger->log('DEBUG', __FUNCTION__." start");
        if (!$this->isConnected()) {
            $this->connect();
        }

        if (!in_array($opcode, array_keys(self::$opcodes))) {
            $warning = "Bad opcode '{$opcode}'.  Try 'text' or 'binary'.";
            $this->logger->warning($warning);
            throw new BadOpcodeException($warning);
        }

        $payload_chunks = str_split($payload, $this->options['fragment_size']);
        $frame_opcode = $opcode;

        for ($index = 0; $index < count($payload_chunks); ++$index) {
            $chunk = $payload_chunks[$index];
            $final = $index == count($payload_chunks) - 1;

            $this->sendFragment($final, $chunk, $frame_opcode, $masked);

            // all fragments after the first will be marked a continuation
            $frame_opcode = 'continuation';
        }

        $this->logger->log('DEBUG', __FUNCTION__." Sent '{$opcode}' message", [
            'opcode' => $opcode,
            'content-length' => strlen($payload),
            'frames' => count($payload_chunks),
        ]);
      
    }
	/**
     * Convenience method to send text message and read response
     * @param string $payload Content as string
     */


	public function sendread($payload, $opcode = 'text', $masked = true) {
		$this->logger->log('DEBUG', __FUNCTION__." start");
        if (!$this->isConnected()) {
            $this->connect();
        }

        if (!in_array($opcode, array_keys(self::$opcodes))) {
            $warning = "Bad opcode '{$opcode}'.  Try 'text' or 'binary'.";
            $this->logger->log('WARNING', __FUNCTION__." ".$warning);
            throw new BadOpcodeException($warning);
        }

        $payload_chunks = str_split($payload, $this->options['fragment_size']);
        $frame_opcode = $opcode;

        for ($index = 0; $index < count($payload_chunks); ++$index) {
            $chunk = $payload_chunks[$index];
            $final = $index == count($payload_chunks) - 1;

            $this->sendFragment($final, $chunk, $frame_opcode, $masked);

            // all fragments after the first will be marked a continuation
            $frame_opcode = 'continuation';
        }
		sleep(1);
      	$auth_rsp = '';
        $response = $this->receiveFragment();
      	list ($final, $payload, $rsp_opcode, $masked) = $response;
        $auth_rsp .= $payload;
        if($auth_rsp){
          		$this->logger->log('INFO', __FUNCTION__." Sent '{$opcode}' message. rsp: ".$auth_rsp);
              	//OnEvent("message",  "text", $auth_rsp);
          		$this->sendEvent("info", "text", $auth_rsp);
            }else{
          		$auth_rsp='{"state":"No response ' .$auth_rsp.'"}';//'{"state":"No auth_rsp: ".$auth_rsp}';
              	$this->logger->log('INFO', __FUNCTION__." Sent '{$opcode}' ".$auth_rsp);
        	}
      
      
      	return $auth_rsp;
    }
	
	public function syncRreceive(){
       /*	if (!$this->isConnected()) {
            $state=false;
          	$this->logger->log('INFO', __FUNCTION__ ." isConnected false");
           	//$this->connect();
        }*/
		$this->sync = true;
        $payload = '';
		do {
			$response = $this->receiveFragment();
			//list ($payload, $final, $opcode) = $response;
          	list ($final, $payload, $opcode, $masked) = $response;
          	$this->logger->log('INFO', __FUNCTION__." in_While ".json_encode($response) );
			//$payload .= $response[0];
		} while (!$response);//!$response[1]
		//$logAdd=($response[1]) ?  $response[1] : 'Empty';
		//$this->logger->log('INFO', __FUNCTION__." log_permRreceive_1 '{$this->last_opcode}' message : ".$logAdd." ".json_encode($response));
		if($payload != ''){//non Empty
			//$this->sendEvent("message", $payload);
          	$this->sendEvent("info", $opcode, $payload);
			$this->logger->log('INFO', __FUNCTION__." Received '$opcode' message : " .$payload );
        }elseif(!$response){
			$this->logger->log('DEBUG', __FUNCTION__." No message --final: ".$final." --opcode: ".$opcode);
			//$this->sendEvent("info", "No response");
          	$this->sendEvent("info", $opcode, $payload);
		}
		if (!$payload  && !$this->isConnected()) {
			$state=false;
			$this->logger->log('INFO', __FUNCTION__." Not connected --final: ".$final." --opcode: ".$opcode);
			$this->sendEvent("status", "", '{"state":"Not connected"}');
            	
		}
        	
      	if($opcode != 'text' && $opcode != 'ping'  && $opcode != 'pong'){
			$this->logger->log('INFO', __FUNCTION__." No text --final: ".$final." --opcode: ".$opcode);
			$continuation = ($opcode == 'continuation');
			$payload_opcode = $continuation ? $this->read_buffer['opcode'] : $opcode;
			$this->read_buffer = ['opcode' => $opcode, 'payload' => $payload, 'frames' => 1];
			$this->sendEvent("info", $opcode, $payload);
		}
      	return $payload;
       
	}
  	protected function receiveFragment(): array {
		//$this->logger->log('DEBUG', __FUNCTION__." start");
        // Read the fragment "header" first, two bytes.
        $data = $this->read(2);
        list ($byte_1, $byte_2) = array_values(unpack('C*', $data));

        $final = (bool)($byte_1 & 0b10000000); // Final fragment marker.
        $rsv = $byte_1 & 0b01110000; // Unused bits, ignore

        // Parse opcode
        $opcode_int = $byte_1 & 0b00001111;
        $opcode_ints = array_flip(self::$opcodes);
        if (!array_key_exists($opcode_int, $opcode_ints)) {
            $warning = "Bad opcode in websocket frame: {$opcode_int}";
            $this->logger->warning($warning);
            throw new ConnectionException($warning, ConnectionException::BAD_OPCODE);
        }
        $opcode = $opcode_ints[$opcode_int];
		$this->logger->log('DEBUG', __FUNCTION__." ".$data."=>".$opcode);
        // Masking bit
        $payload = '';

        // Payload length
        $payload_length = $byte_2 & 0b01111111;

        if ($payload_length > 125) {
            if ($payload_length === 126) {
                $data = $this->read(2); // 126: Payload is a 16-bit unsigned int
                $payload_length = current(unpack('n', $data));
            } else {
                $data = $this->read(8); // 127: Payload is a 64-bit unsigned int
                $payload_length = current(unpack('J', $data));
            }
        }
		
      	$masked = (bool)($byte_2 & 0b10000000);
       // Get masking key.
        if ($masked) {
            $masking_key = $this->read(4);
          	$this->logger->log('DEBUG', __FUNCTION__." masked '{$opcode}' masking_key ". json_encode($masking_key));
        }

        // Get the actual payload, if any (might not be for e.g. close frames.
        if ($payload_length > 0) {
            $data = $this->read($payload_length);
			 if ($masked) {
                // Unmask payload.
                for ($i = 0; $i < $payload_length; $i++) {
                    $payload .= ($data[$i] ^ $masking_key[$i % 4]);
                }
            } else {
                $payload = $data;
            }
        }
		$arRsp=[
            'opcode' => $opcode,
            'final' => $final,
            'content-length' => strlen($payload),
        ];
        $this->logger->log('DEBUG', __FUNCTION__." Read '{$opcode}' frame ". json_encode($arRsp), $arRsp);

        // if we received a ping, send a pong and wait for the next message
        if ($opcode === 'ping') {
            $this->logger->log('DEBUG', __FUNCTION__." Received 'ping', sending 'pong'.");
            $this->send($payload, 'pong', true);
            return [$payload, true, $opcode];
        }

        // if we received a pong, wait for the next message
        if ($opcode === 'pong') {
            $this->logger->log('DEBUG', __FUNCTION__." Received 'pong'.");
            return [$payload, true, $opcode];
        }

        if ($opcode === 'close') {
            // Get the close status.
            $status_bin = '';
            $status = '';
            if ($payload_length > 0) {
                $status_bin = $payload[0] . $payload[1];
                $status = current(unpack('n', $payload));
                $this->close_status = $status;
            }
            // Get additional close message
            if ($payload_length >= 2) {
                $payload = substr($payload, 2);
            }

            $this->logger->log('INFO', __FUNCTION__." Received 'close', status: {$this->close_status}.");
			$this->sendEvent("ERROR", "",__FUNCTION__." Received 'close', status: {$this->close_status}.");
            if ($this->is_closing) {
                $this->is_closing = false; // A close response, all done.
            } else {
                $this->send($status_bin . 'Close acknowledged: ' . $status, 'close', true); // Respond.
            }

            // Close the socket.
            //fclose($this->stream);
			$this->disconnect();
            // Closing should not return message.
            return [$payload, true, $opcode];
        }

        //return [$payload, $final, $opcode];
      	return [$final, $payload, $opcode, $masked];
    }
  	public function receive_c(){
        $filter = $this->options['filter'];
        if (!$this->isConnected()) {
            $this->connect();
        }

        do {
            $response = $this->receiveFragment();
            list ($payload, $final, $opcode) = $response;
			// Continuation and factual opcode
            $continuation = ($opcode == 'continuation');
            $payload_opcode = $continuation ? $this->read_buffer['opcode'] : $opcode;

            // Filter frames
            if (!in_array($payload_opcode, $filter)) {
                if ($payload_opcode == 'close') {
                    return null; // Always abort receive on close
                }
                $final = false;
                continue; // Continue reading
            }

            // First continuation frame, create buffer
            if (!$final && !$continuation) {
                $this->read_buffer = ['opcode' => $opcode, 'payload' => $payload, 'frames' => 1];
                continue; // Continue reading
            }

            // Subsequent continuation frames, add to buffer
            if ($continuation) {
                $this->read_buffer['payload'] .= $payload;
                $this->read_buffer['frames']++;
            }
        } while (!$final);

        // Final, return payload
        $frames = 1;
        if ($continuation) {
            $payload = $this->read_buffer['payload'];
            $frames = $this->read_buffer['frames'];
            $this->read_buffer = null;
        }
        $this->logger->log('INFO', __FUNCTION__." Received '{$opcode}' message", [
            'opcode' => $payload_opcode,
            'content-length' => strlen($payload),
            'frames' => $frames,
        ]);

        $this->last_opcode = $payload_opcode;
        $factory = new Factory();
        return $this->options['return_obj']
            ? $factory->create($payload_opcode, $payload)
            : $payload;
    }
  	public function receive_p(){
        $filter = $this->options['filter'];
        if (!$this->isConnected()) {
            $this->connect();
        }

        do {
            $response = $this->pullMessage();
                        if (!$this->isConnected()) {
                            $this->connection = null;
                        }
                        // Trigger callback according to filter
                      	list ($final, $payload, $opcode, $masked) = $response;
                        //$opcode = $message->getOpcode();
                        
			// Continuation and factual opcode
            $continuation = ($opcode == 'continuation');
            $payload_opcode = $continuation ? $this->read_buffer['opcode'] : $opcode;

            // Filter frames
            if (!in_array($payload_opcode, $filter)) {
                if ($payload_opcode == 'close') {
                    return null; // Always abort receive on close
                }
                $final = false;
                continue; // Continue reading
            }

            // First continuation frame, create buffer
            if (!$final && !$continuation) {
                $this->read_buffer = ['opcode' => $opcode, 'payload' => $payload, 'frames' => 1];
                continue; // Continue reading
            }

            // Subsequent continuation frames, add to buffer
            if ($continuation) {
                $this->read_buffer['payload'] .= $payload;
                $this->read_buffer['frames']++;
            }
        } while (!$final);

        // Final, return payload
        $frames = 1;
        if ($continuation) {
            $payload = $this->read_buffer['payload'];
            $frames = $this->read_buffer['frames'];
            $this->read_buffer = null;
        }
        $this->logger->log('INFO', __FUNCTION__." Received '{$opcode}' message", [
            'opcode' => $payload_opcode,
            'content-length' => strlen($payload),
            'frames' => $frames,
        ]);

        $this->last_opcode = $payload_opcode;
        $factory = new Factory();
        return $this->options['return_obj']
            ? $factory->create($payload_opcode, $payload)
            : $payload;
    }
  	
	protected function sendFragment(bool $final, string $payload, string $opcode, bool $masked): void {
		//$this->logger->log('DEBUG', __FUNCTION__." start");
        $data = '';

        $byte_1 = $final ? 0b10000000 : 0b00000000; // Final fragment marker.
        $byte_1 |= self::$opcodes[$opcode]; // Set opcode.
        $data .= pack('C', $byte_1);

        $byte_2 = $masked ? 0b10000000 : 0b00000000; // Masking bit marker.

        // 7 bits of payload length...
        $payload_length = strlen($payload);
        if ($payload_length > 65535) {
            $data .= pack('C', $byte_2 | 0b01111111);
            $data .= pack('J', $payload_length);
        } elseif ($payload_length > 125) {
            $data .= pack('C', $byte_2 | 0b01111110);
            $data .= pack('n', $payload_length);
        } else {
            $data .= pack('C', $byte_2 | $payload_length);
        }

        // Handle masking
        if ($masked) {
            // generate a random mask:
            $mask = '';
            for ($i = 0; $i < 4; $i++) {
                $mask .= chr(rand(0, 255));
            }
            $data .= $mask;

            // Append payload to frame:
            for ($i = 0; $i < $payload_length; $i++) {
                $data .= $payload[$i] ^ $mask[$i % 4];
            }
        } else {
            $data .= $payload;
        }

        $this->write($data);
        $this->logger->log('DEBUG', __FUNCTION__." Sent '{$opcode}' frame", [
            'opcode' => $opcode,
            'final' => $final,
            'content-length' => strlen($payload),
        ]);
    }
	protected function onError($code= null, $message) {
      	$this->logger->log('ERROR', __FUNCTION__." {$message} code: {$code} " );
      
    }
	protected function parser($_buffer){
        $this->logger->log('DEBUG', __FUNCTION__." start... ");
        $frameSizeLimit = 2097152; // 2MB 4096;
        $messageSizeLimit = 10485760;
        $textOnly = false;//$this->options->isTextOnly();
        $doUtf8Validation = false;//$validateUtf8 = $this->options->isValidateUtf8();

        $compressionContext = true;
        $compressedFlag = $compressionContext ? 0b100 : 0;

        $dataMsgBytesRecd = 0;
        $savedBuffer = '';
        $compressed = false;

        $buffer = $_buffer;
        $offset = 0;
        $bufferSize = strlen($buffer);

        $this->logger->log('DEBUG', __FUNCTION__." bufferSize: ".$bufferSize);
            $payload = ''; // Free memory from last frame payload.

            if ($bufferSize < 2) {
                $buffer = substr($buffer, $offset);
                $offset = 0;
                $buffer .= $_buffer;
                $bufferSize = strlen($buffer);
            }

            $firstByte = ord($buffer[$offset]);
            $secondByte = ord($buffer[$offset + 1]);

            $offset += 2;
            $bufferSize -= 2;

            $final = (bool) ($firstByte & 0b10000000);
            $rsv = ($firstByte & 0b01110000) >> 4;
            $opcode = $firstByte & 0b00001111;
            $isMasked = (bool) ($secondByte & 0b10000000);
            $maskingKey = '';
            $frameLength = $secondByte & 0b01111111;
			$this->logger->log('DEBUG', __FUNCTION__." opcode: ".$opcode);
            return;
        	if ($opcode >= 3 && $opcode <= 7) {
                $this->onError(Code::PROTOCOL_ERROR, 'Use of reserved non-control frame opcode');
                return;
            }

            if ($opcode >= 11 && $opcode <= 15) {
                $this->onError(Code::PROTOCOL_ERROR, 'Use of reserved control frame opcode');
                return;
            }

            $isControlFrame = $opcode >= 0x08;

            if ($isControlFrame || $opcode === Opcode::CONT) { // Control and continuation frames
                if ($rsv !== 0) {
                    $this->onError(Code::PROTOCOL_ERROR, 'RSV must be 0 for control or continuation frames');
                    return;
                }
            } else { // Text and binary frames
                if ($rsv !== 0 && (!$compressionContext || $rsv & ~$compressedFlag)) {
                    $this->onError(Code::PROTOCOL_ERROR, 'Invalid RSV value for negotiated extensions');
                    return;
                }

                //$doUtf8Validation = $validateUtf8 && $opcode === Opcode::TEXT;
                $compressed = (bool) ($rsv & $compressedFlag);
            }

            if ($frameLength === 0x7E) {
                while ($bufferSize < 2) {
                    $buffer = substr($buffer, $offset);
                    $offset = 0;
                    $buffer .= yield;
                    $bufferSize = strlen($buffer);
                }

                $frameLength = unpack('n', $buffer[$offset] . $buffer[$offset + 1])[1];
                $offset += 2;
                $bufferSize -= 2;
            } elseif ($frameLength === 0x7F) {
                while ($bufferSize < 8) {
                    $buffer = substr($buffer, $offset);
                    $offset = 0;
                    $buffer .= yield;
                    $bufferSize = strlen($buffer);
                }

                $lengthLong32Pair = unpack('N2', substr($buffer, $offset, 8));
                $offset += 8;
                $bufferSize -= 8;

                if (PHP_INT_MAX === 0x7fffffff) {
                    if ($lengthLong32Pair[1] !== 0 || $lengthLong32Pair[2] < 0) {
                        $this->onError(
                            Code::MESSAGE_TOO_LARGE,
                            'Received payload exceeds maximum allowable size'
                        );
                        return;
                    }
                    $frameLength = $lengthLong32Pair[2];
                } else {
                    $frameLength = ($lengthLong32Pair[1] << 32) | $lengthLong32Pair[2];
                    if ($frameLength < 0) {
                        $this->onError(
                            Code::PROTOCOL_ERROR,
                            'Most significant bit of 64-bit length field set'
                        );
                        return;
                    }
                }
            }

            if ($frameLength > 0 && $isMasked === $this->masked) {
                $this->onError(
                    Code::PROTOCOL_ERROR,
                    'Payload mask error'
                );
                return;
            }

            if ($isControlFrame) {
                if (!$final) {
                    $this->onError(
                        Code::PROTOCOL_ERROR,
                        'Illegal control frame fragmentation'
                    );
                    return;
                }

                if ($frameLength > 125) {
                    $this->onError(
                        Code::PROTOCOL_ERROR,
                        'Control frame payload must be of maximum 125 bytes or less'
                    );
                    return;
                }
            }

            if ($frameSizeLimit && $frameLength > $frameSizeLimit) {
                $this->onError(
                    Code::MESSAGE_TOO_LARGE,
                    'Received payload exceeds maximum allowable size'
                );
                return;
            }

            if ($messageSizeLimit && ($frameLength + $dataMsgBytesRecd) > $messageSizeLimit) {
                $this->onError(
                    Code::MESSAGE_TOO_LARGE,
                    'Received payload exceeds maximum allowable size'
                );
                return;
            }

            if ($textOnly && $opcode === Opcode::BIN) {
                $this->onError(Code::UNACCEPTABLE_TYPE,'BINARY opcodes (0x02) not accepted' );
                return;
            }

            if ($isMasked) {
                while ($bufferSize < 4) {
                    $buffer = substr($buffer, $offset);
                    $offset = 0;
                    $buffer .= yield;
                    $bufferSize = strlen($buffer);
                }

                $maskingKey = substr($buffer, $offset, 4);
                $offset += 4;
                $bufferSize -= 4;
            }

            while ($bufferSize < $frameLength) {
                $chunk = yield;
                $buffer .= $chunk;
                $bufferSize += strlen($chunk);
            }

            $payload = substr($buffer, $offset, $frameLength);
            $buffer = substr($buffer, $offset + $frameLength);
            $offset = 0;
            $bufferSize = strlen($buffer);

            if ($isMasked) {
                // This is memory hungry but it's ~70x faster than iterating byte-by-byte
                // over the masked string. Deal with it; manual iteration is untenable.
                /** @psalm-suppress InvalidOperand String operands expected. */
                $payload ^= str_repeat($maskingKey, ($frameLength + 3) >> 2);
            }

            

            $dataMsgBytesRecd += $frameLength;

            if ($savedBuffer !== '') {
                $payload = $savedBuffer . $payload;
                $savedBuffer = '';
            }

            if ($compressed) {
                /** @psalm-suppress PossiblyNullReference */
                $payload = $compressionContext->decompress($payload, $final);

                if ($payload === null) { // Decompression failed.
                    $this->onError(Code::PROTOCOL_ERROR,'Invalid compressed data');
                    return;
                }
            }

           
            

            //$this->onData($opcode, $payload, $final);
          	return ['opcode' => $opcode,'payload' => $payload,'final' => $final];
        
    }
  
  	public function setClient(WebSocketClientInterface $client){
        $this->client = $client;
        return $this;
    }

    /**
     * @return WebSocketClientInterface
     */
    public function getClient(){
        return $this->client;
    }
  	public function setLoop(LoopInterface $loop){
        $this->loop = $loop;
        return $this;
    }

    /**
     * @return LoopInterface
     */
    public function getLoop(){
        return $this->loop;
    }
	
  
  	public function test(){
      $ressource= get_resource_type($this->stream);
      	$this->logger->log('DEBUG', __FUNCTION__." ressource : {$ressource}");
      $meta = $this->getMeta();//stream_get_meta_data($this->stream);
      
      	$this->logger->log('DEBUG', __FUNCTION__." meta : ".json_encode($meta));
      $set_blocking = stream_set_blocking($this->stream);
      	$this->logger->log('DEBUG', __FUNCTION__." set_blocking : ".$set_blocking);
      $set_read_buffer= stream_set_read_buffer($this->stream);
      	$this->logger->log('DEBUG', __FUNCTION__." set_read_buffer : ".$set_read_buffer);
      
      //$header = stream_get_line($this->stream, 4096, "\r\n\r\n");
      //$this->logger->log('INFO', __FUNCTION__." header : ".$header);
      /*
      if (!is_resource($this->stream) || get_resource_type($this->stream) !== "stream") {
             throw new InvalidArgumentException('First parameter must be a valid stream resource');
        }

        // ensure resource is opened for reading (fopen mode must contain "r" or "+")
        
        if (isset($meta['mode']) && $meta['mode'] !== '' && strpos($meta['mode'], 'r') === strpos($meta['mode'], '+')) {
            throw new InvalidArgumentException('Given stream resource is not opened in read mode');
        }

        // this class relies on non-blocking I/O in order to not interrupt the event loop
        // e.g. pipes on Windows do not support this: https://bugs.php.net/bug.php?id=47918
        if (stream_set_blocking($this->stream, false) !== true) {
            throw new RuntimeException('Unable to set stream resource to non-blocking mode');
        }
      	if (function_exists('stream_set_read_buffer') && !$this->isLegacyPipe($this->stream)) {
            stream_set_read_buffer($this->stream, 0);
      	}
      	*/
      	$bufferSize = ($readChunkSize === null) ? 65536 : (int)$readChunkSize;
      	$content = stream_get_contents($this->stream, $bufferSize);
      		$this->logger->log('DEBUG', __FUNCTION__." content : {}".$content);
     	$local=stream_socket_get_name($this->stream, false);
      		$this->logger->log('DEBUG', __FUNCTION__." local : {}".$local);
      	$server=stream_socket_get_name($this->stream, true);
      		$this->logger->log('DEBUG', __FUNCTION__." server : {}".$server);
      	
    }
  	public function handleClose(){
        if (!is_resource($this->stream)) {
            return;
        }

        // Try to cleanly shut down socket and ignore any errors in case other
        // side already closed. Shutting down may return to blocking mode on
        // some legacy versions, so reset to non-blocking just in case before
        // continuing to close the socket resource.
        // Underlying Stream implementation will take care of closing file
        // handle, so we otherwise keep this open here.
        @stream_socket_shutdown($this->stream, \STREAM_SHUT_RDWR);
        stream_set_blocking($this->stream, false);
      	
    }


}