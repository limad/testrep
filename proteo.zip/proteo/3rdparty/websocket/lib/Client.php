<?php

/**
 * Copyright (C) 2014-2020 Textalk/Abicart and contributors.
 *
 * This file is part of Websocket PHP and is free software under the ISC License.
 * License text: https://raw.githubusercontent.com/Textalk/websocket-php/master/COPYING
 */

namespace WebSocket;
error_reporting(E_ALL);

use WebSocket\Exception\{ConnectionException};
use WebSocket\Message\{Factory, Message};
//use WebSocket\Exception\;

class Client extends Base {
    // Default options
    protected static $default_options = [
		//'event_handler'	=> null,//function to get return
		'context'		=> null,
		'filter'		=> ['text', 'binary'],
		'fragment_size'	=> 4096,
		'headers'		=> null,
		'logger'		=> null,
		'origin'		=> null, // @deprecated
		'persistent'	=> false,
		'async'			=> false,
		'return_obj'	=> false,
		'timeout'		=> 5,
		'callback'		=> null,//function to get return
    ];
	protected $sock_uri;

    /**
     * @param string $uri     A ws/wss-URI
     * @param array  $options
     *   Associative array containing:
     *   - context:       Set the stream context. Default: empty context
     *   - timeout:       Set the socket timeout in seconds.  Default: 5
     *   - fragment_size: Set framgemnt size.  Default: 4096
     *   - headers:       Associative array of headers to set/override.
     */
    public function __construct(string $uri, array $options = []){
        $this->options = array_merge(self::$default_options, $options);
        $this->setLogger($this->options['logger']);
        $this->setCallback($this->options['callback']);
      	$this->sock_uri = $uri;
        $this->msg_factory = new Factory();
      	$this->connect();
    }

    public function __destruct(){
        //$backtrace = debug_backtrace(false, 2)[1]['function'];
		$this->logger->log('DEBUG', __FUNCTION__."() start... ");//from: {$backtrace}
      	if ($this->isConnected()) {
          	$this->logger->log('ERROR', __FUNCTION__." connected closing socket...");
            fclose($this->stream);
        }
      	/*if ($this->getType() === 'stream') {
            fclose($this->stream);
        }*/
        $this->stream = null;
    }

    /**
     * Perform WebSocket handshake
     */
    protected function connect(): void{
      	$this->logger->info(" *");
      	$this->logger->info(" ┌───────── ".__FUNCTION__." start");
      	//$this->sendEvent("info","",  "➡ api::connecting() start...");
      	//($message, $connection = '', $type = null )
      	//$this->Event("➡ api::connecting() start...", "info");
      	
      
      	$this->connection = null;
      	$url_parts = parse_url($this->sock_uri);
        if (empty($url_parts) || empty($url_parts['scheme']) || empty($url_parts['host'])) {
            $error = "Invalid url '{$this->sock_uri}' provided.";
            $this->logger->error("| ".__FUNCTION__." ".$error);
            throw new BadUriException($error);
        }
        $scheme    = $url_parts['scheme'];
        $host      = $url_parts['host'];
        $user      = isset($url_parts['user']) ? $url_parts['user'] : '';
        $pass      = isset($url_parts['pass']) ? $url_parts['pass'] : '';
        $port      = isset($url_parts['port']) ? $url_parts['port'] : ($scheme === 'wss' ? 443 : 80);
        $path      = isset($url_parts['path']) ? $url_parts['path'] : '/';
        $query     = isset($url_parts['query'])    ? $url_parts['query'] : '';
        $fragment  = isset($url_parts['fragment']) ? $url_parts['fragment'] : '';

        $path_with_query = $path;
        if (!empty($query)) {
            $path_with_query .= '?' . $query;
        }
        if (!empty($fragment)) {
            $path_with_query .= '#' . $fragment;
        }

        if (!in_array($scheme, ['ws', 'wss'])) {
            $error = "Url should have scheme ws or wss, not '{$scheme}' from URI '{$this->sock_uri}'.";
            $this->logger->error("| ".__FUNCTION__." ".$error);
            throw new BadUriException($error);
        }

        $host_uri = ($scheme === 'wss' ? 'ssl' : 'tcp') . '://' . $host;

        // Set the stream context options if they're already set in the config
        if (isset($this->options['context'])) {
            // Suppress the error since we'll catch it below
            if (@get_resource_type($this->options['context']) === 'stream-context') {
                $context = $this->options['context'];
            } else {
                $error = "Stream context in options['context'] isn't a valid context.";
                $this->logger->error("| ".__FUNCTION__." ".$error);
                throw new InvalidArgumentException($error);
            }
        } else {
            $context = stream_context_create();
        }

        $persistent = $this->options['persistent'] === true;
      	$async = $this->options['async'] === true;
      	
        $flags = STREAM_CLIENT_CONNECT;
        if($async === true){
          	$this->logger->debug("| ".__FUNCTION__." ".'async mode enabled');
          	$flags = $flags | STREAM_CLIENT_ASYNC_CONNECT;
          	//$this->options['timeout'] = 0;
        }elseif($persistent === true){
          	$this->logger->debug("| ".__FUNCTION__." ".'persistent mode enabled');
          	$flags = $flags | STREAM_CLIENT_PERSISTENT;
          	//$flags = $flags | STREAM_CLIENT_ASYNC_CONNECT;
        }
      
      
      
        $error = $errno = $errstr = null;
        set_error_handler(function (int $severity, string $message, string $file, int $line) use (&$error) {
            $this->logger->warning("| ".__FUNCTION__." ".$message, ['severity' => $severity]);
            $error = $message;
        }, E_ALL);
		//max(ini_get("default_socket_timeout"),$this->options['timeout']), //$this->options['timeout'],//ini_get("default_socket_timeout")
      	$stream_timeout = $this->options['timeout'] >= 5 ? $this->options['timeout'] : 30;
        // Open the socket.
        $stream = stream_socket_client(
            "{$host_uri}:{$port}",
            $errno,
            $errstr,
            $stream_timeout,
            $flags,
            $context
        );

        restore_error_handler();

       
		if (!$stream) {//!$this->isConnected()
            $error = "Could not open socket to \"{$host}:{$port}\": {$errstr} ({$errno}) {$error}.";
            $this->logger->error("| ".__FUNCTION__." ".$error);
            throw new ConnectionException($error);
        }
		$this->stream = $stream;
        if (!$this->isConnected()) {
            $error = "Invalid stream on \"{$host}:{$port}\": {$errstr} ({$errno}) {$error}.";
            $this->logger->error("| ".__FUNCTION__." ".$error);
            throw new ConnectionException($error);
        }
      	
      	
      	
      	
        if (1 == 1) { //|| ftell($stream) == 0
          	$this->logger->debug("| ".__FUNCTION__.' setting timeout '.$this->options['timeout']."--default: ".ini_get("default_socket_timeout"));
            // Set timeout on the stream as well.
           // stream_set_timeout($stream , $this->options['timeout']);
			if (@stream_set_timeout($stream, $this->options['timeout']) == false) {
                $this->logger->debug("| ".__FUNCTION__.' Unable to set timeout '.$this->options['timeout']);
            }
         }
      // Generate the WebSocket key.
            $key = self::generateKey();

            // Default headers
            $headers = [
                'Host'                  => $host . ":" . $port,
                'User-Agent'            => 'websocket-client',
                'Connection'            => 'Upgrade',
                'Upgrade'               => 'websocket',
                'Sec-WebSocket-Key'     => $key,
                'Sec-WebSocket-Version' => '13',
             ];

            // Handle basic authentication.
            if ($user || $pass) {
                $headers['authorization'] = 'Basic ' . base64_encode($user . ':' . $pass);
            }

            // Deprecated way of adding origin (use headers instead).
            if (isset($this->options['origin'])) {
                $headers['origin'] = $this->options['origin'];
            }

            // Add and override with headers from options.
            if (isset($this->options['headers'])) {
                $headers = array_merge($headers, $this->options['headers']);
            }

            $header = "GET " . $path_with_query . " HTTP/1.1\r\n" . implode(
                "\r\n",
                array_map(
                    function ($key, $value) {
                        return "$key: $value";
                    },
                    array_keys($headers),
                    $headers
                )
            ) . "\r\n\r\n";

            // Send headers.
            $this->write($header);

            // Get server response header (terminated with double CR+LF).
            $response = stream_get_line($stream, 1024, "\r\n\r\n");
			$this->logger->debug("| "."stream_get_line response: {$response}");
            /// @todo Handle version switching

            $address = "{$scheme}://{$host}{$path_with_query}";

            // Validate response.
            if (!preg_match('#Sec-WebSocket-Accept:\s(.*)$#mUi', $response, $matches)) {
                $error = "Connection to '{$address}' failed: Server sent invalid upgrade response: {$response}";
                $this->logger->error("| ".__FUNCTION__." ".$error);
                throw new ConnectionException($error);
            }

            $keyAccept = trim($matches[1]);
            $expectedResonse
                = base64_encode(pack('H*', sha1($key . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')));

            if ($keyAccept !== $expectedResonse) {
                $error = 'Server sent bad upgrade response.';
                $this->logger->error(__FUNCTION__." ".$error);
                throw new ConnectionException($error);
            }
       
      
      
      	$this->connection = true; //new Connection($stream, $this->options);
		$mode = get_resource_type($stream);
        $this->logger->info(" | "."Client connected to {$address}"." resource_type: : {'$mode'} : {'$stream'}" );
      	//$this->sendEvent("info", "", "➡ api::connectted in: {'$mode'} mode");
      	//$this->Event("➡ api::connected in: {'$mode'} mode", "info");
      
      	$eventMsg=["status"=>"connected", "mode"=>$mode];
      	$this->Event(json_encode($eventMsg), "notice");
      	//$this->Event('{"status":"connected"}', "notice");
      	//stream_context_set_option($context, 'ssl', 'verify_peer_name', false);
      
      	$nonBlocking = @stream_set_blocking($stream, false);
      	if ($nonBlocking !== true) {
          	$this->logger->debug("| ".'Unable to set stream resource to non-blocking mode');
            //$this->sendEvent("info", "", "Unable to set stream resource to non-blocking mode");
          	$this->Event("Unable to set stream resource to non-blocking mode", "info");
          //throw new \RuntimeException('Unable to set stream resource to non-blocking mode');
        }else{//if(1==1)
          	$this->logger->debug("| ".' non-blocking mode enabled: ' .(int)$nonBlocking);
			$set_read_buffer = @stream_set_read_buffer($stream,2);//8192,0
      		if ($set_read_buffer !== 0) {//Set read file buffering on the given stream
          		$this->logger->debug("| ".'Unable to set READ file buffering size');
            	//$this->sendEvent("info", "", "Unable to set READ file buffering size");
              	$this->Event("Unable to set READ file buffering size", "info");
          
          ///throw new \RuntimeException('Unable to set stream resource to non-blocking mode');
            }
          
          
          //$this->logger->log('DEBUG', __FUNCTION__." set_read_buffer : ".$set_read_buffer);
			/*
          	$set_write_buffer = @stream_set_write_buffer($stream, 0);//8192,0
            if ($set_write_buffer !== 0) {//Set read file buffering on the given stream
          		$this->logger->debug('Unable to set  WRITE buffering size');
            }
          
          	
          	if (function_exists('socket_import_stream')) {
                if (($scheme === 'tcp') || ($scheme === 'unix')) {
                        $stream = @socket_import_stream($stream);
                        @socket_set_option($stream, SOL_SOCKET, SO_KEEPALIVE, 1);//keepAlive
                        if ($scheme === 'tcp') {
                            @socket_set_option($stream, SOL_TCP, TCP_NODELAY, 1);//noDelay
                        }
                }
                if ($scheme === 'tcp') {
                    $raw_socket = @socket_import_stream($stream);
                    @socket_set_option($stream, SOL_SOCKET, SO_KEEPALIVE, 1);
                    @socket_set_option($stream, SOL_TCP, TCP_NODELAY, 1);
            	}
			}
               */ 
        }
      	
      	$metaData = stream_get_meta_data($stream);
      	if (strpos($metaData["mode"], "r") !== false && \strpos($metaData["mode"], "+") === false) {
            throw new Error("Expected a writable stream");
        }
      	$this->logger->debug("| ". __FUNCTION__."\r\n"
									." meta_timed_out:  {$metaData
                                      ['timed_out']} "."\r\n"
									." meta_eof:  {$metaData['eof']} "."\r\n"
									." meta_blocked:  {$metaData['blocked']} "
									." meta_unread_bytes:  {$metaData['unread_bytes']} "
									." metadata:". json_encode($metaData)
                                   	." non Blocking mode :  ". (int)($nonBlocking == true)
                           			." set_read_buffer to 0 :  ". (int)($set_read_buffer == 0)
                                    //." set_write_buffer to 0 :  ". (int)($set_write_buffer == 0) . "\r\n\r\n"
                                    );
       //$this->getInfos();
      //$this->logger->info("response:  {$response}");
      	//$this->logger->info("Request_header: ".json_encode($header));
      	//$this->logger->info("resource_type: ".get_resource_type($stream));
       $this->logger->debug("└──────────────────────────────────── ");
      	
    }
	 /**
     * Generate a random string for WebSocket key.
     *
     * @return string Random string
     */
    protected static function generateKey(): string {
        $key = '';
        for ($i = 0; $i < 16; $i++) {
            $key .= chr(rand(33, 126));
        }
        return base64_encode($key);
    }
  
  	public function setLogger($logger = null){
      	$this->logger = $logger ? : new NullLogger();
      //$this->logger = $logger ? : null;
    }
    public function setCallback($callback = null): self {
		if($callback && is_callable($callback, true)){
          	$this->callback = $callback;
        }else{
          	$this->callback = null;
          	if(!is_callable($callback, true)){
          		$this->logger->log('WARNING', __FUNCTION__." ". $callback." is not a callable function");
            }
        }
        return $this;
    }	
    public function Event($message, $type = null) {
		$callback = $this->callback;
		if(is_null($callback)){
          	return false;
        }
		$result = $callback($message, $this->connection, $type);
		if (!is_null($result)) {
			//$this->logger->debug("|          ". __FUNCTION__." callback ok");
          	return $result;
		}
      
    }
  	public function getId() {
		return $this->stream;
    }
  	/* ---------- Stream I/O methods ------------------------------------------------- */

    public function getStream() {
		$this->logger->debug( __FUNCTION__." start");
        return $this->isConnected() ? $this->stream : null;
    } 
  
  /**
     * Disconnect from client/server.
     */
    public function disconnect(): void {
      	$backtrace = debug_backtrace(false, 2)[1]['function'];
		$this->logger->debug( __FUNCTION__."() start... from: {$backtrace}");
      	//$this->sendEvent("WARNING", "", __FUNCTION__."() start... from: {$backtrace}");
      	$this->Event( __FUNCTION__."() start... from: {$backtrace}", "WARNING");
		$this->is_closing = true;
      	fclose($this->stream);
        $this->stream = null;
        
    }
  	
}