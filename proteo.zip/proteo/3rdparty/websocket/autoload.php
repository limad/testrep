<?php
 	//require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';
    //PHP version check
    if (version_compare(PHP_VERSION, '7.2.0', '<')){
        throw new Exception('SDK requires PHP 7.2.0 or higher.');
    }

    //required libraries
    if (!function_exists('curl_version')){
        throw new Exception('SDK requires cURL extension.');
    }

    if(!function_exists('json_decode')){
        throw new Exception('SDK requires JSON extension.');
    }
	
	//base directory for the namespace prefix
    $baseDir = __DIR__;
	//project-specific namespace prefix to load
    $prefix = 'WebSocket\\';//.'/'lib/
	//list all sub directory of $baseDir
	//$cdir = scandir($baseDir);
	$lodingDirs = [];
	//search all subb directory
	foreach (scandir($baseDir) as $value){
		if (!in_array($value,array(".","..")) && is_dir($baseDir . DIRECTORY_SEPARATOR . $value)  ){//.$dir . DIRECTORY_SEPARATOR 
			//log::add('naEnergie', 'debug', "Directory: {$value}");
			$lodingDirs[] = $baseDir. DIRECTORY_SEPARATOR . $value .DIRECTORY_SEPARATOR;
		}
    }



	function autoload($class){
      	global $lodingDirs;
      	global $prefix;
      	global $baseDir;
         	
      	//does the class use the namespace prefix?
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0){
            //no move to the next registered autoloader
            return;
        }
		
        //get the relative class name
        $relative_class = substr($class, $len);
		// replace the namespace prefix with the base directory, replace namespace
        // separators with directory separators in the relative class name, append
        // with .php
        foreach ($lodingDirs as $lodingDir){
            $file = $lodingDir . str_replace('\\', '/', $relative_class) . '.php';
          	//if the file exists, require it
          	if (file_exists($file)){
				//log::add('naEnergie', 'error', "	class: ".$class." relative_class: ".$relative_class."::".$file);
              
              	require $file;
              	break;
			}
        }
    }  	
    
	//spl_autoload_extensions(".php"); // comma-separated list
    spl_autoload_register('autoload', true);



?>