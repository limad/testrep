<?php error_reporting(E_ALL);
require_once dirname(__FILE__) . '/../../../core/php/core.inc.php';
use GuzzleHttp\Client;
use GuzzleHttp\Cookie\FileCookieJar;

class proteoAPI {

	public $_version = '0.1';
    const STATUS_CONNECTED = 1;
	const STATUS_CONNECTING = 2;
	const STATUS_UNUSED = 4;
	const STATUS_NOT_CONNECTED = 0;

/////////////////////////////////////*********************///////////////////////////////////// 
	public static function getClient($force=false){
		//log::add('proteo', 'debug', __FUNCTION__ .' start ');
		$ip = config::byKey('ipBox', 'proteo');
		$login = config::byKey('proteoLogin', 'proteo');
		$password = config::byKey('proteoPassword', 'proteo');
		$tokenurl = 'http://' . $ip . '/api/1.0/?method=auth.getToken';
			
		$authToken = cache::bykey('proteo' . '_token_auth')->getValue();
		
		$date = new DateTime();
		$Timestamp = $date->getTimestamp();
		$tokenAge=round( ($Timestamp - cache::bykey('proteo' . '_token_time')->getValue() )/60, 1);
		log::add('proteo', 'debug', __FUNCTION__ .' authToken... '.$authToken);	
		if($authToken===null || $authToken==='' || $authToken === 'Not connected' || $tokenAge >= 54 || $force != false){//|| $tokenAge >= 60
			log::add('proteo', 'debug', __FUNCTION__ .' Reniew token...:  '.$authToken.' age: '.$tokenAge);
			$post = array('method' => 'auth.getToken');
			////////////////////
			$params['method']='auth.getToken';
			
			$url = 'http://' . $ip . '/api/1.0/'; 
			$rqstResp = self::simpleRqst($url, $params);
			log::add('proteo', 'debug', __FUNCTION__ .' authToken... '.substr($authToken, 0, 8).'...');	
			if ($rqstResp['status'] === 200) {
				//log::add('proteo', 'debug', __FUNCTION__ .' rqstResp1 = ' . $rqstResp['curlrsp']);
				$neufbox = new SimpleXMLElement($rqstResp['curlrsp']);
				$tok = (string)$neufbox->auth['token'];
				$begin = date('Y-m-d H:i:s');
				if($tok != ''){
					$hash = hash_hmac('sha256', hash('sha256', $login), $tok) . hash_hmac('sha256', hash('sha256', $password), $tok);
					$params=array();
					$params['method']='auth.checkToken';
					$params['token'] = $tok;
					$params['hash'] = $hash;
					$auth_rqst = self::simpleRqst($url, $params);
					//log::add('proteo', 'debug', __FUNCTION__ .' tok = ' . $tok);
				
					$authtoken = new SimpleXMLElement($auth_rqst['curlrsp']);
					if ($authtoken['stat'] == 'ok') {
						$token = strval($authtoken->auth['token']);
							
						$date = new DateTime();
						$Timestamp = $date->getTimestamp();
						cache::set('proteo' . '_token_auth' , $token);
						cache::set('proteo' . '_token_time' , $Timestamp);
						$result_msg = 'ok';
						//log::add('proteo', 'debug', __FUNCTION__ .' authtoken = ' . $token);
					}
					else{
						cache::set('proteo' . '_token_auth' , 'Not connected');
						$result_msg =  'bad request=> '.$authtoken->{'err'}['msg'] . ' while retriving your token';
						//throw new Exception(__('proteo: '. $authtoken->{'err'}['msg'] . ' while retriving your token', __FILE__));
						//log::add('proteo', 'error', '' . $authtoken->{'err'}['msg'] . ' while retriving your token');
					}
				}
			}
			else{
				$result_msg =  'bad request: '.' Unexpected HTTP code: '. $rqstResp['status'] ;//
				$arp = self::getarp($ip);
				if($arp == ''){
				    $result_msg .= ' Ip injoignable'.$arp ;
				}else{
				    $result_msg .= ' ' .$arp .' ne semble pas une box SFR valide';
				}
				
				
			}
			//end if ($rqstResp['status'] === 200
		} 
		else {
			$result_msg = 'ok';
		}
		return $result_msg;
	}
/////////////////////////////////////*********************///////////////////////////////////// 
	public static function _request($apiMethod, $curlMethod = 'GET', $force = false) {
		$client = self::getClient();
		$ipBox = config::byKey('ipBox', 'proteo');
		$token = cache::bykey('proteo' . '_token_auth')->getValue();
		$noderesp=strval(substr($apiMethod, 0, strpos($apiMethod, '.')));
		
         //
		$date = new DateTime();
		$Timestamp = $date->getTimestamp();
		$difftime=($Timestamp - cache::bykey('proteo' . '_token_time')->getValue() )/60;//nb heuees
		$durem_t=$difftime % 1440;//durée en minutes
		$tokenAge=date('H:i', mktime(0,$durem_t));
		
		$params['method']=$apiMethod;
		if (isset($token)){		
			$params['token']=$token;
		}
		$url = 'http://' . $ipBox . '/api/1.0/'; 
		$url .= '?' . http_build_query($params, NULL, '&');
		
		
		if (!isset($ch)){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		}

		curl_setopt($ch, CURLOPT_URL, $url);

		if ($curlMethod == 'POST'){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
        
		$rqstResp = curl_exec($ch);
		if (!curl_errno($ch)) {
		    $xmlNode = simplexml_load_string($rqstResp);
		    $arData = BoxHelper::xmlToArray($xmlNode);
		    if(isset($arData['rsp']) && $arData['rsp']['stat'] === 'ok'){
			    $rsp=$arData['rsp'];
			    //log::add('proteo','debug','          '. __FUNCTION__ .' ok for '.$apiMethod );	//.' '.$noderesp. ': ' .json_encode($arData['rsp'])
			    log::add('proteo','debug','          '. __FUNCTION__ .' ok for '.$apiMethod .json_encode($arData['rsp']));	//.' '.$noderesp. ': ' .json_encode($arData['rsp'])
			    return $rsp;
		    }else if(isset($arData['rsp']) && $arData['rsp']['stat'] === 'fail'){
			    if($arData['rsp']['err']['msg'] === 'Authentication needed' && $force == false){
				    log::add('proteo','debug','          '. __FUNCTION__ .'Authentication needed for '.$apiMethod .'lets reniew token');
				    self::getClient(true);
				    self::_request($apiMethod, $curlMethod,true);
			    }else{
				    log::add('proteo','error', __FUNCTION__ .' Error for: ' .$apiMethod.': ' .$arData['rsp']['err']['msg']);	//. ' tokenAge: ' .$tokenAge .' min'
			    }
			    //return $arData['rsp']['err']['msg'];
		    }
		}else{}
        
    }
/////////////////////////////////////*********************/////////////////////////////////////
	public static function simpleRqst($url, $params= null, $curlMethod = 'GET') {
	
		//log::add('proteo', 'debug', __FUNCTION__ .' params = ' . json_encode($params));
		$url = $url; 
		if ($params != null){
			$url .= '?' . http_build_query($params, NULL, '&');
		}
		
		if (!isset($ch)){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		}

		curl_setopt($ch, CURLOPT_URL, $url);

		if ($curlMethod == 'POST'){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
        
		$rqstResp = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$info = curl_getinfo($ch);
		
		if (!curl_errno($ch)) {//pas d'erreur
			switch ($http_code) {
				case 200:  # OK
					$return['status']=$http_code;
					$return['curlrsp'] = $rqstResp;
				break;
				default:
				   $return['status']=$http_code;//.'--'.json_encode($info)
					$return['curlrsp'] = json_encode($info);
					
			
			}
		}else{
			//log::add('proteo', 'debug', __FUNCTION__ .' Unexpected HTTP code: ' . $http_code);
			$return['status']=$http_code;//.'--'.json_encode($info);
			$return['curlrsp'] = null;
		}
		
		curl_close($ch);
		
		return $return;
		
        
    }
/////////////////////////////////////*********************/////////////////////////////////////   
	public static function getarp($ip) {
		$exec_string = 'arp -a '.$ip;
		exec($exec_string, $output, $return);
		$arp=$output[0];
		   
		$lines=explode("\n", $arp);
		$mac ='';		
		foreach($lines as $line){
			$cols=explode(' ', trim($line));
			$mac = $cols[3];//strval(trim($cols[3]));
			if(filter_var($mac, FILTER_VALIDATE_MAC)){ 
			$name=($cols[0]?$cols[0]:'---');
			$return='macAddr : '.$mac.'('.$name.')';
			
			} else {
			$return='';
			
			}
			
		}
		return $return ;	
    }
/////////////////////////////////////*********************/////////////////////////////////////
	public static function testIp($host){
        
		$fsock = fsockopen($host, '80', $errno, $errstr, 5);
        if (! $fsock ) {
            
            return $fsock;
	    
	}else{
	    //log::add('proteo', 'debug', '		********* '. 'IP: '.$host.' semble en ligne ********* ');
	    return $fsock;
	}
        fclose($fsock);
    }
    
/////////////////////////////////////*********************/////////////////////////////////////
	public static function getExtIp() {
		$cmds = array('ipinfo.io/ip','ipecho.net/plain','ifconfig.me');
		$check = '';
		foreach($cmds as $cmd) {
			$ip = 'sudo curl ' . $cmd;
			$ip = exec($ip);
			if (filter_var($ip, FILTER_VALIDATE_IP)) {
				return $ip;
				break;
			} else {
				$check = false;
			}
		}
		if(!$check) {
			log::add('proteo', 'error', '!!! Impossible de détecter l\'adresse IP !!!');	
			return false;	
		}
	}
/////////////////////////////////////*********************/////////////////////////////////////
	public static function pingExec($host, $_mode = 'ip') {
		$latency = false;
		//$ttl = escapeshellcmd($this->ttl);
		//$host = escapeshellcmd($this->host);
		if ($_mode == 'arp') {
			$exec_string = 'sudo arping -c 10 -C 1 -w 500000 ' . $host;
		} else {
			//$exec_string = 'sudo ping -n -c 1 -t ' . $ttl . ' ' . $host;
			$exec_string = 'sudo ping -n -c 1 -t 1 '.$host;
		}
		exec($exec_string, $output, $return);
		$output = array_values(array_filter($output));
		if (!empty($output[1])) {
			$response = preg_match("/time(?:=|<)(?<time>[\.0-9]+)(?:|\s)ms/", $output[count($output)-4], $matches);
			if ($response > 0 && isset($matches['time'])) {
				$latency = $matches['time'];
			}
		}else{
		    $output='vide';
		}
		//return $output;
		return $latency;
	}
/////////////////////////////////////*********************/////////////////////////////////////
	public static function pingPort($host,$port,$ttl) {
		$start = microtime(true);
		$fp = @fsockopen($host, $port, $errno, $errstr, $ttl);
		if (!$fp) {
			$latency = false;
		} else {
			$latency = microtime(true) - $start;
			$latency = round($latency * 1000);
		}
		return $latency;
	}
 
/////////////////////////////////////*********************///////////////////////////////////// 
	public static function macVendor($mac_address) {
		//$mac_address = "FC:FB:FB:01:FA:21";
		$url = "https://api.macvendors.com/". urlencode($mac_address);
      
		$params= null;
		$response=self::simpleRqst($url,$params);
		log::add('proteo', 'debug', __FUNCTION__ .' response = ' . $response['curlrsp'] );
	//	$ch = curl_init();
		//curl_setopt($ch, CURLOPT_URL, $url);
	//	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//$response = curl_exec($ch);
		if($response['status']==200) {
			$virgPos=strpos($response['curlrsp'], ',');
          	if($virgPos !=''){
              //log::add('proteo', 'debug', __FUNCTION__ .'virgPos = ' . $virgPos);
				$vendor=substr($response['curlrsp'], 0, $virgPos);
        	}else{
            	$vendor=$response['curlrsp'];
          	}
			//log::add('proteo', 'debug', __FUNCTION__ .' vendor = ' . $vendor);
         
          
          return trim($vendor).'_'.substr($mac_address, 12, 16);
		} else {
			return $mac_address;
		}
		
	}
/////////////////////////////////////*********************///////////////////////////////////// 
    public static function httpLogin($method=null){ 
		$filename = 'cookie_sfr';
		$cookieFile = jeedom::getTmpFolder('proteo').'/'.$filename;
		$cookieJar = new FileCookieJar($cookieFile, TRUE);
		$ip = config::byKey('ipBox', 'proteo');
		$boxUrl = 'http://' . $ip;
		
		//Step 1 Get Challenge*******************************//
		/////////////////////////////////////////
		$client = new Client([ 
			'base_uri' => $boxUrl,
			'cookies' => $cookieJar,
		]);
		
		$response = $client->request('POST', '/login', [
						'headers'  => [
										'X-Requested-With' => ' XMLHttpRequest',
										'X-Requested-Handler' => ' ajax',
									],
						'form_params' => ['action' => 'challenge']
				]);	
		if($response->getStatusCode() != 200){
				//throw new Exception(__('Request Erreur : '.$response->getStatusCode(), __FILE__) );
		}else{
			$return = $response->getBody()->getContents();
			//echo '</br>-return1 : '.$return;
			$xml = new SimpleXMLElement($return);
			$challenge=(string) $xml->challenge;
		}
		cache::set('proteo' . '_challenge' , $challenge);
		log::add('proteo', 'debug', __FUNCTION__ .' response: '.$response->getStatusCode());
		log::add('proteo', 'debug', __FUNCTION__ .' challenge: '.$challenge);
		//Step 2 Get sid*******************************//
		/////////////////////////////////////////
		
		$login = config::byKey('proteoLogin', 'proteo');
		$password = config::byKey('proteoPassword', 'proteo');
		$hash=hash_hmac('sha256', hash('sha256', $login), $challenge).hash_hmac('sha256', hash('sha256', $password), $challenge);
			$body = array(
							'method' => 'passwd',
								'zsid' => $challenge,
								'hash' => $hash,
								//'page_ref'=> '/state/lan',//'/maintenance/system'
								'login' => '',
								'password' => '',);
		$response2 = $client->request('POST', '/login', ['form_params' => $body]);
		log::add('proteo', 'debug', __FUNCTION__ .' response2: '.$response2->getStatusCode());
		if($response2->getStatusCode() != 200){
				//throw new Exception(__('Request Erreur : '.$response->getStatusCode(), __FILE__) );
		}else{
			$return2 = $response2->getBody()->getContents();
			
			$content = file_get_contents($cookieFile);
			$json_data = json_decode($content, true);
			
			$cook_sid=$json_data[0]['Value'];
			$date = new DateTime();
			$Timestamp = $date->getTimestamp();
			log::add('proteo', 'debug', __FUNCTION__ .' sid: '.$cook_sid.' -- '.'challenge: '.$challenge);
			cache::set('proteo' . '_sid' , $cook_sid);
			cache::set('proteo' . '_sid_time' , $Timestamp);
			//echo '</p>-file-contents : '.$content;
			//echo '</p>-Value : '.$json_data[0]['Value'];
				
		}
		
		//return $cook_sid;
		return $client;
		
		
	}	
/////////////////////////////////////*********************/////////////////////////////////////
    public static function htmlRqst($method=null){ 
		$client = self::getClient();
		$authToken = cache::bykey('proteo' . '_token_auth')->getValue();
		$ipBox = config::byKey('ipBox', 'proteo');
		$url = 'http://' . $ipBox . '/state/lan';
		$params=array();
		$params['sid']= $authToken;//$_sid;
					
		$reponse = self::simpleRqst($url, $params);
			//log::add('proteo', 'debug', __FUNCTION__ .' testcurl: '.$reponse['status'].'--'.$reponse['curlrsp']);
		
		$StatClients=BoxHelper::_getTableDataAsArray($reponse['curlrsp'], '//table[@class="wlanhost_stats"]');//pcports_stats
		//log::add('proteo', 'debug', __FUNCTION__ .' StatClients: '.json_encode($StatClients));		
		//$StatClients=BoxHelper::tojson($testcurl['curlrsp']);
		//$StatClients2=BoxHelper::_getTableDataAsArrayWithHeaders($reponse['curlrsp'], '//table[@class="pcports_stats"]');//pcports_stats
		return $StatClients;
		
		
	}	
/////////////////////////////////////*********************/////////////////////////////////////
	public static function guzRqst($method=null){ 
		$authToken = cache::bykey('proteo' . '_token_auth')->getValue();
		$challenge = cache::bykey('proteo' . '_challenge')->getValue();
		$_sid = cache::bykey('proteo' . '_sid')->getValue();
		
		
		$filename = 'cookie_sfr';
		$cookieJar = jeedom::getTmpFolder('proteo').'/'.$filename;
		//$cookieJar = new FileCookieJar($cookieFile, TRUE);
		$ip = config::byKey('ipBox', 'proteo');
		$boxUrl = 'http://' . $ip;
		//Step 1 Get sid cookie*******************************//
		/////////////////////////////////////////
		self::httpLogin();
		
		$clientg = new Client([ 
			'base_uri' => $boxUrl,
			//'cookies' => $cookf,
		]);
		
		//Step 2 Get rqst*******************************//
		/////////////////////////////////////////
		
		$login = config::byKey('proteoLogin', 'proteo');
		$password = config::byKey('proteoPassword', 'proteo');
		$headers = array(
								'Referer' => 'http://192.168.1.1/index',
								 );
		$body = array(
				'zsid' => $_sid,
				'cookies' => $_sid,
				);
		
		
		$response2 = $clientg->request('GET', '/state/lan', [
														'query' => ['sid' => $authToken],
							   ]);
		
		if($response2->getStatusCode() != 200){
				//throw new Exception(__('Request Erreur : '.$response->getStatusCode(), __FILE__) );
		}else{
			$return2 = $response2->getBody()->getContents();
			log::add('proteo', 'debug', __FUNCTION__ .' return2: '.$return2);
			$content = file_get_contents($cookieFile);
		list($rawHeaders, $body) = explode("\r\n\r\n", $return2, 2);
		//$internet_status=BoxHelper::_getStatusFromNodeCss($return2, '//td[@id="internet_status"]');
		//log::add('proteo', 'debug', __FUNCTION__ .' internet_status: '.$internet_status);
		
		}
		
		
		
	}

/////////////////////////////////////*********************/////////////////////////////////////
    //AUTHORIZATION=======================================================
    public $error = null;
    //public $_token = null;

    protected $_proteo_user;
    protected $_proteo_pass;
    
    protected $_cookFile = '';
    const CLASS_VERSION = '0.1.2';



////
	
	
	public static function getFullReport() {
	    $report = array();
        $myMethods = get_class_methods($this);
        $excludedMethods = array('getHost', 'getFullReport', 'getStatusAsString');
        sort($myMethods);
        
        foreach($myMethods as $methodName) {
            if (substr($methodName, 0, 3) == 'get' && !in_array($methodName, $excludedMethods)) {
                $key = self::_uncamelize(substr($methodName, 3));
                $report[$key] = call_user_func(array($this, $methodName));
            }
        }
	
		return $report;
	}
	
    
} //proteoAPI end

class BoxHelper {
	///////////////////////////////////////////////////////////////////////
	//			HELPERS
	///////////////////////////////////////////////////////////////////////////
	
/////////////////////////////////////*********************///////////////////////////////////// 
	public static function _isValidXML($xml) {
		$doc = @simplexml_load_string($xml);
		if ($doc) {
			return true; //this is valid
		} else {
			return false; //this is not valid
		}
    
    }

/////////////////////////////////////*********************///////////////////////////////////// 
	public static function xmlToArray($xml, $options = array()) {
		
		
		//log::add('proteo','debug', __FUNCTION__ .' xml: '.$xml);
		
		$defaults = array(
			'namespaceSeparator' => ':',//you may want this to be something other than a colon
			'attributePrefix' => '',   //to distinguish between attributes and nodes with the same name
			'alwaysArray' => array(),   //array of xml tag names which should always become arrays
			'autoArray' => true,        //only create arrays for tags which appear more than once
			'textContent' => '$',       //key used for the text content of elements
			'autoText' => true,         //skip textContent key if node has no attributes or child nodes
			'keySearch' => false,       //optional search and replace on tag and attribute names
			'keyReplace' => false       //replace values for above search values (as passed to str_replace())
		);
		$options = array_merge($defaults, $options);
		
		if(!is_object($xml)){
			log::add('proteo', 'error', __FUNCTION__ .' invalid xml "' . gettype($xml) );
			return;
		}
		$namespaces = $xml->getDocNamespaces();
		$namespaces[''] = null; //add base (empty) namespace
	 
		//get attributes from all namespaces
		$attributesArray = array();
		foreach ($namespaces as $prefix => $namespace) {
			foreach ($xml->attributes($namespace) as $attributeName => $attribute) {
				//replace characters in attribute name
				if ($options['keySearch']) $attributeName =
						str_replace($options['keySearch'], $options['keyReplace'], $attributeName);
				$attributeKey = $options['attributePrefix']
						. ($prefix ? $prefix . $options['namespaceSeparator'] : '')
						. $attributeName;
				$attributesArray[$attributeKey] = (string)$attribute;
			}
		}
	 
		//get child nodes from all namespaces
		$tagsArray = array();
		foreach ($namespaces as $prefix => $namespace) {
			foreach ($xml->children($namespace) as $childXml) {
				//recurse into child nodes
				$childArray = self::xmlToArray($childXml, $options);
				//log::add('proteo', 'debug', __FUNCTION__ .' childArray "' . json_encode($childArray) );
				foreach ($childArray as $key => $value) {
					list($childTagName, $childProperties) = array($key , $value);
				}//replace characters in tag name
				if ($options['keySearch']) $childTagName =
						str_replace($options['keySearch'], $options['keyReplace'], $childTagName);
				//add namespace prefix, if any
				if ($prefix) $childTagName = $prefix . $options['namespaceSeparator'] . $childTagName;
	 
				if (!isset($tagsArray[$childTagName])) {
					//only entry with this key
					//test if tags of this type should always be arrays, no matter the element count
					$tagsArray[$childTagName] =
							in_array($childTagName, $options['alwaysArray']) || !$options['autoArray']
							? array($childProperties) : $childProperties;
				} elseif (
					is_array($tagsArray[$childTagName]) && array_keys($tagsArray[$childTagName])
					=== range(0, count($tagsArray[$childTagName]) - 1)
				) {
					//key already exists and is integer indexed array
					$tagsArray[$childTagName][] = $childProperties;
				} else {
					//key exists so convert to integer indexed array with previous value in position 0
					$tagsArray[$childTagName] = array($tagsArray[$childTagName], $childProperties);
				}
			}
		}
	 
		//get text content of node
		$textContentArray = array();
		$plainText = trim((string)$xml);
		if ($plainText !== '') $textContentArray[$options['textContent']] = $plainText;
	 
		//stick it all together
		$propertiesArray = !$options['autoText'] || $attributesArray || $tagsArray || ($plainText === '')
				? array_merge($attributesArray, $tagsArray, $textContentArray) : $plainText;
	 
		//return node as array
		return array(
			$xml->getName() => $propertiesArray
		);
	}

/////////////////////////////////////*********************///////////////////////////////////// 
	public static function extractTagValue($tag, $xmlstring){ 
		$array_resp=array();
		$listzone='';
		$doc = new DOMDocument;
		$doc->loadXML($xmlstring);
		
		if(is_array($tag)){
			foreach ($tag as $key) {
			$node = $doc->getElementsByTagName($key); 
				for($c = 0; $c<$node->length; $c++){ 
					foreach ($node as $tagvalue) {
						$value= $tagvalue->nodeValue; PHP_EOL;
					}
				$tagsarray=array($key=>$value);
				$listzone=$value[$c] .'|'.$listzone;
				} 
				$array_resp=array_merge($array_resp, $tagsarray);
			}
			return $array_resp;
			
			} 
		else{
			$nodes = $doc->getElementsByTagName($tag);
			if($nodes->length>1){
				foreach ($nodes as $tagvalue) {
					$value= $tagvalue->nodeValue;
					$tagsarray=array($value);
					$array_resp=array_merge($array_resp,$tagsarray);
				} 
				return $array_resp;
			}			
			else{
				foreach ($nodes as $tagvalue) {
					$value= $tagvalue->nodeValue;
				}
				return $value;
			}	
		}
	} 

/////////////////////////////////////*********************///////////////////////////////////// 
	function _getFormValues($html, $xpath) {
		$dom = self::_htmlToDOMXPath($html);
		$inputNodes = $dom->query($xpath . '//input | ' . $xpath . '//select');
		
		$formData = array();
		foreach($inputNodes as $inputNode) {
			$attributes = $inputNode->attributes;
			if ($inputNode->nodeName == 'input') {
				switch($attributes->getNamedItem('type')->nodeValue) {
					case 'radio':
						if ($attributes->getNamedItem('checked') && $attributes->getNamedItem('checked')->nodeValue == 'checked') {
							$formData[$attributes->getNamedItem('name')->nodeValue] = $attributes->getNamedItem('value')->nodeValue;
						}
						break;
						
					default:
						$formData[$attributes->getNamedItem('name')->nodeValue] = $attributes->getNamedItem('value') ? $attributes->getNamedItem('value')->nodeValue : '';
						break;
				}
			}
			elseif($inputNode->nodeName == 'select') {
				$optionNodes = $inputNode->getElementsByTagName('option');
				foreach($optionNodes as $optionNode) {
					if ($optionNode->attributes->getNamedItem('selected') && $optionNode->attributes->getNamedItem('selected')->nodeValue == 'selected') {
						$formData[$attributes->getNamedItem('name')->nodeValue] = $optionNode->attributes->getNamedItem('value')->nodeValue;
					}
				}
			}
		}
		return $formData;
	}

/////////////////////////////////////*********************///////////////////////////////////// 	
	function _htmlToDOMXPath($html, $encoding = 'iso-8859-1') {
		$dom = new DOMDocument('1.0', $encoding);
		@$dom->loadHTML($html);
		$xpathDom = new DOMXPath($dom);
		
		return $xpathDom;
	}

/////////////////////////////////////*********************///////////////////////////////////// 	
	protected static function _trim($text) {
		return trim($text, chr(32) . chr(160));		//32 = space / 160 = non-breakable space
	}

/////////////////////////////////////*********************///////////////////////////////////// 	
	protected static function _normalizeText($text) {
		return self::_trim(preg_replace('/\s+/', ' ', str_replace(array("\n", "\r\n"), '', $text)));
	}

/////////////////////////////////////*********************///////////////////////////////////// 	
	function _uncamelize($string) {
	   return strtolower(preg_replace('/(.)([A-Z])/', '$1_$2', $string));
	}
/////////////////////////////////////*********************///////////////////////////////////// 	
	function _getStatusFromNodeCss($html, $xpath) {
		$dom = self::_htmlToDOMXPath($html);
		$entries = $dom->query($xpath);
		if (null === $entries->item(0)) {
			log::add('proteo', 'debug', __FUNCTION__ .' Cannot find node at XPath "' . $xpath . '"');
		}
		$entry = $entries->item(0);
		
		$status = null;
		switch($entry->attributes->getNamedItem('class')->nodeValue) {
		    case 'enabled':$status = self::STATUS_CONNECTED;
			break;
		    case 'disabled':$status = self::STATUS_NOT_CONNECTED;
			break;
		    case 'unused':$status = self::STATUS_UNUSED;
			break;
		}
		return $status;
	}
/////////////////////////////////////*********************///////////////////////////////////// 	
	function _getTableDataAsArrayold($html, $xpath) {
		$dom = self::_htmlToDOMXPath($html);
		$entries = $dom->query($xpath);
		if (null === $entries->item(0) || $entries->item(0)->nodeName != 'table') {
			log::add('proteo', 'debug', __FUNCTION__ .' Cannot find <table> node at XPath "' . $xpath );
		}
		log::add('proteo', 'debug', __FUNCTION__ .' nodeName0: ' . $entries->item(0)->nodeName. '---'.$entries->item(0)->textContent);
		
		$entry = $entries->item(0);
		log::add('proteo', 'debug', __FUNCTION__ .' nodeValue div: ' . $entry->attributes->getNamedItem('div')->nodeValue . '"');
		
		$data = array();
		foreach($entry->childNodes as $childNode) {
		
		/** $childNode <tr> */
			$label = '';
			$value = '';
			foreach($childNode->childNodes as $node) {
			       log::add('proteo', 'debug', __FUNCTION__ .' node "' . $node->nodeName . '"'.$node->textContent);
		
				if ($node->nodeName == 'th') {
					$label = self::_normalizeText($node->textContent);
				}
				if ($node->nodeName == 'td') {
					$value = self::_normalizeText($node->textContent);
				}
			}
			if ($label && $value) {
				$data[$label] = $value;
			}
		}
		return $data;
	}
/////////////////////////////////////*********************///////////////////////////////////// 	
	function _getTableDataAsArrayWithHeaders($html, $xpath) {
		$dom = self::_htmlToDOMXPath($html);
		$entries = $dom->query($xpath);
		if (null === $entries->item(0) || $entries->item(0)->nodeName != 'table') {
			log::add('proteo', 'debug', __FUNCTION__ .' Cannot find <table> node at XPath "' . $xpath . '"');
		}
		$entry = $entries->item(0);
		
		$data = array();
		
		// Cols
		$cols = array();
		$nodeList = $dom->query($xpath . '/thead/tr/th');
		foreach($nodeList as $node) {
			if ($node->nodeName == 'th') {
				$cols[] = self::_normalizeText($node->textContent);
			}
		}
		
		// Rows
		$rows = array();
		$rowNodeList = $dom->query($xpath . '/tbody/tr');
		$i = 0;
		foreach($rowNodeList as $rowNode) {
			$i++;
			$j = 0;
			foreach($rowNode->childNodes as $cellNode) {
				if ($cellNode->nodeName == 'td') {
					$colName = isset($cols[$j]) ? $cols[$j] : "{Column $j}";
					$j++;
					
					// Normal text node
					if ($value = self::_normalizeText($cellNode->textContent)) {
						$data[$i][$colName] = $value;
					}
					else {
						foreach($cellNode->childNodes as $subCellNode) {
							// Image node: retrieve "alt" attribute as text value
							if ($subCellNode->nodeName == 'img') {
								if ($value = $subCellNode->getAttribute('alt')) {
									$data[$i][$colName] = self::_normalizeText($value);
								}
							}
						}
					}
					
					// Fallback
					if (!isset($data[$i][$colName])) {
						$data[$i][$colName] = '';
					}
				}
			}
		}
		log::add('proteo', 'debug', __FUNCTION__ .' data: '.json_encode($data));
		return $data;
	}
/////////////////////////////////////*********************/////////////////////////////////////
    public static function _getTableDataAsArray($html, $xpath) {
		$dom = new DOMDocument('1.0', 'iso-8859-1');//'UTF-8'
		@$dom->loadHTML($html);
		$dom->normalizeDocument();
		$xpathDom = new DOMXPath($dom);
		
		$entries = $xpathDom->query($xpath);
		if (null === $entries->item(0) || $entries->item(0)->nodeName != 'table') {
			log::add('proteo', 'debug', __FUNCTION__ .' Cannot find <table> node at XPath "' . $xpath );
		}
		$data = array();
		$i=0;
		foreach($entries as $entry) {
		  
			//log::add('proteo', 'debug', __FUNCTION__ .' entry: ' .$entry->nodeName . '"'.$entry->textContent);
		    //$data[$i]='';
		    foreach($entry->childNodes as $childNode) {
				$label = '';
			    $value = '';
			    foreach($childNode->childNodes as $node) {
				  // log::add('proteo', 'debug', __FUNCTION__ .' node2 "' . $node->nodeName . '--text: '.$node->textContent);
					foreach($node->childNodes as $nodechild) {
						if ($nodechild->nodeName == 'th') {
                          	$label =  trim($nodechild->textContent, " \t\n\r\0\x0B");
                        }
						if ($nodechild->nodeName == 'td') {
							$value=html_entity_decode(trim(str_replace(';','-',preg_replace('/\s+/S', " ", strip_tags($nodechild->textContent)))));
						}
					
                    }
					if ($label && $value) {
                      	$data[$i][$label] = $value;
                    }
                }
		    }
		$i++;
		}
		$return=json_encode($data, JSON_UNESCAPED_UNICODE);
		log::add('proteo', 'debug', __FUNCTION__ .' StatClients: '.$return);		
		
		return $return;
	}
	
	
}//fin helper
?>