<?php

class telnet {
	//file handler for socket
	var $fp = NULL;
	function telnet() {
		$this->fp = NULL;
	}

	public function telnetConnect($ip, $port, &$errno, &$errstr) {
		$this->telnetDisconnect();
		$this->fp = fsockopen($ip, $port, $errno, $errstr);
		stream_set_timeout($this->fp,3);

		if(!$this->fp) {
			return false;
		}
		return true;
	}

	public function telnetSendCommand($command,&$response) {
		if ($this->fp) {
			fputs($this->fp,"$command\r");
			usleep(100000);
			$this->telnetReadResponse($response);
		}
		return $this->fp?1:0;
	}

	public function telnetDisconnect() {
		if ($this->fp) {
			$this->telnetSendCommand('exit',$result);
			fclose($this->fp);
			$this->fp=NULL;
		}
	}

	private function telnetReadResponse(&$response) {
		$response='';
		do {
		//	$response.=fread($this->fp,1000);
			$response.=fgets($this->fp,1000);
			$status=socket_get_status($this->fp);
		} while ($status['unread_bytes']);
	}

}

?>
