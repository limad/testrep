<?php

class ampli_pioneer_telnet {
	//file handler for socket
	var $fp = NULL;

	function telnet() {
		$this->fp = NULL;
	}

	public function telnetConnect($ip, $port, &$errno, &$errstr) {
		$this->telnetDisconnect();
		$this->fp = fsockopen($ip, $port, $errno, $errstr);
		if(!$this->fp) {
			return false;
		}
		return true;
	}
	
	public function telnetSendCommand($command,&$response) {
//mon_plantage();
		if ($this->fp) {
			$command=trim($command);
			fputs($this->fp,"$command\r");
			usleep(200000);
			$this->telnetReadResponse($response);
		}
		return $this->fp?1:0;
	}
	
	public function telnetDisconnect() {
		if ($this->fp) {
			$this->telnetSendCommand('exit',$result);
			fclose($this->fp);
			$this->fp=NULL;
		}
	}

	public function telnetGetReadResponse(&$response) {
		$response='';
		do { 
			$response.=fgets($this->fp,1000);
			$status=socket_get_status($this->fp);
		} while ($status['unread_bytes']);
	}

	
	private function telnetReadResponse(&$response) {
		$response='';
		do { 
			$response.=fgets($this->fp,1000);
			$status=socket_get_status($this->fp);
		} while ($status['unread_bytes']);
	}

}

?>