<?php

require_once dirname(__FILE__) . '/../../../core/php/core.inc.php';
include_file('core', 'authentification', 'php');

if (!isConnect()) {
	include_file('desktop', '404', 'php');
	die();

}

?>
<form class="form-horizontal">
    <fieldset>
		<div class="form-group">
            <label class="col-lg-4 control-label">{{Adresse IP Proteo}}</label>
            <div class="col-lg-4">
                <input class="configKey form-control" value="" data-l1key="ipProteo" placeholder="192.168.0.0" autocomplete="off"/>
            </div>
		</div>
		
		 <div class="form-group">
            <label class="col-lg-4 control-label">{{Port}}</label>
            <div class="col-lg-4">
                <input class="configKey form-control" value="" data-l1key="portProteo" placeholder="23" autocomplete="off"/>
                
            </div>
		</div>
  
  		<div class="form-group">
			<label class="col-lg-4 control-label">{{}}</label>
			<div class="col-lg-2">
                <a class="btn btn-success" id="bt_syncProteo" title="">
				<i class='fas fa-refresh' ></i> {{Synchroniser...}}</a>
			</div>
		</div>
	</fieldset>
</form>




		
<script>
	$('#bt_savePluginPanelConfig').on('click',function(){
		if($('.configKey[data-l1key=ipProteo]').val() === ''){
				$('#div_alertPluginConfiguration').showAlert({message: 'IP invalide ! Renseignez l\'IP de la Proteo SVP' , level: 'warning'});
				$('#div_alertPluginConfiguration').removeClass('alert-success');
				$('#div_alertPluginConfiguration').addClass('alert-danger');
				return;
		}
		else if($('.configKey[data-l1key=portProteo]').val() === ''){
				$('#div_alertPluginConfiguration').showAlert({message: 'Le champ Port ne peut être vide !' , level: 'warning'});
				$('#div_alertPluginConfiguration').removeClass('alert-success');
				$('#div_alertPluginConfiguration').addClass('alert-danger');
			return;
		}
		
	
	
	});

	
	$("input[data-l1key='functionality::cron::enable']").on('change',function(){
        if ($(this).is(':checked')) 
			$("input[data-l1key='functionality::cron5::enable']").prop("checked", false)
	 });

    $("input[data-l1key='functionality::cron5::enable']").on('change',function(){
        if ($(this).is(':checked')) 
			$("input[data-l1key='functionality::cron::enable']").prop("checked", false)
    });
	
	
	
	$('#bt_syncProteo').on('click', function (){	
			if($('.configKey[data-l1key=ipProteo]').val() === ''){
				$('#div_alertPluginConfiguration').showAlert({message: 'IP invalide ! Renseignez l\'IP de la box SVP' , level: 'warning'});
				$('#div_alertPluginConfiguration').removeClass('alert-success');
				$('#div_alertPluginConfiguration').addClass('alert-danger');
				return;
			}
			else if($('.configKey[data-l1key=portProteo]').val() === ''){
				$('#div_alertPluginConfiguration').showAlert({message: 'Le champ Identifiant ne peut être vide !' , level: 'warning'});
				$('#div_alertPluginConfiguration').removeClass('alert-success');
				$('#div_alertPluginConfiguration').addClass('alert-danger');
				return;
			}
			
			else{
				$('#div_alertPluginConfiguration').removeClass('alert-success');
              	$('#div_alertPluginConfiguration').removeClass('alert-danger');
              	$('#div_alert').empty();
				savePluginConfig();
				$.ajax({
					type: "POST",
						url: "plugins/proteo/core/ajax/proteo.ajax.php",
						data: { action: "syncData",},
						dataType: 'json',
						error: function (request, status, error) {
							handleAjaxError(request, status, error);
						},
						success: function (data) {
							if (data.state != 'ok') {//erreur api
								if (data.result != 'bad request') {
									$('#div_alert').showAlert({message: '{{Echec de la tentative de connexion: }}' + data.result, level: 'danger'});
									$('#div_alertPluginConfiguration').append('<br>Echec de connexion. Vérifier que les informations saisies sont correctes. Msg: ' + data.result);
									$('#div_alertPluginConfiguration').removeClass('alert-success');
									$('#div_alertPluginConfiguration').addClass('alert-danger');
								}else{ //pas de reponse api
									$('#div_alert').showAlert({message: '{{Echec de la tentative de connexion: }}' + data.result , level: 'danger'});
									$('#div_alertPluginConfiguration').append('<br>Echec de connexion. Vérifier la connectivité internet. No response' );
									$('#div_alertPluginConfiguration').removeClass('alert-success');
									$('#div_alertPluginConfiguration').addClass('alert-danger');

								}
								return;
							}
							//$('#div_alertPluginConfiguration').append('<br>Bravo!.. Synchronisation réussie');
							$('#div_alertPluginConfiguration').append('<br>Bravo!.. Synchronisation '  + ' - ' + data.result);//+ data.state
							$('#div_alert').showAlert({message: 'Actualiser la page ! (F5)', level: 'success'});
							//$('#ul_plugin .li_plugin[data-plugin_id=proteo]').click();
						}
				});
			}
	});
	
	

</script>