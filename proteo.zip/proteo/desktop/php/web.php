 <?php
 if (!class_exists('proteoAPI')) {
    require_once dirname(__FILE__) . '/../../../proteo/3rdparty/proteoAPI.php';
}

$ipbox = config::byKey('ipBox', 'proteo');
$eqLogics = proteo::byType('proteo');

        foreach ($eqLogics as $eqLogic) {
			if(!is_null( $eqLogic->getConfiguration('ip')))
				$ip = $eqLogic->getConfiguration('ip');
				//$id = $eqLogic->getID();
				$name = $eqLogic->getName();
				//$status = $eqLogic->getCmd('info', 'name');
				$cmd = $eqLogic->getCmd('info', 'lastCallRead');
				//$status = $status->execCmd();
				//$status = $cmd->getValue();
				
				//$testIp = proteoAPI::testIp($ip);
				//$ping = $eqLogic->ping();
				//$ping = proteoAPI::pingExec($ip,'arp');
				//$ping = proteoAPI::pingExec($ip);
				//$ping = proteoAPI::pingPort($ip,80,1);
				
				//$ping = proteoAPI::getarp($ip);
				echo '<br><b>'.$name.'</b>: '.$status;
				
				//$ttl=1;
				//$exec_string = 'sudo ping -n -c 1 -t 10 '.$ip;
				//$ping = exec($exec_string, $output, $return);
				/*if(filter_var($ip, FILTER_VALIDATE_IP)){ 
					//$ping = exec('sudo ping -n -c 1 -t 10 '.$ip, $output, $return);
					$ping = proteoAPI::pingExec($ip);
					echo '<br><b>	'.$name.'</b> return: '.$ping;
				}else{
					echo '<br><b>	'.$name.'</b> invalide Ip ';
				}*/
				//$arp=`sudo ping -n -c 1 -t 64 $ip`;
				//echo '<p><b>'.$name.': </b>'.$arp;
        }

//$arp=`sudo ping -n -c 1 -t 64 192.168.1.22`;
//echo '</p><b>arp: </b>'.$arp;
//$ping = exec('sudo ping -n -c 1 -t 64 '.$ip, $output, $return);
//echo '</p><b>ping: </b>'.json_encode($output);



/*
$arcook=array(
		    "Name"=>"sid","Value"=>"f965756ea77a44f13b81d37f96a094","Domain"=>"192.168.1.1","Path"=>"\/","Max-Age"=>null,
		    "Expires"=>null,"Secure"=>false,"Discard"=>false,"HttpOnly"=>false
		);
		$cookf[]=json_encode($arcook,true);
		
		
$content = file_get_contents($cookf);
			$json_data = json_decode($cookf, true);
			
			$cook_sid=$json_data[0]['Value'];
			echo '<br><b>	cook_sid'.$cook_sid.'</b> ';
*/
