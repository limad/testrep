<?php
if (!isConnect('admin')) {
	throw new Exception('{{401 - Accès non autorisé}}');
}
$plugin = plugin::byId('proteo');
sendVarToJS('eqType', $plugin->getId());
$eqLogics = eqLogic::byType($plugin->getId());
$eqname=$plugin->getName();

?>

<style>
  #table_cmdi tr:hover{background-color: #9e9a9a;}
  #table_cmda tr:hover{background-color: #9e9a9a;}
  #table_cmdi tr:nth-child(even){background-color: #background-color#;}
</style>
<!--
*#table_cmdi tr:nth-child(even){background-color: #background-color#;}
-->

<div class="row row-overflow">
	<div class="col-xs-12 eqLogicThumbnailDisplay">
		<legend>{{Gestion}}</legend>
		<div class="eqLogicThumbnailContainer">
			<div class="cursor eqLogicAction logoPrimary" data-action="add">
				<i class="fas fa-plus-circle"></i>
				<br/>
				<span >{{Ajouter}}</span>
			</div>
  			<div class="cursor eqLogicAction logoDefault" data-action="gotoPluginConf">
				<i class="fas fa-wrench"></i>
				<br/>
				<span>{{Configuration}}</span>
			</div>
				
			<div class="cursor eqLogicAction logoDefault" data-action="removeAll" id="bt_removeAll">
				<i class="fas fa-minus-circle" style="color: #FA5858;"></i>
				<br/>
				<span>{{Supprimer tous}}</span>
			</div>
			
			        
          
			<div class="cursor" id="bt_healthproteo" data-action="gotoPluginConf">
				<i class="fas fa-medkit"></i>
				<br/>
				<span>{{Santé}}</span>
			</div>
		</div>
		
		<legend><i class="fas fa-table"></i> {{Equipements Proteo}}</legend>
		<div class="eqLogicThumbnailContainer">
			<?php
			if (count($eqLogics) == 0) {
				echo "<br/><br/><br/><center><span style='color:#767676;font-size:1.2em;font-weight: bold;'>{{Vous n'avez pas de Proteo configuré, aller sur Configuration et cliquez sur synchroniser pour commencer}}</span></center>";
			} 
			else {
				foreach ($eqLogics as $eqLogic) {
					$type=$eqLogic->getConfiguration('type');
					$opacity = ($eqLogic->getIsEnable()) ? '' : 'disableCard';
					if ($type != 'lan' && $type != 'wifi') {//box
						if ($eqLogic->getIsEnable() != 1) {
						}
						echo '<div class="eqLogicDisplayCard cursor '.$opacity.'" data-eqLogic_id="' . $eqLogic->getId() . '">';
							echo '<img src="plugins/proteo/core/img/' . $eqLogic->getConfiguration('type', '') . '.png" style="width: 75px; height: 75px;" />';
							echo '<br/>';
							echo '<span class="name">' . $eqLogic->getHumanName(true, true) . '</span>';
						echo '</div>';
					}
				}
              echo '</div>';
				
              echo '<legend><i class="fas fa-table"></i> {{Equipements connectés à la Box}} </legend>';
				echo '<input class="form-control" placeholder="{{Rechercher}}" id="in_searchEqlogic" />';
				echo '<div class="eqLogicThumbnailContainer">';

				foreach ($eqLogics as $eqLogic) {
					$type=$eqLogic->getConfiguration('type');
					$opacity = ($eqLogic->getIsEnable()) ? '' : 'disableCard';
					if ($type === 'lan' || $type === 'wifi') {
						echo '<div class="eqLogicDisplayCard cursor '.$opacity.'" data-eqLogic_id="' . $eqLogic->getId() . '">';
							echo '<img src="plugins/proteo/core/img/' . $eqLogic->getConfiguration('type', '') . '.png" />';
							echo '<br/>';
							echo '<span class="name">' . $eqLogic->getHumanName(true, true) . '</span>';
						echo '</div>';
					}
				}
				echo '</div>';
			}
			
			
	?>	
		
	
	</div>
	
	<div class="col-xs-12 eqLogic" style="display: none;">
			<div class="input-group pull-right" style="display:inline-flex">
				<span class="input-group-btn">
      				<a class="btn btn-default pull-right btn-sm" id="bt_eqConfigRaw"><i class="fas fa-info"></i> </a>
					<a class="btn btn-default eqLogicAction btn-sm roundedLeft" data-action="configure"><i class="fas fa-cogs"></i> Configuration avancée</a><a class="btn btn-sm btn-success eqLogicAction" data-action="save"><i class="fas fa-check-circle"></i> Sauvegarder</a><a class="btn btn-danger btn-sm eqLogicAction roundedRight" data-action="remove"><i class="fas fa-minus-circle"></i> Supprimer</a>
				</span>
			</div>
			
			
			<ul class="nav nav-tabs" role="tablist">
			<li role="presentation"><a class="eqLogicAction cursor" aria-controls="home" role="tab" data-action="returnToThumbnailDisplay" style="padding:10px 5px !important"><i class="fa fa-arrow-circle-left"></i></a></li>
			
			<li role="presentation" class="active"><a href="#eqlogictab" aria-controls="home" role="tab" data-toggle="tab" style="padding:10px 5px !important"><i class="fas fa-tachometer-alt"></i> {{Equipement}}</a></li>
			<li role="presentation"><a href="#commandtab" data-toggle="tab" style="padding:10px 5px !important"><i class="fa fa-list-alt" aria-hidden="true"></i> {{Commandes}}</a></li>
			<!--<li  role="presentation"><a href="#configureAdvanced" data-toggle="tab" style="padding:10px 5px !important"><i class="fa fa-cog" aria-hidden="true"></i> {{Avancée}}</a></li>
			-->
		   

		</ul>
		<div class="tab-content">
				<!-- *********** eqlogictab  ****-->
				<div class="tab-pane active" id="eqlogictab">
					<br/>
					<legend><i class="fas fa-tachometer-alt"></i> {{Général}}</legend>
					<div class="row">
						
      
      
      					<div class="col-lg-8"><!--infos-->
							<form class="form-horizontal">
								<fieldset>
									<div class="form-group">
										<label class="col-lg-3 control-label" style="top: 6px; ">{{Nom de l'équipement}}</label>
										<div class="col-lg-4">
											<input type="text" class="eqLogicAttr form-control" data-l1key="id" style="display : none;  " />
											<input type="text" class="eqLogicAttr form-control" data-l1key="name" placeholder="{{Nom du thermostat}}" style="top: 15px; "/>
										</div>
									</div>
									<div class="form-group">
										<label class="col-lg-3 control-label" style="top: 6px; ">{{Objet parent}}</label>
										<div class="col-lg-4">
											<select id="sel_object" class="eqLogicAttr form-control" data-l1key="object_id">
												<option value="">{{Aucun}}</option>
												<?php
												foreach (jeeObject::all() as $object) {
													echo '<option value="' . $object->getId() . '">' . $object->getName() . '</option>';
												}
												?>
											</select>
										</div>
									</div>
                                    
                                    
                                  <div class="form-group">
										<label class="col-lg-3 control-label" style="top: 6px; ">{{Catégorie}}</label>
										<div class="col-lg-8">
                        <?php
                        foreach (jeedom::getConfiguration('eqLogic:category') as $key => $value) {
                          echo '<label class="checkbox-inline">';
                          echo '<input type="checkbox" class="eqLogicAttr" data-l1key="category" data-l2key="' . $key . '" />' . $value['name'];
                          echo '</label>';
                        }
                        ?>
										</div>
									</div>
                                    
                                    
									<div class="form-group">
										<label class="col-lg-3 control-label"></label>
										<div class="col-lg-4">
											<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="isEnable" checked/>{{Activer}}</label>
											<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="isVisible" checked/>{{Visible}}</label>
										</div>
									</div>
								</fieldset>
							</form>
							<br>
							<!-- Informations  --> 
							<legend><i class="fas fa-info" aria-hidden="true"></i> {{Options}}</legend>
							<form class="form-horizontal">
								<fieldset>
									
									
									
										<div class="form-group" id="div_showall" style="display: none;">
											<label class="col-lg-3 control-label">{{Afficher les équipements ?}}</label>
												<div class="col-lg-7">
													<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="configuration" data-l2key="showall" checked />{{Lier les équipements connectés à la box}}</label>
												</div>
										</div> 
													<!--*******************************  --> 
										<div class="form-group">
											<label class="col-lg-3 control-label" >{{Affichage sur Dashboard}} 
												<sup><i class="fas fa-question-circle tooltipstered" tooltip="Cocher les informations à afficher sur la tuile"></i></sup>
											</label>	
												<div class="col-lg-7">
													
													<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="configuration" data-l2key="displayIp" checked />{{IP}}</label> 
													<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="configuration" data-l2key="displayMac" />{{MAC}}</label> 
													<!--<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="configuration" data-l2key="displayHostname" />{{Hostname}}</label> 
													-->
													<label class="checkbox-inline"><input type="checkbox" class="eqLogicAttr" data-l1key="configuration" data-l2key="displayTimer" checked />{{Keepalive timer}}</label>
							
												</div>
										</div>   
										
					
									
									
									
									
									
								</fieldset>
							</form>
					
					
					 
						</div>
						
                        
                        
                        
                        
                        
                        
						<div class="col-lg-2"><!--img-->
							<center>
								<span class="eqLogicAttr" data-l1key="configuration" data-l2key="type" style="display:none;"></span>
								<img src="<?php echo $plugin->getPathImgIcon();?>" id="img_typeModel" style="height : 250px" />
							</center>
						</div>
					</div>
					<!--row-->
				
						
					
					
					
					
						
				<!--Configuration durées par défaut-->
					<form class="form-horizontal">
						<fieldset>
							<legend><i class="fas fa-calendar" aria-hidden="true"></i> {{Informations}}</legend>
							<form class="form-horizontal">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="col-lg-4 control-label" style="top: 6px; ">{{Ip}}</label>
										<div class="col-lg-4">
											<input disabled class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="ip" id="ip"/>
										</div>
								</div> 
                                <div class="form-group">
									<label class="col-lg-4 control-label" style="top: 6px; ">{{Port}}</label>
										<div class="col-lg-4">
											<input disabled class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="port" id="port"/>
										</div>
								</div> 
                                 
											<!--*******************************  --> 
								  
											<!--*******************************  -->  
								<div class="form-group" id="div_nbscan" style="display: none;">
									<label class="col-lg-4 control-label" style="top: 6px; ">{{Nombre d'équipement scanés}}</label>
										<div class="col-lg-6">
											<input disabled class="eqLogicAttr form-control" data-l1key="configuration" data-l2key="nbEqScan" id="nbEqScan"/>
										</div>
								</div> 
							</div>
							<div class="col-lg-6"></div>
								

							
							</form>
						</fieldset>
					</form>
					
					<br>
					<form class="form-horizontal">
						<fieldset>
							<legend><i class="fas fa-wrench" aria-hidden="true"></i> {{Configuration autres...}}</legend>
							<div class="col-lg-6"></div>
						
							<div class="col-lg-6"></div>
						</fieldset>
					</form>
				</div>
				<!-- *********** commandtab  ****-->
				<div class="tab-pane" id="commandtab">
					<style>
					
					</style>
					
					<legend>
						<center class="title_cmdtable">{{Tableau de commandes <?php echo ' - '.$eqname.': ';?>}}
							<span class="eqName"></span>
						</center>
					</legend>
					
					<legend><i class="fas fa-info-circle"></i>  {{Infos}}</legend>
						<table id="table_cmdi" class="table table-bordered table-condensed tablesorter">
								<!--<table class="table  tablesorter tablesorter-bootstrap tablesorter6b93e3c58137c hasResizable table-striped hasFilters" id="table_update" style="margin-top: 5px;" role="grid"><colgroup class="tablesorter-colgroup"></colgroup>
								</table>-->
								<thead>
									<tr>
										<th style="width: 40px;">Id</th>
										<th style="width: 280px;">{{Nom}}</th>
										<th style="width: 100px;">{{Type}}</th>
										<th style="width: 220px;">{{Options}}</th>
										<th style="width: 80px;">{{Action}}</th>
										 
									</tr>
								</thead>
								<tbody></tbody>
						</table>

							<legend><i class="fas fa-list-alt"></i>  {{Actions}}</legend>
							<table id="table_cmda" class="table tablesorter table-bordered table-condensed">
								
								<thead>
									<tr>
										<th style="width: 40px;">Id</th>
										<th style="width: 280px;">{{Nom}}</th>
										<th style="width: 100px;">{{Type}}</th>
										<th style="width: 220px;">{{Options}}</th>
										<th style="width: 80px;">{{Action}}</th>
										 
									</tr>
								</thead>
								<tbody></tbody>
							</table>

					
				</div>
				<!-- *********** configureAdvanced  ****-->
				
				
				<div class="tab-pane" id="configurePlanning">
					<form class="form-horizontal">
						<fieldset>
							<br/><br/>
							
							
						</fieldset>
					</form>
				</div>
					
			</div>
			<!-- *********** div class="tab-content" ****-->
	</div>

</div>

<?php include_file('desktop', 'proteo', 'js', 'proteo');?>
<?php include_file('core', 'plugin.template', 'js');?>