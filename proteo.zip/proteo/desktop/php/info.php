<?php
error_reporting(E_ALL);
//foreach (ini_get_all(null, false) as $key => $value) echo "$key : $value<br>";
$ar1 = array();
$ar2 = array('1','2','3');
$ar3 = array('1'=>'E','2','3');

$time = date('d-m-Y H:i');
$ar1[0] = $time;
echo '<p> ar1 count: '.count($ar1);
echo '<p> ar2 count: '.count($ar2);
echo '<p> ar3 count: '.count($ar3);
echo '<p> ar3 count COUNT_RECURSIVE: '.count($ar3, COUNT_RECURSIVE);
//COUNT_RECURSIVE
