
<?php error_reporting(E_ALL);
$url = 'http://192.168.1.43:23';
//create a new cURL resource
//setup request to send json via POST

//$payload0 = json_encode(array("1234567" => array("msgId":5;)));
$payload='{"1234567":{"msgId":5, "read":["status","about"]}}';

echo '<p>';

include_file('core', 'plugin.template', 'js');




/* Autorise l'exécution infinie du script, en attente de connexion. */
//set_time_limit(0);

/* Active le vidage implicite des buffers de sortie, pour que nous
 * puissions voir ce que nous lisons au fur et à mesure. */
//ob_implicit_flush();

$address = '192.168.1.43';
$port = '23';



$host = $address;
        //log::add('dspsmartplug', 'debug', '		********* '. __FUNCTION__ .' started ********* @IP: '.$host);

        $fsock = fsockopen($host, $port, $errno, $errstr, 10   );
       // echo 'fgets: '.fgets($fsock).'<p>';

//fputs($fsock,$payload);
 //     $result=fread($fsock,1024);

//echo  'nl2br: '. nl2br($result).'<p>';


if (! $fsock ) {
            fclose($fsock);
            //log::add('dspsmartplug', 'error','@IP : '. $host.' est injoignable' );
           echo 'error','@IP : '. $host.' est injoignable'.'<p>';
            throw new Exception(__('Communication error check @IP ',__FILE__));
		}else{
			fwrite($fsock, $payload);
  			$response .= fgets($fsock, 1160);
 echo  'response: '. $response.'<p>';


  //fputs($fsock, $payload);
	// $buffer=fgets($fsock, 4096);
 //  echo  'buffer: '. $buffer.'<p>';


$buffer = "";

while(!feof($fsock))
{
    $buffer .=fgets($fsock, 4096);
}

print_r($buffer);
echo "<br /><br /><br />";
var_dump($buffer);
//log::add('dspsmartplug', 'debug', '		********* '. 'IP: '.$host.' Connected ********* ');
			echo '		********* '. 'IP: '.$host.' Connected ********* '.'<p>';
		}
        fclose($fsock);

$fp = stream_socket_client("tcp://192.168.1.43:23", $errno, $errstr, 30);
if (!$fp) {
    echo "$errstr ($errno)<br />\n";
} else {
    fwrite($fp, $payload);
    while (!feof($fp)) {
        echo fgets($fp, 1024);
    }
    fclose($fp);
}

////////////////////////