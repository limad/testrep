
/* This file is part of Jeedom.
*
* Jeedom is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Jeedom is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
*/
$('#typeEq').change(function(){
});
/////////////////////////////////
//Commandes:
function addCmdToTable(_cmd) {
    if (!isset(_cmd)) var _cmd = {configuration: {}}
    if (!isset(_cmd.configuration)) _cmd.configuration = {}
    var tr = '<tr class="cmd" data-cmd_id="' + init(_cmd.id) + '">'
        tr += '<td>'
        tr += '<input class="cmdAttr form-control input-sm" data-l1key="id" style="display : none">'
        tr += '<input class="cmdAttr form-control input-sm" data-l1key="type" style="display : none">'
        tr += '<input class="cmdAttr form-control input-sm" data-l1key="subType" style="display : none">'
        tr += '<input class="cmdAttr form-control input-sm" data-l1key="name" style="width : 60%" placeholder="{{Nom}}"></td>'
        tr += '<input class="cmdAttr form-control type input-sm" data-l1key="type" value="info" disabled style="display : none" />'

        tr += '</td>'

        tr += '<td>'
        if (_cmd.subType == "numeric" || _cmd.subType == "binary") {
            tr += '<span><label class="checkbox-inline"><input type="checkbox" class="cmdAttr checkbox-inline" data-l1key="isHistorized"/>{{Historiser}}</label></span> '
        }
        tr += '</td>'

        tr += '<td>'
        if (is_numeric(_cmd.id))
        {
            tr += '<a class="btn btn-default btn-xs cmdAction expertModeVisible" data-action="configure"><i class="fa fa-cogs"></i></a> '
            tr += '<a class="btn btn-default btn-xs cmdAction" data-action="test"><i class="fa fa-rss"></i> {{Tester}}</a>'
        }
        tr += '</td>'
    tr += '</tr>'

    if (_cmd.type == 'info')
    {
        $('#table_infos tbody').append(tr)
        $('#table_infos tbody tr:last').setValues(_cmd, '.cmdAttr')
        if (isset(_cmd.type)) $('#table_infos tbody tr:last .cmdAttr[data-l1key=type]').value(init(_cmd.type))
        jeedom.cmd.changeType($('#table_infos tbody tr:last'), init(_cmd.subType))
    }
    else
    {
        $('#table_actions tbody').append(tr)
        $('#table_actions tbody tr:last').setValues(_cmd, '.cmdAttr')
        if (isset(_cmd.type)) $('#table_actions tbody tr:last .cmdAttr[data-l1key=type]').value(init(_cmd.type))
        jeedom.cmd.changeType($('#table_actions tbody tr:last'), init(_cmd.subType))
    }
    if (_cmd.name == 'SetProgram') _setProgramId_ = _cmd.id
}


$(".eqLogic").delegate(".listCmdInfo", 'click', function () {
    var el = $(this).closest('.form-group').find('.eqLogicAttr');
    jeedom.cmd.getSelectModal({cmd: {type: 'info'}}, function (result) {
        if (el.attr('data-concat') == 1) {
            el.atCaret('insert', result.human);
        } else {
            el.value(result.human);
        }
    });
});
///////////////////////////////////
 $("body").delegate(".listCmdAction", 'click', function () {
	console.log(".listCmdAction")
    var type = $(this).attr('data-type');
    var el = $(this).closest('.' + type).find('.expressionAttr[data-l1key=cmd]');
    jeedom.cmd.getSelectModal({cmd: {type: 'action'}}, function (result) {
        el.value(result.human);
        jeedom.cmd.displayActionOption(el.value(), '', function (html) {
            el.closest('.' + type).find('.actionOptions').html(html);
        });

    });
});

///////////////////////////////////



$('#bt_cronGenerator').on('click',function(){
   jeedom.getCronSelectModal({},function (result) {
       $('.eqLogicAttr[data-l1key=configuration][data-l2key=autorefresh]').value(result.value);
   });
});

$('.eqLogicAttr[data-l1key=configuration][data-l2key=type]').on('change',function(){
    $('#img_typeModel').attr('src','plugins/proteo/core/img/'+$(this).value()+'.png');
    $(".eqName").empty().append($('.eqLogicAttr[data-l1key=name]').value());
   
	if ($(this).value() != 'box') {
		
		$('#div_showall').hide();
		$('#div_nbscan').hide();
		
		
	} else {
		$('#div_showall').show();
		$('#div_nbscan').show();
		
	}
});


//$("#table_cmdi").sortable({axis: "y", cursor: "move", items: ".cmd", placeholder: "ui-state-highlight", tolerance: "intersect", forcePlaceholderSize: true});
/*--------------- */
//$("#table_cmda").sortable({axis: "y", cursor: "move", items: ".cmd", placeholder: "ui-state-highlight", tolerance: "intersect", forcePlaceholderSize: true});

 
 
 
$('#bt_healthproteo').on('click', function () {
    $('#md_modal').dialog({title: "{{Santé proteo}}"});
    $('#md_modal').load('index.php?v=d&plugin=proteo&modal=health').dialog('open');
});

$('#bt_testproteo').on('click', function () {
	$('#md_modal').dialog({title: "{{Panel test}}"});
	$('#md_modal').load('../../plugins/proteo/desktop/php/panel.php').dialog('open');
});

$('#bt_removeAll').on('click', function () {
	 console.log('init removeAll action');
	 bootbox.confirm('{{Etes-vous sûr de vouloir supprimer tous les équipements ?}}', function (result) {
	        if (result) {
	            $.ajax({
	                type: "POST", // méthode de transmission des données au fichier php
	                url: "plugins/proteo/core/ajax/proteo.ajax.php", 
	                data: {
	                    action: "removeAll",
	                    id: $('.eqLogicAttr[data-l1key=id]').value()
	                },
	                dataType: 'json',
	                global: false,
	                error: function (request, status, error) {
	                    handleAjaxError(request, status, error);
	                },
	                success: function (data) { 
	                    if (data.state != 'ok') {
	                        $('#div_alert').showAlert({message: data.result, level: 'danger'});
	                        return;
	                    }
	                    $('#div_alert').showAlert({message: '{{Opération réalisée avec succès}}', level: 'success'});
	                    $('.li_eqLogic[data-eqLogic_id=' + $('.eqLogicAttr[data-l1key=id]').value() + ']').click();
	                }
	            });
	        }
	    });
	 console.log('end removeAll action');
 });




/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
function initTableSorter() {
  $(".tablesorter").each(function () {
    var widgets = ['uitheme', 'zebra'];
    $(".tablesorter").tablesorter({
      theme: "bootstrap",
      //widthFixed: true,
      headerTemplate: '',
      widgets: widgets,
      widgetOptions: {
        resizable: false,
        stickyHeaders: '',
        //stickyHeaders_offset: $('header.navbar-fixed-top').height(),
        zebra: ["ui-widget-content even", "ui-state-default odd"],
      }
    });
  });
}

/////////////////////////////////////////////////////////////////////
/*function saveEqLogic(_eqLogic) {
	if (!isset(_eqLogic.configuration)) {
        _eqLogic.configuration = {};
    }
    _eqLogic.configuration.window = $('#div_window .window').getValues('.expressionAttr');
    _eqLogic.configuration.existingMode = [];
   // zName = $(this).find('.programAttr[data-l1key=name]').html();
    //_eqLogic.configuration.existingMode.push(existingMode);
    
   
    return _eqLogic;
}
*/
/////////////////////////////////////////////////////////////////////
function saveEqLogic(_eqLogic) {
    if (!isset(_eqLogic.configuration)) {
        _eqLogic.configuration = {}
    }

    _eqLogic.configuration.programs = []
    console.log("saveEq: " + _eqLogic.name)
    return _eqLogic
}

$('#bt_eqConfigRaw').off('click').on('click',function(){
  var eqid= $('.eqLogicAttr[data-l1key=id]').value();
	$('#md_modal2').dialog({title: "{{Informations brutes}}"});
	$("#md_modal2").load('index.php?v=d&modal=object.display&class=eqLogic&id='+eqid).dialog('open');
})