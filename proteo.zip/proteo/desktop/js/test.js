
	
	
	$("ul.nav-tabs li:first").addClass("active");
	$(".btn-group button:first").addClass("active");
	$(".btndata button:first").addClass("active");
		
///////////***************************************************************************///////////		
	$("#return_home").click(function() {
		$('.eqlogics_list').show();
		$('.graph').show();
		$('#container_stat').empty();
	});
///////////***************************************************************************///////////	
	$("#history a").click(function() {
		//alert($('ul.nav-tabs.eqtabs li.active a').attr('value')+': '+$(this).attr('value'));
		$('.eqlogics_list').show();
		$('.graph').show();
		$('#container_stat').empty();
		
		var module = $('ul.nav-tabs.eqtabs li.active a').attr('value'),
			valtype = $(this).attr('value');
			idtype = $(this).attr('id');
		var d = new Date();
		var n = d.getFullYear();
		new histgraphYear(module, valtype, idtype)
	})
///////////***************************************************************************///////////	
	//stat annuelles
	$(".statistic_year a").click(function() {
		//alert('natype ' + $(this).attr('natype'));
		$(' #graphics').hide();
		$('ul.nav-tabs.eqtabs li a').hide();
		$(' #statistics_year').show();
		var module = $(this).attr('value'),
			valtype = $(this).attr('title');
			//natype=$(this).attr('natype'),
			data_a=$(this).attr('data_a'),
			data_info=$(this).attr('data_info'),
		//getStatYear(module, valtype,natype,data_a,data_info)
		getStatYear(module, valtype,data_a,data_info)
	})
///////////***************************************************************************///////////	
	$(".statistic_month a").click(function() {
		//alert('month ' + $(this).attr('title'));
		//$(' #graphics').hide();
		$('.graph').hide();
		$(' #statistic_month').show();
		//$(' #statistic_m').show();//ok
		
		var module = $(this).attr('value'),
			d = new Date(),
			year = d.getFullYear();
			valtype = $(this).attr('title');
			natype=$(this).attr('natype'),
			data_a=$(this).attr('data_a'),
			data_info=$(this).attr('data_info'),
		getStatMonth(module, year, valtype, natype,data_a,data_info)
	})
	
///////////***************************************************************************///////////	
	//boutton jour mois...
	$(".delay").click(function() {
		var device_id = $('ul.nav-tabs.eqtabs li.active a').attr('data-type'),
			module_id = $('ul.nav-tabs.eqtabs li.active a').attr('value'),
		type = $('.btndata button.active:first').attr('id'),
		subtitle =$('.btndata button.active:first').attr('name'),
		current_scale = $(this).attr('id');
		
		switch ($(this).attr('name')) {
			case 'day':
				var current_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600),
					current_end = Math.round(+new Date() / 1000);
				ajaxRequest(device_id, module_id, current_scale, type, current_begin, current_end, limit, subtitle, real_time);
				break;
			case 'week':
				var current_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600 * 7),
					current_end = Math.round(+new Date() / 1000);
				ajaxRequest(device_id, module_id, current_scale, type, current_begin, current_end, limit, subtitle, real_time);
				break;
			case 'month':
				var current_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600 * 30),
					current_end = Math.round(+new Date() / 1000);
				ajaxRequest(device_id, module_id, current_scale, type, current_begin, current_end, limit, subtitle, real_time);
				break;
			case 'year':
				var current_begin = Math.round(+new Date(new Date().getFullYear(), 0, 1) / 1000),
					current_end = Math.round(+new Date() / 1000);
				ajaxRequest(device_id, module_id, current_scale, type, current_begin, current_end, limit, subtitle, real_time, info = false);
				break;
	
		}
		$(this).addClass('active').siblings().removeClass('active');
	});
///////////***************************************************************************///////////
	function initScreen() {
		
		
		
		
		/*var current_scale = "1hour",
			current_begin = parseInt(Math.round(+new Date() / 1000) - 24*3600 ) ,	
			current_end = Math.round(+new Date() / 1000);*/
			
		
		switch ($('ul.nav-tabs.eqtabs li.active a').attr('name')) {
			case 'NAMain':
					//$('  aside .battery ').hide();
					//$(' .strong_battery ').hide();
					$(' .cons, .boilerOn, .boilerOff').hide();
					$(' .rain, .srain1').hide();
					$(' .windstr, .guststr, .winda, .gusta, .windhistoric').hide();
					$(' .consmoduleleft ').hide();
					$(' .temp, .hum, .pressure,.noise,.co2').show();
					//$(' .temp').addClass("active");
					//$(' .strong_status img ').attr('src', 'plugins/proteo/docs/icone/' + data.result.wifi_status);
				break;
			case 'NAModule1'://'module_ext'
					$(' .temp, .hum').show();
					$(' .consmoduleleft ').hide();
					////$('  aside .battery ').show();
					//$(' .strong_battery ').show();
					$(' .pressure, .noise, .co2 ').hide();
					$(' .cons, .boilerOn, .boilerOff').hide();
					$(' .rain, .srain1').hide();
					$(' .windstr, .guststr, .winda, .gusta, .windhistoric').hide();
					//$(' .temp').addClass("active");
					//$(' aside .battery ').show();
				break;
			case 'NAModule2'://'module_wind': WindStrength,WindAngle,Guststrength,GustAngle,WindHistoric
					//$('  aside .battery ').show();
					//$(' .strong_battery ').show();
					$(' .consmoduleleft ').hide();
					$(' .temp, .hum, .co2,.pressure,.noise ').hide();
					$(' .cons, .boilerOn, .boilerOff').hide();
					$(' .rain, .srain1').hide();
					$(' .windstr, .guststr, .winda, .gusta, .windhistoric').show();
					
					//$(' .windstr').addClass("active");
				break;
			case 'NAModule3'://'module_rain'
					//$('  aside .battery ').show();
					//$(' .strong_battery ').show();
					$(' .consmoduleleft ').hide();
					$(' .temp, .hum, .co2,.pressure,.noise ').hide();
					$(' .cons, .boilerOn, .boilerOff').hide();
					$(' .rain, .srain1').show();
					$(' .windstr, .guststr, .winda, .gusta, .windhistoric').hide();
					//$(' .srain1').addClass("active");
					break;
			case 'NAModule4'://'module_int sup'
					//$('  aside .battery ').show();
					////$(' .strong_battery ').show();
					$(' .temp, .hum, .co2').show();
					$(' .cons, .boilerOn, .boilerOff, .pressure, .noise').hide();
					$(' .rain, .srain1').hide();
					$(' .windstr, .guststr, .winda, .gusta, .windhistoric').hide();
					$(' .consmoduleleft ').hide();
					//$(' .temp').addClass("active");
					break;
			}
		
		if($('.btndata button.active:first').attr('id')==undefined){
			
			$(' .temp, .hum, .pressure,.noise,.co2, .rain, .srain1, .windstr,.guststr,.winda,.gusta,.windhistoric,.cons,.boilerOn,.boilerOff').removeClass('active');
			switch ($('ul.nav-tabs.eqtabs li.active a').attr('name')) {
				case 'VtTherm':
					$(' .temp').addClass("active");
					//$(' .strong_status img ').attr('src', 'plugins/proteo/docs/icone/' + data.result.wifi_status);
					break;
				case 'NAModule1'://'module_ext'
					$(' .temp').addClass("active");
					break;
				case 'NAModule2'://'module_wind': WindStrength,WindAngle,Guststrength,GustAngle,WindHistoric
					$(' .windstr').addClass("active");
					break;
				case 'NAModule3'://'module_rain'
					$(' .srain1').addClass("active");
					break;
				case 'NAModule4'://'module_int sup'
					$(' .temp').addClass("active");
					break;
			}
		}
		return;
		
	}
///////////***************************************************************************///////////
	//choix équipement eqlogic
	$('ul.nav-tabs.eqtabs li a').click(function(e) {
		$('ul.nav-tabs.eqtabs li.active').removeClass('active');
		$(this).parent('li').addClass('active');
		$(".btndata button.active").removeClass('active');
		$(".btndata button:first").addClass("active");
		
		
		
		$("."+$(this).attr('datali')).addClass("active");
		var device_id = $(this).attr('data-type'),
			module_id = $(this).attr('value'),//module_id = 0,
			scale = '1hour',
			
			//current_begin = parseInt(Math.round(+new Date() / 1000) - 24*3600 ) ,	
			//current_end = Math.round(+new Date() / 1000),
			
			type = $('.btndata button.active:first').attr('id'),
			begin_date = current_begin,
			end_date = current_end,
			limit = '1024',
			subtitle = $('.btndata button.active:first').attr('name');//'Température';
		ajaxRequest(device_id, module_id, scale, type, begin_date, end_date, limit, subtitle, real_time, info = true);
		
		//$(".btn-group button:first").addClass("active");
		$('.btn-group button').removeClass('active');
		$(".btn-group button:first").addClass("active");
		$('#select_date_begin').val('');
		$('#select_date_end').val('');
		
		
		
	})
///////////***************************************************************************///////////
	//timepicker time
	$("#valid_time").click(function() {
		if ($('#select_date_begin').val() == "" && $('#select_date_end').val() == "") {
			var date_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600),
				date_end = Math.round(+new Date());
		}
		if ($('#select_date_begin').val() != "" && $('#select_date_end').val() != "") {
			var date_begin = $('#timestamp_start').val(),
				date_end = $('#timestamp_end').val();
		}
		if ($('#select_date_begin').val() != "" && $('#select_date_end').val() == "") {
			var date_begin = $('#timestamp_start').val();
			date_end = parseInt(Math.round(date_begin) + 24 * 3600)
		}
		if ($('#select_date_begin').val() == "" && $('#select_date_end').val() != "") {
			$('#div_alert').showAlert({
				message: 'Il faut choisir une date de début',
				level: 'danger'
			});
			return;
		}
		var period = parseInt(Math.round($('#timestamp_end').val() - $('#timestamp_start').val()));
		if (period > 15552000) {
			var current_scale = '1week';
		} else if (period > 7776000) {
			var current_scale = '1day';
	
		} else if (period > 2592000) {
			var current_scale = '3hours';
		} else {
			var current_scale = '3hours';
		}
		var device_id = $('ul.nav-tabs.eqtabs li.active a').attr('data-type'),
			module_id = $('ul.nav-tabs.eqtabs li.active a').attr('value'),
			type = $('.btndata button.active:first').attr('id'),
			limit = '1024',
			subtitle = $('.btndata button.active:first').attr('name');//'Température';
		ajaxRequest(device_id, module_id, current_scale, type, date_begin, date_end, limit, subtitle, real_time, info = false);
		$('.btn-group button').removeClass('active');
	});
///////////***************************************************************************///////////
	//choix requestdata//scale 1jour 1 mois....
	$(".data").click(function() {
		//alert($('.btn-group button.active').attr('name'))
		//alert($('.btn-group delay button.active').attr('name'))
		//alert($('.btn-group button.active').attr('name'))
		
		$(".btndata button.active:first").removeClass('active');
		$(this).addClass('active');
		
		if ($('.btn-group button.active').attr('name')) {
			
			
			switch ($('.btn-group button.active').attr('name')) {
				case 'day':
					var current_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600),
						current_end = Math.round(+new Date() / 1000),
						current_scale = '1hour';
					break;
				case 'week':
					var current_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600 * 7),
						current_end = Math.round(+new Date() / 1000)
					current_scale = '3hours';
					break;
				case 'month':
					var current_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600 * 30),
						current_end = Math.round(+new Date() / 1000),
						current_scale = '1day'
					break;
				case 'year':
					var current_begin = Math.round(+new Date(new Date().getFullYear(), 0, 1) / 1000),
						current_end = Math.round(+new Date() / 1000),
						current_scale = '1week';
					break;
			}
		} else {
			if ($('#select_date_begin').val() == "" && $('#select_date_end').val() == "") {
				var current_begin = parseInt(Math.round(+new Date() / 1000) - 24 * 3600),
					current_end = Math.round(+new Date());
			}
			if ($('#select_date_begin').val() != "" && $('#select_date_end').val() != "") {
				var current_begin = $('#timestamp_start').val(),
					current_end = $('#timestamp_end').val();
			}
			if ($('#select_date_begin').val() != "" && $('#select_date_end').val() == "") {
				var current_begin = $('#timestamp_start').val();
				current_end = parseInt(Math.round(date_begin) + 24 * 3600)
			}
	
			if ($('#select_date_begin').val() == "" && $('#select_date_end').val() != "") {
				$('#div_alert').showAlert({
					message: 'Il faut choisir une date de début',
					level: 'danger'
				});
				return;
			}
			var period = parseInt(Math.round($('#timestamp_end').val() - $('#timestamp_start').val()));
			if (period > 15552000) {
				var current_scale = '1week';
			} else if (period > 7776000) {
				var current_scale = '1day';
	
			} else if (period > 2592000) {
				var current_scale = '3hours';
			} else {
				var current_scale = '3hours';
			}
		}
		var device_id = $('ul.nav-tabs.eqtabs li.active a').attr('data-type'),
			module_id = module_id = $('ul.nav-tabs.eqtabs li.active a').attr('value'),
			//type = 'min_' + this.id + ',max_' + this.id + '',
			type = this.id,
			subtitle = this.name;
		ajaxRequest(device_id, module_id, current_scale, type, current_begin, current_end, limit, subtitle, real_time, info = false);
	});
	
	$("#select_date_begin").datepicker("option",
		$.datepicker.regional['fr']
	);
	
	$("#select_date_end").datepicker("option",
		$.datepicker.regional['fr']
	);
	
	$('#select_date_begin').datepicker({
		format: 'd/m/Y',
		timepicker: false,
		onClose: function(dateString) {
			var myDate = $('#select_date_begin').datepicker('getDate') / 1000;
			$('#timestamp_start').attr({
				value: myDate
			});
	
		}
	});
	
	$('#select_date_end').datepicker({
		format: 'd/m/Y',
		timepicker: false,
		onClose: function(dateString) {
			var myDate = $('#select_date_end').datepicker('getDate') / 1000;
			$('#timestamp_end').attr({
				value: myDate
			});
		}
	});
	///////////***************************************************************************///////////
	$(".clic").click(function() {
		
		confirm( "Voulez vous vraiment reinitialiser le Thermostat aux parametres usine",)
		var msg1 = "Le Thermostat Migo a été réinitialisé aux parametres usine, avec succès !",
			msg2 = " Veuillez reconfigurer la connection Wifi",
			msg3 = "Plugin Jeedom::proteo est introuvable";
		
		$('#div_alert').showAlert({ message: msg1 + msg2, level: 'danger'});
		$(".clic").hide();
		
		
		
		//$(' #graphics').hide();
		//$('.displayError').text(msg1 + msg2);
		
		
		sleep(1000)
		alert(msg3);
		
		if($('.displayError').text =! ''){
		//peur(msg3);
		//sleep(1000);
		sleep(1000)
		$('.peur').text("...le Flipes ?...")
		}
		//$('.displayError').append("								...tu Flipes ?...")
		
		
	});
	function peur(msg) {
		sleep(500);
		//$('.displayError').text("Le Flip !...");
		//alert();
	}
///////////***************************************************************************///////////	
	Highcharts.getSVG = function(charts) {
		var svgArr = [],
			top = 0,
			width = 0;
		$.each(charts, function(i, chart) {
			var svg = chart.getSVG();
			svg = svg.replace('<svg', '<g transform="translate(0,' + top + ')" ');
			svg = svg.replace('</svg>', '</g>');
	
			top += chart.chartHeight;
			width = Math.max(width, chart.chartWidth);
	
			svgArr.push(svg);
		});
		return '<svg height="' + top + '" width="' + width + '" version="1.1" xmlns="http://www.w3.org/2000/svg">' + svgArr.join('') + '</svg>';
	};
///////////***************************************************************************///////////
	Highcharts.exportCharts = function(charts, options) {
		var form
		svg = Highcharts.getSVG(charts);
		options = Highcharts.merge(Highcharts.getOptions().exporting, options);
		form = Highcharts.createElement('form', {
			method: 'post',
			action: options.url
		}, {
			display: 'none'
		}, document.body);
		Highcharts.each(['filename', 'type', 'width', 'svg'], function(name) {
			Highcharts.createElement('input', {
				type: 'hidden',
				name: name,
				value: {
					filename: options.filename || 'chart',
					type: options.type,
					width: options.width,
					svg: svg
				}[name]
			}, null, form);
		});
		form.submit();
		form.parentNode.removeChild(form);
	};
///////////***************************************************************************///////////	
	Highcharts.setOptions({
		lang: {
			months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
				'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
			],
			weekdays: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
			rangeSelectorFrom: "du",
			rangeSelectorTo: "au"
		},
		global: {
			useUTC: false
		}
	});
///////////***************************************************************************///////////
	///////////***************************************************************************///////////
	function createGraph(data_module) {
		var datalength = data_module.result.dataType.split(",").length;
		
		if(datalength <= 1){
			
			dataType = data_module.result.dataType;
			nbseries = [{}] ;
				
		}else if(datalength === 2){
			dataType = data_module.result.dataType.split(",");
			nbseries = [{}, {}];	
		}else if(datalength >= 3){
			dataType = data_module.result.dataType.split(",");
			nbseries = [{}, {}, {}];	
		}
		
		
		var options = {
			chart: {
				renderTo: 'container',
				zoomType: 'xy',
				type: 'spline'
			},
			title: {},
			subtitle: {},
			rangeSelector: {
				inputEnabled: false
			},
			legend: {
				enabled: true,
				shadow: true
			},
			plotOptions: {
				line: {
					marker: {
						enabled: false
					}
				}
			},
	
			tooltip: {
				crosshairs: true,
				shared: true,
	
				formatter: function() {
					var s = '<b>' + Highcharts.dateFormat('%A %e %b %Y %H:%M', this.x) + '</b>';
	
					$.each(this.points, function(i, point) {
						s += '<br/>' + '<span style="font-weight:bold;color:' + this.series.color + '">' + this.series.name + ': </span>' + this.y;
						
						var unit = $('.btndata button.active:first').attr('data-unit');
						s += unit;
					});
	
					return s;
				}
			},
			xAxis: [{
				type: 'datetime',
				dateTimeLabelFormats: { // don't display the dummy year
					month: '%e. %b',
					year: '%b'
				}
			}],
			yAxis: [{ // Primary yAxis
				title: {
					style: {}
				},
				labels: {
					// format: '{value} °C'
				},
			}, { // secondary yAxis
				title: {
					style: {}
				},
				labels: {
					// format: '{value} °C'
				},
				opposite: true
			}],
			
			//series: [{}, {}, {}]
			series:nbseries
			
		};
		
		var data = data_module,
			//obj = JSON.parse(data_module.result.infos),
			obj = data_module.result.infos,
			typeGraph = data_module.result.type_graph,
			data1 = [];
			data2 = [];
			data3 = [];
		$.each(obj, function(i, e) {
			data1.push([i * 1000, e[0]]);
			if (typeof data2 != "undefined") {
				data2.push([i * 1000, e[1]]);
			}
			if (typeof data3 != "undefined") {
				data3.push([i * 1000, e[2]]);
			}
		})
		//options.title.text = data_module.result.name_module;
		options.title.text = 'Graphique ' + data_module.result.type_graph + ' ' + data_module.result.name_module;
		options.subtitle.text = '';
		
		if(datalength <= 1){
			
			options.series[0].name = $(".btndata button.active").attr('data-tag').split(",")[0]
			options.series[0].data = data1; //max_temp
			options.series[0].color = '#78aae8'
			options.yAxis[0].title.text = options.series[0].name
			options.yAxis[0].title.style.color = options.series[0].color
			options.yAxis[0].labels.format = '{value} '+ $(".btndata button.active").attr('data-unit');
				
		}else if(datalength == 2){
			options.series[0].name = $(".btndata button.active").attr('data-tag').split(",")[0]
			options.series[0].data = data1; //min_temp
			options.series[0].color = '#78aae8'
			options.yAxis[0].title.text = options.series[0].name
			options.yAxis[0].title.style.color = options.series[0].color
			options.yAxis[0].labels.format = '{value} '+ $(".btndata button.active").attr('data-unit');
				
			options.series[1].name =  $(".btndata button.active").attr('data-tag').split(",")[1]
			options.series[1].data = data2; //max_temp
			options.series[1].color = '#DC143C'
			options.yAxis[1].title.style.color = options.series[1].color
			options.yAxis[1].title.text = options.series[1].name
		}else if(datalength == 3){
			
			options.series[0].name =  $(".btndata button.active").attr('data-tag').split(",")[0]
			options.series[0].data = data1; //max_temp
			options.series[0].color = '#800080'
			options.yAxis[0].title.style.color = options.series[0].color
			options.yAxis[0].title.text = options.series[0].name;
			options.yAxis[0].labels.format =  '{value} '+ $(".btndata button.active").attr('data-unit');
				
			options.series[1].name =  $(".btndata button.active").attr('data-tag').split(",")[1]
			options.series[1].data = data2; //min_temp
			options.series[1].color = '#78aae8'
			options.yAxis[1].title.style.color = options.series[1].color
				
				
			options.series[2].name = $(".btndata button.active").attr('data-tag').split(",")[2]
			options.series[2].data = data3; //min_temp
			options.series[2].color = '#DC143C'
			options.yAxis[1].title.text = options.series[1].name + ' ' + options.series[2].name;
			//options.series[2].title.style.color = options.series[2].color
			//options.yAxis[2].title.text = options.series[2].name;
		}
		/*
		switch (data_module.result.type_graph) {
			case 'WindStrength':
				
				options.series[0].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color;
				
				break;
			case 'GustStrength':
				
				options.series[0].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color;
				break;
			case 'WindAngle':
				options.series[0].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color;
				
				break;
			case 'GustAngle':
				options.series[0].name = 'Angles rafales'
				options.series[0].data = data1; //max_temp
				options.series[0].color = '#3498db'
				options.yAxis[0].title.text = options.series[0].name
				options.yAxis[0].title.style.color = options.series[0].color;
				break;
			case 'Rain':
				options.series[0].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color;
				break;
			case 'Srain1':
				options.series[0].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color;
				break;
			case 'Srain24':
				options.series[0].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color;
				break;
			case 'Température':
				options.series[0].color = '#DC143C'
				options.series[1].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color
				options.yAxis[1].title.style.color = options.series[1].color;
				break;
			case 'Humidité':
				options.series[0].name = 'Humidité max'
				options.series[0].data = data2; //max_temp
				options.series[0].color = '#00FFFF'
				options.series[1].name = 'Humidité min'
				options.series[1].data = data1; //min_temp
				options.series[1].color = '#7FFFD4'
				options.yAxis[0].title.style.color = '#00FFFF'
				options.yAxis[1].title.style.color = '#7FFFD4'
				options.yAxis[0].title.text = 'Humidité max';
				options.yAxis[1].title.text = 'Humidité min';
				break;
			case 'Pression':
				options.series[0].name = 'Pression'
				options.series[0].data = data2; //max_temp
				options.series[0].color = '#800080'
				options.yAxis[0].title.style.color = '#800080'
				options.yAxis[0].title.text = 'Pression';
				options.yAxis[0].labels.format = '{value} mbar';
				break;
			case 'Bruit':
				options.series[0].color = '#0000CD'
				options.series[1].color = '#B0C4DE'
				options.yAxis[0].title.style.color = options.series[0].color
				options.yAxis[1].title.style.color = options.series[1].color;
				break;
			case 'C02':
				options.series[0].color = '#3498db'
				options.yAxis[0].title.style.color = options.series[0].color;
				break;
			
		}
		
		*/
		$('#title_name').empty().append('Graphique proteo');
		new Highcharts.Chart(options)
	}



///////////***************************************************************************///////////
	function ajaxRequest0(device_id, module_id, scale, type, date_begin, date_end, limit, subtitle, real_time, info) {
		//alert(device_id +'--'+ module_id + '--' +type)
		
		//alert('ajax type: '+ type);
				
		$.ajax({
			type: 'POST',
			url: 'plugins/proteo/core/ajax/proteo.ajax.php',
			data: {
				
				action: 'getDataG',
				device_id: device_id,
				module_id: module_id,
				scale: scale,
				type: type,
				date_begin: date_begin,
				date_end: date_end,
				limit: limit,
				subtitle: subtitle,
				real_time: real_time
			},
			dataType: 'json',
			error: function(request, status, error) {
				handleAjaxError(request, status, error);
			},
			success: function(data) {
				//alert('ajax type2: '+ type);
				if (info) {
					if (data.state != 'ok') {
						$('#div_alert').showAlert({
							message: data.result,
							level: 'danger'
						});
						return;
					}
					
					
					if (data.result.temperature_module != undefined){
						$(' .temp_module_left').empty();
						$(' .temp_module_left').append(parseFloat(Math.round(data.result.temperature_module * 10) / 10).toFixed(1));
						
						$(' .temp_module_left').css('font-weight', 'bold');
					}
					if (data.result.max_temp_module != undefined){
						$(' .temp_max_left ').empty();
						$(' .temp_max_left ').append(parseFloat(Math.round(data.result.max_temp_module * 10) / 10).toFixed(1));
						$(' .temp_max_left ').css('font-weight', 'bold');
						
					}
					if (data.result.min_temp_module != undefined){
						$(' .temp_min_left ').empty();
						$(' .temp_min_left ').append(parseFloat(Math.round(data.result.min_temp_module * 10) / 10).toFixed(1));
						$(' .temp_min_left ').css('font-weight', 'bold');
					}
					
					if (data.result.Humidity_module != undefined){
						$(' .humidity_left').empty();
						$(' .humidity_left').append(data.result.Humidity_module);
						$(' .humidity_left').css('font-weight', 'bold');
					}else 
						$(' .humidity_left').css('font-weight', '');
					
					if (data.result.CO2_module != undefined){
						$(' .co2_left').empty();
						$(' .co2_left').append(data.result.CO2_module);
						$(' .co2_left').css('font-weight', 'bold');
					}else 
						$(' .co2_left').css('font-weight', 'normal');
						
					if (data.result.Pressure_module != undefined){
						$(' .pressure_left').empty();
						$(' .pressure_left').append(data.result.Pressure_module);
						$(' .pressure_left').css('font-weight', 'bold');
					}else 
						$(' .pressure_left').css('font-weight', 'normal');
					
					if (data.result.Noise_module != undefined){
						$(' .noise_left').empty();
						$(' .noise_left').append(data.result.Noise_module);
						$(' .noise_left').css('font-weight', 'bold');
					}else 
						$(' .noise_left').css('font-weight', 'normal');
					
				
					$(' .strong_battery img ').attr('src', 'plugins/naMeteo/docs/icone/' + data.result.battery_percent);
					$(' .strong_status img ').attr('src', 'plugins/naMeteo/docs/icone/' + data.result.rf_status);
					
				}
				createGraph(data);
				
		
			}
			
		});
		initScreen();
	};
	function ajaxRequest(device_id, module_id, scale, type, date_begin, date_end, limit, subtitle, real_time, info) {
		$.ajax({
			type: 'POST',
			url: 'plugins/proteo/core/ajax/proteo.ajax.php',
			data: {
				action: 'getDataG',
				device_id: device_id,
				module_id: module_id,
				scale: scale,
				type: type,
				date_begin: date_begin,
				date_end: date_end,
				limit: limit,
				subtitle: subtitle,
				real_time: real_time
			},
			dataType: 'json',
			error: function(request, status, error) {
				handleAjaxError(request, status, error);
			},
			success: function(data) {
				if (info) {
					if (data.state != 'ok') {
						$('#div_alert').showAlert({
							message: data.result,
							level: 'danger'
						});
						return;
					}
					//$(' .temp_module_left,.temp_max_left,.temp_min_left,.Hum_left').empty();
					//$(' .temp_module_left').append(parseFloat(Math.round(data.result.temperature_module * 10) / 10).toFixed(1));
				//	$(' .temp_max_left ').append(parseFloat(Math.round(data.result.max_temp_module * 10) / 10).toFixed(1));
					//$(' .temp_min_left ').append(parseFloat(Math.round(data.result.min_temp_module * 10) / 10).toFixed(1));
					//$(' .temp_cons_left ').append(parseFloat(Math.round(data.result.cons_module * 10) / 10).toFixed(1));		
					
					//$(' .Hum_left').append(data.result.Hum_module);
					//$(' .battery img ').attr('src', 'plugins/proteo/docs/icone/' + data.result.battery_percent);
					//$(' .status img ').attr('src', 'plugins/proteo/docs/icone/' + data.result.rf_status);
					
					
				}
				var type_station = data.result.type;
				
				//$(' .pressure,.noise,.co2,.hum ').hide();
				//$('  aside .battery ').show();
				$(' .temp, .tempmm').show();
				$(' .cons, .boiler, .sumboiler, .boilerOff ').show();
				$(' .consmoduleleft ').show();
					
				//$(' .tempmaxleft ').hide();
				//$(' .tempminleft ').hide();
				
				createGraph(data);
			}
		});
		//initScreen();
	};
////////////////////////////////////*******************////////////////////////////////////
	
/////////// historique annuelle ***************************************************************************///////////
	function histgraphYear(module, valtype,	idtype) {
		//$('#container_stat').empty();
		//alert("module: " + module)
		//alert("valtype: " + valtype)
		//alert("idtype: " + idtype)
		
		
		$.ajax({
			type: 'GET',
			url: 'plugins/proteo/data/year.json',
			dataType: 'json',
			async: false,
			error: function(request, status, error) {
				handleAjaxError(request, status, error);
			},
			success: function(data) {
				result = data;
			}
		});
		
			
		var options = {
			chart: {
				renderTo: 'container',
				zoomType: 'xy',
				type: 'spline',
			},
			title: {
			},
			subtitle: {},
			rangeSelector: {
				inputEnabled: false
			},
			legend: {
				enabled: true,
				shadow: true
			},
			xAxis: {
				categories: ['Jan','Fév','Mar','Avr','Mai','Jui','Jui','Aou','Sep','Oct','Nov','Déc'],
				min: 0,
				max: 11,
				crosshair: true
			},
			yAxis: { // Primary yAxis
				labels: {
					// format: '{value} °C'
				},
				title: {}
			},
			tooltip: {
				shared: true
			}
		};
		var seriesData = [];
		//alert("valtype " +'--'+ valtype+' idtype: '+idtype)
		
		for (i = 0; i < result.length; i++) {
			//if (result[i]['device_id']+'|'+result[i]['module_id'] == module) {
				resulttype=result[i]['datatype'].split(",");
				//alert(resulttype.length + resulttype[0])
			if (result[i]['module_id'] == module) {
				for (j = 0; j < resulttype.length; j++) {
					
					if (resulttype[j] == valtype) {
					//	alert("resulttype[j] " +resulttype[j] + " valtype " + valtype)
						dindex=j;
						unit = result[i]['unit'][j];
						//alert('dindex: '+ valtype + '--'+ dindex)
						//break;
					}

				}
				//alert('if '+ result[i]['datatype'][0] +'--'+ result[i]['datatype'][1])
				$('#title_name').empty().append('Graphique Annuel');
				//options.title.text = result[i]['name'];
				options.title.text = 'Graphique Annuel ' + idtype + ' ' + result[i]['name'];
				var title = idtype,
							prefix = unit
				
				options.yAxis.title.text = title;
				options.yAxis.labels.format = '{value} ' + prefix;
				var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
				for (var key in result[i]['year']) {
					
					var obj = result[i]['year'][key];
					var series = [];
					var j = 0;
					
					$.each(obj, function(i, e) {
						switch (unit) {
							case 'kWh':
								var coef = 1000,
									prefix = 'kWh';
								break;
							case 'W':
								var coef = 1000,
									prefix = 'kWh';
								break;
							case '°C':
								var coef = 1;
								prefix = '°C';
								break;
							case 'sec':
								var coef = 60,
									prefix = 'min';
								break;
							case 'min':
								var coef = 1,
									prefix = 'min';
								break;
							default:
								var coef = 1;
								prefix = '';
								break;
						}
						//alert("coef: " + coef +'--'+ prefix)
				
						var date = new Date(i * 1000);
						if (monthNames[date.getMonth()] == monthNames[j]) {
							//series.push([e[dindex]])
							//series.push([ Math.round(e[resulttype.indexOf(valtype)]/coef * 10 / 10).toFixed(1) ])
							//series.push([ Math.round(e[resulttype.indexOf(valtype)]*10/coef/10).toFixed(0) ])
							series.push([ parseFloat(Math.round(e[resulttype.indexOf(valtype)]/coef * 10).toFixed(1) / 10)])
						} else {
							
							var k = date.getMonth();
							for (j = 0; j < k; j++) {
								series.push(null)
							}
							$.each(obj, function(i, e) {
								//series.push([e[dindex]])
								//series.push([ parseFloat(Math.round(e[resulttype.indexOf(valtype)]/coef * 10) / 10) ])
								series.push([ parseFloat(Math.round(e[resulttype.indexOf(valtype)]/coef * 10).toFixed(1) / 10)])
								//series.push([ parseFloat(Math.round(e[resulttype.indexOf(valtype)]/coef * 10) / 10).toFixed(1) ])
							})
							return false;
						}
						console.log("seriesData: "+valtype+'--' + series)
						j++;
					})
					
					
						if(valtype == 'rain' || valtype=='srain1'){
						typegraph = 'column';//'spline',//'bar',
						}else {typegraph = 'spline';}//'spline',
						
					seriesData.push({
						name: key,
						tooltip: {
							valueSuffix: ' ' + prefix
						},
						type: typegraph, //'spline',//'bar',
				
						data: series
					});
				}
			}
		}
		//console.log("seriesData: " + seriesData)
		options.series = seriesData;
		var chart = new Highcharts.Chart(options);
		
	}
///////////***************************************************************************///////////
	function colorTemp(data) {
		switch (true) {
			case (data > 27):
				return "#5F0000";
				break;
			case (data > 24):
				return "#A31B1E";
				//return "#780A0F";
				break;
			case (data > 21):
				return "#A60F14";
				break;
			case (data > 18):
				return "#CC181E";
				break;
			case (data > 15):
				return "#FC9272";
				break;
			case (data > 12):
				return "#FB6A4A";
				break;
			case (data > 9):
				return "#FC9272";
				break;
			case (data > 6):
				return "#FCBBAA";
				break;
			case (data > 3):
				return "##FFE0E0";
				break;
			case (data > 0):
				return "#FFF0F5";
				break;
			case (data > -2):
				return "#AADCE6";
				break;
			case (data > -4):
				return "#DBF5FF";
				break;
			case (data > -6):
				return "#AADCE6";
				break;
			case (data > -8):
				return "#78BFD6";
				break;
			case (data > -10):
				return "#5AA0CD";
				break;
			case (data > -12):
				return "#4292C7";
				break;
			case (data > -14):
				return "#072F6B";
				break;
			case (data > -16):
				return "#08529C";
				break;
			case (data > -18):
				return "#FFFFFF";
				break;
			default:
				return "#071E46";
				break;
		}
	}
///////////***************************************************************************///////////	
	function colorHumidity(data) {
		switch (true) {
			case (data == 100):
				return "#0000C2";
				break;
			case (data > 90):
				return "#303EFF";
				break;
			case (data > 75):
				return "#3C83FF";
				break;
			case (data > 60):
				return "#33C1FF";
				break;
			case (data > 50):
				return "#00FFFF";
				break;
			case (data > 40):
				return "#80FFC7";
				break;
			case (data > 35):
				return "#FFFFBE";
				break;
			case (data > 30):
				return "#FFFF00";
				break;
			case (data > 25):
				return "#FEBD00";
				break;
			case (data > 20):
				return "#FF9000";
				break;
			case (data > 15):
				return "#FE5900";
				break;
			case (data > 10):
				return "#6E000D";
				break;
			case (data > 5):
				return "#A64443";
				break;
			default:
				return "#6E000D";
				break;
		}
	}
///////////***************************************************************************///////////	
	function colorRain(data) {
		switch (true) {
			case (data == 100):
				return "#c7e0ea";
				break;
			case (data > 80):
				return "#b1dced";
				break;
			case (data > 60):
				return "#8dcee8";
				break;
			case (data > 40):
				return "#71b3ce";
				break;
			case (data > 30):
				return "#5198b5";
				break;
			case (data > 15):
				return "#378dcc";
				break;
			case (data > 10):
				return "#2485cc";
				break;
			case (data > 5):
				return "#d7ecf2";
				break;
			case (data > 2):
				return "#02528c";
				break;
			default:
				return "#8b9496";
				break;
		}
	}
///////////***************************************************************************///////////	
	function colorWind(data) {
		switch (true) {
			case (data > 100):
				return "#510256";
				break;
			case (data > 80):
				return "#66016d";
				break;
			case (data > 60):
				return "#ad19b7";
				break;
			case (data > 40):
				return "#f466ff";
				break;
			case (data > 20):
				return "#f9a5ff";
				break;
			case (data > 10):
				return "#e0c3e2";
				break;
			case (data > 5):
				return "#c6b8c6";
				break;
			case (data > 1):
				return "#9a91a3";
				break;
			default:
				return "#8b9496";
				break;
		}
	}
///////////***************************************************************************///////////
	function getStatMonth(module, year , valtype, natype,data_a,data_info) {
		datalength = $(this).attr('data_a').split(",").length;
		btndataType = $(this).attr('data_a').split(",");
		//data_a1=btndataType[0];
		//data_a2=btndataType[1];
		dinfo =  $(this).attr('data_info').split(",");
		btndata = data_a.split(",");
		$('#container_stat').empty();
		$.ajax({
				type: 'GET',
				url: 'plugins/proteo/data/month.json',
				data: {
					type: 'month'
				},
				dataType: 'json',
				async: false,
				error: function(request, status, error) {
					handleAjaxError(request, status, error);
				},
				success: function(data) {
					
					result = data;
					//alert("data.name " + data['name'])
					////////
					
		var monthNames = ['Jan', 'fev', 'mar', 'avr', 'mai', 'juin', 'jui', 'aou', 'sep', 'oct', 'nov', 'dec'],
			NbrCol = 13, // nombre de colonnes
			NbrLigne = 31, // nombre de lignes
			div = "";
		div += '<table border="1" width="100%"><thead>';
		div += '<tr><th rowspan="2" style="background:#CCCCCC;">dates</th>';
		
		for (i = 0; i < monthNames.length; i++) {
			div += '<th colspan="2" style="background:#CCCCCC;"> ' + monthNames[i] + '</th>';
		}
					
		div += '</tr>';
		div += '<tr>';
		for (j = 1; j < 25; j++) {
			
			if (j / 2 == Math.round(j / 2) ) {//&& btndataType.length > 1
				div += '<td class="' + btndataType[1] + '_statm" >' + dinfo[1] + '</td>';//col2
			} else {
				div += '<td class="' + btndataType[0] + '_statm" >' + dinfo[0] + '</td>';//col1
			}
		}
		
		div += '</tr>';
		for (i = 1; i <= NbrLigne; i++) {
			div += '<tr class="' + i + '">';
			div += '<td > ' + i + '</td>';
			for (j = 1; j < 25; j++) {
				div += '<td ></td>';
			}
			div += '</tr>';
		}
	
		div += '</table >';
		$("#container_stat").append(div);
		
				for (i = 0; i < result.length; i++) {
					
					//if (result[i].module_id == module) {
					if (result[i]['device_id']+'|'+result[i]['module_id'] == module) {
						resulttype=result[i]['datatype'].split(",");
						resultu = result[i]['unit'];
						unit=resultu[resulttype.indexOf(btndata[0])];
						$('.eqlogics_list').hide();
						$('#title_name').empty().append('Statistiques Mensuelles des températures pour ' + result[i]['name'] + ' pour l\'année : ' + year + ' en: ' + unit);
						var links = Object.keys(result[i].year).reverse();
						var menu = '<div class="btn-group menu_year">';
						for (var j = 0; j < links.length; j++) {
							menu += '<button type="button" class="btn btn-primary menu_year" value="' + module + '" name="' + links[j] + '">' + links[j] + '</button>';
						}
						menu += '</div>';
						$('#container_stat').prepend(menu);
						
						switch (unit) {
								case 'kWh':
									var coef = 1000,
										prefix = unit;
									break;
								case 'W':
									var coef = 1,
										prefix = unit;
									break;
								case '°C':
									var coef = 1;
									break;
								case 'sec':
									var coef = 1,
										prefix = unit;
									break;
								case 'min':
									var coef = 60,
										prefix = unit;
									break;
								default:
									var coef = 1;
									prefix = unit;
									break;
						}	
							//unit=resultunit[indexOf(btndataType[0])];
							//alert("btndataType[0] " + btndataType[0])
							//alert("btndata[0] " + btndata[0])
							//alert("index unit " + result[i]['unit'].split(",")[0])
							
						var obj = result[i]['year'][year];
						
						$.each(obj, function(i, e) {
							var d = new Date(i * 1000);
								n = d.getDate();
								m = d.getMonth(),
								q = (m + 1) * 2,
								r = q - 1;
							//alert("valtype " +valtype)
							
							
							data_min = parseFloat(Math.round(e[resulttype.indexOf(btndata[0])]/coef * 10) / 10).toFixed(1);
							data_max = parseFloat(Math.round(e[resulttype.indexOf(btndata[1])]/coef * 10) / 10).toFixed(1);
							//data_min=e[resulttype.indexOf(btndata[0])]/coef;
							//data_max=e[resulttype.indexOf(btndata[1])]/coef;
								
							switch (valtype) {//$( "#sel_type" ).val()series.push([e[dindex]])
								case 'tem': 
									colorMin = colorTemp(data_min);
									colorMax = colorTemp(data_max); 
									break;
								case 'cons':
									colorMin = colorHumidity(data_min),
									colorMax = colorHumidity(data_max); 
									break;
								case 'hum':  
									colorMin = colorWind(data_min),
									colorMax = colorWind(data_max); 
									break;
								case 'guststr':
									colorMin = colorWind(data_min),
									colorMax = colorWind(data_max); 
									break;
								case 'rain': 
									//$(' .statmmin ').empty().append('Pluie');
									//$(' .statmmax ').empty().append('');
									colorMin = colorRain(data_min); 
									break;
								default:
									colorMin = colorTemp(data_min);
									colorMax = colorTemp(data_max); 
									break;
								
							}
							//$('#' + btndata[k] + '_staty .' + year[j] + '').find('td:eq(' + n + ')').append(dataval);
							
							//alert("table tr." + n +"---"+ "td:eq(" + r + ")")
							$("table tr." + n).find("td:eq(" + r + ")").append(data_min);
							$("table tr." + n).find("td:eq(" + r + ")").css("background-color", colorMin);
							if(btndataType.length>1){
								//alert("btndataType.length: " +btndataType.length)
								$("table tr." + n).find("td:eq(" + q + ")").append(data_max);
								$("table tr." + n).find("td:eq(" + q + ")").css("background-color", colorMax);
								
							}else{
								$("." + btndataType[1] + '_statm').empty();
							}
							
						})
						//$("." + btndataType[1] + '_statm').empty();
						//alert($("." + btndataType[1] + '_statm'))
						//$('#' + btndataType[1] + '_statm .' + '').find("td:eq(" + 1 + ")").append(600);
						//$(' .'+ btndataType[1] + ")").empty().append('Vents');
						//$("table tr." + 1).find("td:eq(" + 1 + ")").append(600);
						//$("table tr." + 1).find("td:eq(" + 2 + ")").append(870);
						//$('#' + btndataType[1] + '_statm .' + 1 + '').find("td:eq(" + 1 + ")").append(600);
						//'<td class="' + btndataType[1] + '_statm" >' + dinfo[1] + '</td>'
					}
				}
				$(".menu_year button").click(function() {
						year = $(this).attr('name');
						
						
					getStatMonth(module, year , valtype, natype,data_a,data_info)
				})
			}
		});
	}
	
///////////stats annuelles***************************************************************************///////////
	function getStatYear(module, valtype,data_a,data_info) {//(module, valtype,data_a,data_info)
		//alert("valtype: " +valtype)
		$('#container_stat').empty();
		$.ajax({
				type: 'GET',
				url: 'plugins/proteo/data/year.json',
				data: {
					type: 'year'
				},
				dataType: 'json',
				async: false,
				error: function(request, status, error) {
					handleAjaxError(request, status, error);
				},
				success: function(data) {
					
					result = data;
					////////
					
				var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
				
				var info = Object.values(data_info.split(","));//data_info.split(",");
					
					var btndata = Object.values(data_a.split(","));
						
					for (var k = 0; k < btndata.length; k++) {
						div = '<div>';
						div += '<table id="' + btndata[k] + '_staty" class="table_stat" border="1" style="width:100%;margin:auto"><caption>' + info[k] + '</caption><thead><tr><th></th><th style="text-align:center">jan</th><th>Fev</th><th>Mar</th><th>Avr</th><th>mai</th><th>Jui</th><th>Jui</th><th>Aou</th><th>Sept</th><th>Oct</th><th>Nov</th><th>Déc</th><tr></thead>';
						div += '<tbody>';
						$('.graph').hide();
						$('.eqlogics_list').hide();
						//alert('result.length: ' + result.length)
						for (i = 0; i < result.length; i++) {
						//for (i = result.length; i >0; i++) {
							if (result[i]['device_id']+'|'+result[i]['module_id'] == module) {
								nblinks = Object.keys(result[i].year);
								nbyear = Object.keys(result[i].year).length;
								//year = Object.keys(result[i].year).reverse();
								year = Object.keys(result[i].year);
								resulttype=result[i]['datatype'].split(",");//Object.keys(result[i].['datatype']);
								resultu = result[i]['unit'];
								unit=resultu[resulttype.indexOf(btndata[k])];
								switch (unit) {
									case 'kWh':
										var coef = 1000,
											prefix = unit;
										break;
									case 'min':
										var coef = 60,
											prefix = unit;
										break;
									default:
										var coef = 1;
										prefix = unit;
										break;
								}
								for (var y = 0; y < nbyear; y++) {
									div += '<tr class="' + year[y] + '"><th >' + year[y] + '</th><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
								}
								$('#title_name').empty().append('Statistique annuelle pour ' + result[i]['name']);
								$('#container_stat').append(div);
							
								for (var j = 0; j < nbyear; j++) {
									var obj = result[i]['year'][year[j]];
									$.each(obj, function(i, e) {
										var d = new Date(i * 1000);
										var n = d.getMonth();
										//dataval = e[resulttype.indexOf(btndata[k])]
									dataval = parseFloat(Math.round(e[resulttype.indexOf(btndata[k])]/coef * 10) / 10).toFixed(1)
									switch (valtype) {
										case "tem":
											color = colorTemp(dataval);
											break;
										case "hum":
											color = colorHumidity(dataval);
											break;
										case "windstr":
											color = colorTemp(dataval);
											break;
										case "rain":
											color = colorTemp(dataval);
											break;
										default:
											color = colorTemp(dataval);
										break;
									}
									
										$('#' + btndata[k] + '_staty .' + year[j] + '').find('td:eq(' + n + ')').append(dataval);
										$('#' + btndata[k] + '_staty .' + year[j] + '').find('td:eq(' + n + ')').css("background-color", color);
									})
								}
							}
						}
					}
				}
			});
		}
///////////////////////
